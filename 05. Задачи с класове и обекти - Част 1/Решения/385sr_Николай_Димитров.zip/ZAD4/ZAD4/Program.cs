﻿namespace ZAD4
{
    class Rectangle
    {
        public int width;
        public int height;

        public int GetArea()
        {
            return width * height;
        }

        public int GetPerimeter()
        {
            return 2 * (width + height);
        }

        public void PrintInfo()
        {
            Console.WriteLine("Ширина: " + width);
            Console.WriteLine("Височина: " + height);
            Console.WriteLine("Лице: " + GetArea());
            Console.WriteLine("Периметър: " + GetPerimeter());
        }

        class Program
        {
            static void Main()
            {
                Rectangle rect = new Rectangle();

                Console.WriteLine("Въведете ширина: ");
                rect.width = int.Parse(Console.ReadLine());

                Console.WriteLine("Въведете височина: ");
                rect.height = int.Parse(Console.ReadLine());

                Console.WriteLine();
                rect.PrintInfo();
            }
        }
    }
}