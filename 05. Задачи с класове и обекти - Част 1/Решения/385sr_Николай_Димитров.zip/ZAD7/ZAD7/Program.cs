﻿namespace ZAD7
{
    class Student
    {
        public string name;
        public string facultyNumber;

        public Student(string name, string facultyNumber)
        {
            this.name = name;
            this.facultyNumber = facultyNumber;
        }
    }

    class Course
    {
        public string courseName;
        public string teacherName;

        public Course(string courseName, string teacherName)
        {
            this.courseName = courseName;
            this.teacherName = teacherName;
        }

        public void EnrollStudent(Student student)
        {
            Console.WriteLine($"Студент {student.name} с ФН {student.facultyNumber} е записан в курса \"{courseName}\", воден от {teacherName}.");
        }
    }

    class Program
    {
        static void Main()
        {
            Student student = new Student("Иван Петров", "12345");
            Course course = new Course("Увод в програмирането", "доц. д-р Мария Иванова");

            course.EnrollStudent(student);
        }
    }
}
