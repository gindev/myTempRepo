﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZAD2
{
    class Book
    {
        public string title;
        public string author;
        public int year_of_publication;
        public int pages;

        public void PrintInfo()
        {
            Console.WriteLine("Заглавие: " +  title);
            Console.WriteLine("Автор: " + author);
            Console.WriteLine("Година на издаване: " + year_of_publication);
            Console.WriteLine("Брой страници: " + pages);
            Console.WriteLine();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Book book1 = new Book();
            book1.title = "Под игото";
            book1.author = "Иван Вазов";
            book1.year_of_publication = 1894;
            book1.pages = 350;

            Book book2 = new Book();
            book2.title = "Немили-недраги";
            book2.author = "Иван Вазов";
            book2.year_of_publication = 1883;
            book2.pages = 120;

            book1.PrintInfo();
            book2.PrintInfo();

        }
    }

}
