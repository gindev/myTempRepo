﻿namespace ZAD3
{
    class Car
    {
        public string brand;
        public string model;
        public int year;
        public int maxspeed;

        public Car(string brand, string model, int year, int maxspeed)
        {
            this.brand = brand;
            this.model = model;
            this.year = year;
            this.maxspeed = maxspeed;
        }

        public void ShowCarInfo()
        {
            Console.WriteLine("Марка: " + brand);
            Console.WriteLine("Модел: " + model);
            Console.WriteLine("Година: " + year);
            Console.WriteLine("Максимална скорост: " + maxspeed + "км/ч");
            Console.WriteLine();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car("Toyota", "Corolla", 2020, 180);
            Car car2 = new Car("BMW", "X5", 2022, 240);
            Car car3 = new Car("Audi", "A4", 2021, 220);

            car1.ShowCarInfo();
            car2.ShowCarInfo();
            car3.ShowCarInfo();
        }
    }
}
