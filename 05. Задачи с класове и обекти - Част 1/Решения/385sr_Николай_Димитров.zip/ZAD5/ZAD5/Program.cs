﻿namespace ZAD5
{
    class BankAccount
    {
        public string accountNumber;
        public string holderName;
        public decimal balance;

        public void Deposit(decimal amount)
        {
            balance += amount;
            Console.WriteLine("Внесена сума: " + amount);
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine("Изтеглена сума: " + amount);
            }
            else
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
        }

        public void PrintBalance()
        {
            Console.WriteLine("Текуща наличност: " + balance);
        }
    }

    class Program
    {
        static void Main()
        {
            BankAccount account = new BankAccount();

            Console.WriteLine("Въведете номер на сметка: ");
            account.accountNumber = Console.ReadLine();

            Console.WriteLine("Въведете име: ");
            account.holderName = Console.ReadLine();

            Console.WriteLine("Начална наличност: ");
            account.balance = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Въведете сума за внасяне: ");
            decimal depositAmount = decimal.Parse(Console.ReadLine());
            account.Deposit(depositAmount);

            Console.WriteLine("Въведете сума за теглене: ");
            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
            account.Withdraw(withdrawAmount);

            Console.WriteLine();

            account.PrintBalance();
        }
    }
}
