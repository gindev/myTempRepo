﻿namespace ZAD6
{    
    class Movie
    {
        public string name;
        public string genre;
        public int duration;
        public double rating;

        public Movie(string name, string genre, int duration, double rating)
        {
            this.name = name;
            this.genre = genre;
            this.duration = duration;
            this.rating = rating;
        }

        public void Print()
        {
            Console.WriteLine($"{name} | Жанр: {genre} | Продължителност: {duration} мин. | Оценка: {rating}");
        }
    }

    class Program
    {
        static void Main()
        {
            List<Movie> movies = new List<Movie>();

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Филм {i + 1}:");

                Console.Write("Име: ");
                string name = Console.ReadLine();

                Console.Write("Жанр: ");
                string genre = Console.ReadLine();

                Console.Write("Продължителност: ");
                int duration = int.Parse(Console.ReadLine());

                Console.Write("Оценка: ");
                double rating = double.Parse(Console.ReadLine());

                movies.Add(new Movie(name, genre, duration, rating));
                Console.WriteLine();
            }

            Console.WriteLine("Всички филми:");
            foreach (var m in movies)
            {
                m.Print();
            }

            Movie best = movies[0];

            foreach (var m in movies)
            {
                if (m.rating > best.rating)
                {
                    best = m;
                }
            }

            Console.WriteLine("\nФилм с най-висока оценка:");
            best.Print();
        }
    }
}
