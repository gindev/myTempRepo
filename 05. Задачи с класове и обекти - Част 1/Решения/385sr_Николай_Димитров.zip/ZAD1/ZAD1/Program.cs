﻿namespace ZAD1
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();

            student.FirstName = "Николай";
            student.LastName = "Димитров";
            student.FN = 385;
            student.Spec = "Информационна сигурност";

            Console.WriteLine("Име: " + student.FirstName);
            Console.WriteLine("Фамилия: " + student.LastName);
            Console.WriteLine("Факултетен номер: " + student.FN);
            Console.WriteLine("Специалност: " + student.Spec);
        }
    }
}
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int FN { get; set; }
        public string Spec { get; set; }
    }

