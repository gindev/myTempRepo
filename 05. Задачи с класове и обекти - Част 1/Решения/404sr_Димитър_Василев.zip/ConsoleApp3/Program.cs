﻿namespace AllTasksInOne
{
    // ====================== ЗАДАЧА 1 ======================
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }
    }

    // ====================== ЗАДАЧА 2 ======================
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public int Pages { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine("Заглавие: " + Title);
            Console.WriteLine("Автор: " + Author);
            Console.WriteLine("Година на издаване: " + Year);
            Console.WriteLine("Брой страници: " + Pages);
            Console.WriteLine();
        }
    }

    // ====================== ЗАДАЧА 3 ======================
    class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int MaxSpeed { get; set; }

        public Car(string brand, string model, int year, int maxSpeed)
        {
            Brand = brand;
            Model = model;
            Year = year;
            MaxSpeed = maxSpeed;
        }

        public void ShowCarInfo()
        {
            Console.WriteLine("Марка: " + Brand);
            Console.WriteLine("Модел: " + Model);
            Console.WriteLine("Година: " + Year);
            Console.WriteLine("Максимална скорост: " + MaxSpeed + " км/ч");
            Console.WriteLine();
        }
    }

    // ====================== ЗАДАЧА 4 ======================
    class Rectangle
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public double GetArea() => Width * Height;

        public double GetPerimeter() => 2 * (Width + Height);

        public void PrintInfo()
        {
            Console.WriteLine("Ширина: " + Width);
            Console.WriteLine("Височина: " + Height);
            Console.WriteLine("Лице: " + GetArea());
            Console.WriteLine("Периметър: " + GetPerimeter());
        }
    }

    // ====================== ЗАДАЧА 5 ======================
    class BankAccount
    {
        public string AccountNumber { get; set; }
        public string OwnerName { get; set; }
        public decimal Balance { get; private set; }

        public BankAccount(string accountNumber, string ownerName, decimal initialBalance)
        {
            AccountNumber = accountNumber;
            OwnerName = ownerName;
            Balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                Balance += amount;
                Console.WriteLine($"Внесена сума: {amount:F2}");
            }
        }

        public void Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine($"Изтеглена сума: {amount:F2}");
            }
            else
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
        }

        public void PrintBalance()
        {
            Console.WriteLine($"Текуща наличност: {Balance:F2}");
        }
    }

    // ====================== ЗАДАЧА 6 ======================
    class Movie
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Duration { get; set; }
        public double Rating { get; set; }
    }

    // ====================== ЗАДАЧА 7 ======================
    class UniversityStudent
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
    }

    class Course
    {
        public string CourseName { get; set; }
        public string Lecturer { get; set; }

        public void EnrollStudent(UniversityStudent student)
        {
            Console.WriteLine($"Студент {student.Name} с ФН {student.FacultyNumber} " +
                            $"е записан в курса \"{CourseName}\", воден от {Lecturer}.");
        }
    }

    // ====================== ГЛАВНА ПРОГРАМА (само един Main!) ======================
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== ВСИЧКИ ЗАДАЧИ В ЕДИН ПРОЕКТ ===\n");
                Console.WriteLine("1. Задача 1  - Клас Student");
                Console.WriteLine("2. Задача 2  - Клас Book");
                Console.WriteLine("3. Задача 3  - Клас Car с конструктор");
                Console.WriteLine("4. Задача 4  - Клас Rectangle");
                Console.WriteLine("5. Задача 5  - Клас BankAccount");
                Console.WriteLine("6. Задача 6  - Масив от филми (Movie)");
                Console.WriteLine("7. Задача 7  - Взаимодействие Student и Course");
                Console.WriteLine("0. Изход от програмата");
                Console.Write("\nИзберете номер на задача: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": Task1_Student(); break;
                    case "2": Task2_Book(); break;
                    case "3": Task3_Car(); break;
                    case "4": Task4_Rectangle(); break;
                    case "5": Task5_BankAccount(); break;
                    case "6": Task6_Movie(); break;
                    case "7": Task7_StudentCourse(); break;
                    case "0":
                        Console.WriteLine("Програмата приключва. Довиждане!");
                        return;
                    default:
                        Console.WriteLine("Невалиден избор! Моля опитайте отново.");
                        break;
                }

                Console.WriteLine("\nНатиснете произволен клавиш за връщане към менюто...");
                Console.ReadKey();
            }
        }

        // ====================== ЗАДАЧА 1 ======================
        static void Task1_Student()
        {
            Console.WriteLine("\n--- Задача 1: Клас Student ---");
            Student student = new Student
            {
                FirstName = "Димитър",
                LastName = "Василев",
                FacultyNumber = "404СР",
                Specialty = "Информационна сигурност"
            };

            Console.WriteLine("Име: " + student.FirstName);
            Console.WriteLine("Фамилия: " + student.LastName);
            Console.WriteLine("Факултетен номер: " + student.FacultyNumber);
            Console.WriteLine("Специалност: " + student.Specialty);
        }

        // ====================== ЗАДАЧА 2 ======================
        static void Task2_Book()
        {
            Console.WriteLine("\n--- Задача 2: Клас Book ---");

            Book book1 = new Book { Title = "Война и мир", Author = "Лев Толстой", Year = 1869, Pages = 1225 };
            Book book2 = new Book { Title = "Престьпление и наказание", Author = "Фьодор Достоевски", Year = 1866, Pages = 671 };

            book1.PrintInfo();
            book2.PrintInfo();
        }

        // ====================== ЗАДАЧА 3 ======================
        static void Task3_Car()
        {
            Console.WriteLine("\n--- Задача 3: Клас Car с конструктор ---");

            Car car1 = new Car("Honda", "Civic", 2019, 200);
            Car car2 = new Car("Audi", "A6", 2023, 250);
            Car car3 = new Car("Volkswagen", "Golf", 2021, 210);

            car1.ShowCarInfo();
            car2.ShowCarInfo();
            car3.ShowCarInfo();
        }

        // ====================== ЗАДАЧА 4 ======================
        static void Task4_Rectangle()
        {
            Console.WriteLine("\n--- Задача 4: Клас Rectangle ---");

            Console.Write("Въведете ширина: ");
            double width = double.Parse(Console.ReadLine());

            Console.Write("Въведете височина: ");
            double height = double.Parse(Console.ReadLine());

            Rectangle rect = new Rectangle { Width = width, Height = height };
            rect.PrintInfo();
        }

        // ====================== ЗАДАЧА 5 ======================
        static void Task5_BankAccount()
        {
            Console.WriteLine("\n--- Задача 5: Клас BankAccount ---");

            Console.Write("Въведете начална наличност: ");
            decimal initial = decimal.Parse(Console.ReadLine());

            BankAccount account = new BankAccount("BG5566778899", "Димитър Василев", initial);

            Console.WriteLine($"Начална наличност: {initial:F2}");

            Console.Write("Въведете сума за внасяне: ");
            decimal deposit = decimal.Parse(Console.ReadLine());
            account.Deposit(deposit);

            Console.Write("Въведете сума за теглене: ");
            decimal withdraw = decimal.Parse(Console.ReadLine());
            account.Withdraw(withdraw);

            account.PrintBalance();
        }

        // ====================== ЗАДАЧА 6 ======================
        static void Task6_Movie()
        {
            Console.WriteLine("\n--- Задача 6: Масив от филми ---");

            Movie[] movies = new Movie[5];

            for (int i = 0; i < 5; i++)
            {
                movies[i] = new Movie();
                Console.WriteLine($"\nВъвеждане на филм №{i + 1}");
                Console.Write("Име на филм: ");
                movies[i].Title = Console.ReadLine();

                Console.Write("Жанр: ");
                movies[i].Genre = Console.ReadLine();

                Console.Write("Продължителност (минути): ");
                movies[i].Duration = int.Parse(Console.ReadLine());

                Console.Write("Оценка (0.0-10.0): ");
                movies[i].Rating = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("\n=== Информация за всички филми ===");
            foreach (var m in movies)
            {
                Console.WriteLine($"Филм: {m.Title} | Жанр: {m.Genre} | Продължителност: {m.Duration} мин. | Оценка: {m.Rating}");
            }

            // Намиране на най-висока оценка
            Movie best = movies[0];
            foreach (var m in movies)
            {
                if (m.Rating > best.Rating)
                    best = m;
            }

            Console.WriteLine("\nФилм с най-висока оценка:");
            Console.WriteLine($"{best.Title} | Оценка: {best.Rating}");
        }

        // ====================== ЗАДАЧА 7 ======================
        static void Task7_StudentCourse()
        {
            Console.WriteLine("\n--- Задача 7: Взаимодействие между Student и Course ---");

            UniversityStudent student = new UniversityStudent
            {
                Name = "Димитър Василев",
                FacultyNumber = "404СР"
            };

            Course course = new Course
            {
                CourseName = "Практикум по програмиране на C#",
                Lecturer = "ас. д-р Панайот Гиндев"
            };

            course.EnrollStudent(student);
        }
    }
}