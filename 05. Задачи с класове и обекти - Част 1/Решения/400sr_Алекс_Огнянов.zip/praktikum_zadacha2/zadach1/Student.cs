﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadach1
{
    internal class Student
    {
        private string name;
        private string surname;
        private string fn;
        private string major;

        public Student(string name, string surname, string fn, string major)
        {
            this.name = name;
            this.surname = surname;
            this.fn = fn;
            this.major = major;
        }
        public void PrintStudent() 
        {
            Console.WriteLine($"Име: {name}");
            Console.WriteLine($"Фамилия: {surname}");
            Console.WriteLine($"Факултетент номер: {fn}");
            Console.WriteLine($"Специалност: {major}");

        }
    }
}
