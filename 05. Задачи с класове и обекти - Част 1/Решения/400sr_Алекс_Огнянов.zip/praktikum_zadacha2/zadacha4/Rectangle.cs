﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Rectangle
    {
        private double width;
        private double height;

        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }
        public double GetArea()
        {
            double area = width * height;
            return area;
        }
        public double GetPerimeter()
        {
            double perimeter = (width * 2) + (height * 2);
            return perimeter;
        }
        public void PrintInfo() 
        {
            Console.WriteLine($"Ширина: {width}");
            Console.WriteLine($"Височина: {height}");
            Console.WriteLine($"Лице: {GetArea()}");
            Console.WriteLine($"Периметър: {GetPerimeter()}");
        }
    }
}
