﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ваведи широчина: ");
            double width = double.Parse(Console.ReadLine());
            Console.Write("Ваведи височина: ");
            double height = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Rectangle r1 = new Rectangle(width,height);
            r1.PrintInfo();
        }
    }
}
