﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Алекс Огнянов","400ср");
            Course c1 = new Course("Практикум по C#","ас. д-р Панайот Гиндев");

            c1.EnrollStudent(s1);
        }
    }
}
