﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Student
    {
        public string name;
        public string fn;

        public Student(string name, string fn)
        {
            this.name = name;
            this.fn = fn;
        }

    }
}
