﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Course
    {
        public string major;
        public string teacher;

        public Course(string major, string teacher)
        {
            this.major = major;
            this.teacher = teacher;
        }
        public void EnrollStudent(Student s1) 
        {
            Console.WriteLine($"Студент {s1.name} с ФН {s1.fn} е записан в курса '{major}', воден от {teacher}");
        }
    }
}
