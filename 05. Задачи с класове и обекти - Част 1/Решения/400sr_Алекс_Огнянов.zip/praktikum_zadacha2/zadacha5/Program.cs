﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            BankAccount b1 = new BankAccount("4545tg56tgt5", "Aleks", 0);
            
            
            Console.Write($"Начална наличност: ");
            decimal balance = decimal.Parse(Console.ReadLine());
            b1.Deposit(balance);

            Console.Write("Сума за внасяне: ");
            decimal depositSum = decimal.Parse(Console.ReadLine());
            b1.Deposit(depositSum);

            Console.Write("Сума за теглена: ");
            decimal withdrawSum = decimal.Parse(Console.ReadLine());
            b1.Withdraw(withdrawSum);

            Console.WriteLine($"Текуща наличност: {b1.PrintBalance()}");

        }
    }
}
