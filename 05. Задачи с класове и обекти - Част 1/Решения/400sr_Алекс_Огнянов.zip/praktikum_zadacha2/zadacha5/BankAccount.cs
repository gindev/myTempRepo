﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class BankAccount
    {
        private string iBan;
        private string owner;
        private decimal balance;

        public BankAccount(string iBan, string owner, decimal balance)
        {
            this.iBan = iBan;
            this.owner = owner;
            this.balance = balance;
        }
        public void Deposit(decimal deposit) 
        {
            balance += deposit;

        }
        public void Withdraw(decimal withdraw) 
        {
            if (withdraw>balance) 
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
            else balance -= withdraw;
        }
        public decimal PrintBalance() 
        {
            return balance;
        }
    }
}
