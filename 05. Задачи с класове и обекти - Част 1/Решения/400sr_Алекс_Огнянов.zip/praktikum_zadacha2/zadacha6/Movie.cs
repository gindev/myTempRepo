﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Movie
    {
        public string Name { get; set; }
        public string Genre { get; set; }
        public int Duration { get; set; }
        public double Rating { get; set; }
    }
}
