﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Movie[] movies = new Movie[5];


            for (int i = 0; i < movies.Length; i++)
            {
                Console.WriteLine($"Въведи данни за филм {i + 1}:");

                Console.Write("Име: ");
                string name = Console.ReadLine();

                Console.Write("Жанр: ");
                string genre = Console.ReadLine();

                Console.Write("Продължителност: ");
                int duration = int.Parse(Console.ReadLine());

                Console.Write("Оценка: ");
                double rating = double.Parse(Console.ReadLine());

                Movie movie = new Movie();
                movie.Name = name;
                movie.Genre = genre;
                movie.Duration = duration;
                movie.Rating = rating;

                movies[i] = movie;

                Console.WriteLine();
            }

            Console.WriteLine("Всички филми:");
            for (int i = 0; i < movies.Length; i++)
            {
                Console.WriteLine($"Филм {i + 1}: {movies[i].Name} | Жанр: {movies[i].Genre} | Продължителност: {movies[i].Duration} мин. | Оценка: {movies[i].Rating}");
            }

            Movie bestMovie = movies[0];

            for (int i = 1; i < movies.Length; i++)
            {
                if (movies[i].Rating > bestMovie.Rating)
                {
                    bestMovie = movies[i];
                }
            }

            Console.WriteLine();
            Console.WriteLine("Филм с най-висока оценка:");
            Console.WriteLine($"{bestMovie.Name} | Оценка: {bestMovie.Rating}");
        }
 
    }
}
