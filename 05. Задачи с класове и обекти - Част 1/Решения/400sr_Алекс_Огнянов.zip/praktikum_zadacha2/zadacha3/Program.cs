﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car c1 = new Car("Toyota","Corola",2020,180);
            Car c2 = new Car("BMW", "X5", 2022, 240);
            Car c3 = new Car("Audi", "A3", 2009, 220);

            c1.ShowCarInfo();
            c2.ShowCarInfo();
            c3.ShowCarInfo();
        }
    }
}
