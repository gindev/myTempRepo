﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Car
    {
        private string brand;
        private string model;
        private int releaseYear;
        private int maxSpeed;

        public Car(string brand, string model, int releaseYear, int maxSpeed)
        {
            this.brand = brand;
            this.model = model;
            this.releaseYear = releaseYear;
            this.maxSpeed = maxSpeed;
        }
        public void ShowCarInfo()
        {
            Console.WriteLine($"Марка: {this.brand}");
            Console.WriteLine($"Модел: {this.model}");
            Console.WriteLine($"Година: {this.releaseYear}");
            Console.WriteLine($"Максимална скорост: {this.maxSpeed}");
            Console.WriteLine();
        }
    }
}
