﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Book
    {
        private string heading;
        private string author;
        private int releaseDate;
        private int pageNum;

        public Book(string heading, string author, int releaseDate, int pageNum)
        {
            this.heading = heading;
            this.author = author;
            this.releaseDate = releaseDate;
            this.pageNum = pageNum;
        }
        public void PrintInfo() 
        {
            Console.WriteLine($"Заглавие: {heading}");
            Console.WriteLine($"Автор: {author}");
            Console.WriteLine($"Дата на издаване: {releaseDate}");
            Console.WriteLine($"Брой страници: {pageNum}");
            Console.WriteLine();
        }
    }
}
