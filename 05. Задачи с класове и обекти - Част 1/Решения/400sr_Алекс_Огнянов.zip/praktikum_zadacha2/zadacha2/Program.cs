﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book("Под игото","Иван Вазов",1894,350);
            Book b2 = new Book("Немили-недраги", "Иван Вазов", 1883, 120);
            b1.PrintInfo();
            b2.PrintInfo();

        }
    }
}
