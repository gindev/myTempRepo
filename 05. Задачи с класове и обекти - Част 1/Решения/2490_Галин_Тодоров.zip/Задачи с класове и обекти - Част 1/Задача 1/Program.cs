﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_1.Клас__Student
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Student student = new Student();

            Console.Write("Име: ");
            student.Ime = Console.ReadLine();

            Console.Write("Фамилия: ");
            student.Familiq = Console.ReadLine();

            Console.Write("Факултетен номер: ");
            student.Faklutetennomer = Console.ReadLine();

            Console.Write("Специалност: ");
            student.Specialnost = Console.ReadLine();

            student.PrintInfo();
        }


    }
}

    


