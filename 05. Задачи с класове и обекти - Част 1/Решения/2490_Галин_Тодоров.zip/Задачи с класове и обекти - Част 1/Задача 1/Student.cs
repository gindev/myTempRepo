﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_1.Клас__Student
{
    internal class Student
    {

        public string Ime;
        public string Familiq;
        public string Faklutetennomer;
        public string Specialnost;

        public Student() { }

        public Student(string ime, string familiq, string nomer, string specialnost)
        {
            Ime = ime;
            Familiq = familiq;
            Faklutetennomer = nomer;
            Specialnost = specialnost;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Име: " + Ime);
            Console.WriteLine("Фамилия: " + Familiq);
            Console.WriteLine("Номер: " + Faklutetennomer);
            Console.WriteLine("Специалност: " + Specialnost);
        }
    }

}
    

