﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_6.Масив_или_списък_от_обекти____Movie_
{
    internal class Movie
    {
        public string Title;
        public string Genre;
        public int Minutes;
        public double Score;

        
        public Movie(string title, string genre, int minutes, double score)
        {
            Title = title;
            Genre = genre;
            Minutes = minutes;
            Score = score;
        }

        
        public void PrintInfo(int number)
        {
            Console.WriteLine($"Филм {number}: {Title} | Жанр: {Genre} | Продължителност: {Minutes} мин. | Оценка: {Score}");
        }
    }

}