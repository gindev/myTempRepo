﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_6.Масив_или_списък_от_обекти____Movie_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Movie[] movies = new Movie[5];

                                  
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"--- Въведете данни за Филм №{i + 1} ---");

                Console.Write("Име: ");
                string title = Console.ReadLine();

                Console.Write("Жанр: ");
                string genre = Console.ReadLine();

                Console.Write("Продължителност (в минути): ");
                int duration = int.Parse(Console.ReadLine());

                Console.Write("Оценка: ");
                double rating = double.Parse(Console.ReadLine());

                
                movies[i] = new Movie(title, genre, duration, rating);
                Console.WriteLine(); 
            }

             
           
            for (int i = 0; i < 5; i++)
            {
                movies[i].PrintInfo(i + 1);
            }

            
            int BestRate = 0; 

            for (int i = 1; i < 5; i++)
            {
                if (movies[i].Score > movies[BestRate].Score)
                {
                   BestRate= i; 
                }
            }


            Console.WriteLine("=================================================");
            Console.WriteLine("Филм с най-висока оценка:");
            Console.WriteLine($"{movies[BestRate].Title} | Оценка: {movies[BestRate].Score}");
            Console.WriteLine("=================================================");
        }
    }

}

