﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_5.Клас__BankAccount_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Начална наличност: ");
            decimal initial = decimal.Parse(Console.ReadLine());
            BankAccount acc = new BankAccount(initial);

           
            Console.Write("Внесена сума: ");
            decimal depositAmount = decimal.Parse(Console.ReadLine());
            acc.Deposit(depositAmount);

        
            Console.Write("Изтеглена сума: ");
            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
            acc.Withdraw(withdrawAmount);

            
            acc.PrintBalance();
        }
    }

}
    

