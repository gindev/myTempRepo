﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_5.Клас__BankAccount_
{
    internal class BankAccount
    {
        private string accountNumber;
        private string accountHolder;
        private decimal balance;

 
        public BankAccount(decimal initialBalance)
        {
            balance = initialBalance;
        }

       
        public void Deposit(decimal amount)
        {
            balance += amount;
        }

        
        public void Withdraw(decimal amount)
        {
            if (amount > balance)
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
            else
            {
                balance -= amount;
            }
        }

        
        public void PrintBalance()
        {
            Console.WriteLine($"Текуща наличност: {balance:F2}");
        }
    }

}

