﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_3.Клас__Car__с_конструктор
{
    internal class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int MaxSpeed { get; set; }


        public Car(string brand, string model, int year, int maxSpeed)
        {
            Brand = brand;
            Model = model;
            Year = year;
            MaxSpeed = maxSpeed;
        }


        public void ShowCarInfo()
        {
            Console.WriteLine($"Марка: {Brand}\nМодел: {Model}\nГодина: {Year}\nМаксимална скорост: {MaxSpeed} км/ч\n");
        }
    }

}
