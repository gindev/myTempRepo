﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_3.Клас__Car__с_конструктор
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Car[] cars = {
            new Car("Mercedess", "S550" , 2008, 250),
            new Car("Iveco", "Daily", 2008, 150),
            
        };

        
            foreach (var car in cars)
            {
                car.ShowCarInfo();
            }
        }
    }
}
   

