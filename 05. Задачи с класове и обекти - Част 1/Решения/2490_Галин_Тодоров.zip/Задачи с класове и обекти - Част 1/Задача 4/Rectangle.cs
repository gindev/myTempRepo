﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_4.Клас__Rectangle__с_изчислителни_методи
{
    internal class Rectangle
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double GetArea()
        {
            return Width * Height;
        }

        public double GetPerimeter()
        {
            return 2 * (Width + Height);
        }
       
        public void PrintInfo()
        {
            Console.WriteLine($"Ширина: {Width}");
            Console.WriteLine($"Височина: {Height}");
            Console.WriteLine($"Лице: {GetArea()}");
            Console.WriteLine($"Периметър: {GetPerimeter()}");
        }
    }

}
