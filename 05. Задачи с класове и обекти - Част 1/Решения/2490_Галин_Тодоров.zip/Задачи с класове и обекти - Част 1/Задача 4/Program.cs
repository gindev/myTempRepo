﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_4.Клас__Rectangle__с_изчислителни_методи
{
    internal class Program
    {
        static void Main(string[] args)
        {

            
            double w = double.Parse(Console.ReadLine());

            
            double h = double.Parse(Console.ReadLine());

            
            Rectangle rect = new Rectangle(w, h);

            rect.PrintInfo();
        }
    }
}
    

