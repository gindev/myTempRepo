﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book book1 = new Book("Под игото", "Иван Вазов", 1894, 350);
          
            Book book2 = new Book("Немили-недраги", "Иван Вазов", 1883, 120);
            
            book1.PrintInfo();

            book2.PrintInfo();

           
            Console.ReadKey();
        }
    }
}
