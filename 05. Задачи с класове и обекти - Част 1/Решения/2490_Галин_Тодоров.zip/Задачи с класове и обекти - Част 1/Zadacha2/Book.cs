﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Book
    {

        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public int Pages { get; set; }

   
        public Book(string title, string author, int year, int pages)
        {
            Title = title;
            Author = author;
            Year = year;
            Pages = pages;
        }

      
        public void PrintInfo()
        {
            Console.WriteLine($"Заглавие: {Title}");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Година на издаване: {Year}");
            Console.WriteLine($"Брой страници: {Pages}");
            Console.WriteLine();
        }
    }

}

