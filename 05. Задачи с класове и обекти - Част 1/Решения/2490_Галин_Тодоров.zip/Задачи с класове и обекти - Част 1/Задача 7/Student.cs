﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_7.Взаимодействие_между_обекти____Student__и__Course_
{
    internal class Student
    {

        public string name;
        public string facultyNumber;

        public Student(string name, string facultyNumber)
        {
            this.name = name;
            this.facultyNumber = facultyNumber;
        }
    }

}

