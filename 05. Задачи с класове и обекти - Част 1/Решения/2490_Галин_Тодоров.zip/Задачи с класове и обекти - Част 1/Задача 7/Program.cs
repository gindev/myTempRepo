﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_7.Взаимодействие_между_обекти____Student__и__Course_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student myStudent = new Student("Galin Todorov", "2490");

         
            Course myCourse = new Course("Практикум по C# sharp", " ас. д-р Панайот Гиндев");

            
            myCourse.EnrollStudent(myStudent);
        }
    }

}
