﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_7.Взаимодействие_между_обекти____Student__и__Course_
{
    internal class Course
    {
        public string courseName;
        public string teacherName;

        
        public Course(string courseName, string teacherName)
        {
            this.courseName = courseName;
            this.teacherName = teacherName;
        }

        
        public void EnrollStudent(Student student)
        {
            
            Console.WriteLine($"Студент {student.name} с ФН {student.facultyNumber} е записан в курса \"{this.courseName}\",  от {this.teacherName}.");
        }
    }
}

