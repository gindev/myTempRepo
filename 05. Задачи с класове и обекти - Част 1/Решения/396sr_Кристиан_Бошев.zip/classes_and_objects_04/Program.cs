﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ширина: ");
            int width = int.Parse(Console.ReadLine());

            Console.Write("Въведете дължина: ");
            int length = int.Parse(Console.ReadLine());

            var rect = new Rectangle { width = width, length = length };

            rect.PrintInfo();
        }
    }
}
