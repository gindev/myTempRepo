﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_04
{
    internal class Rectangle
    {
        public int Length;
        public int Width;

        public int length { get => Length; set => Length = value; }
        public int width { get => Width; set => Width = value; }

        public int GetArea()
        {
            return Length * Width;
        }

        public int GetPerimeter()
        {
            return 2 * (Length + Width);
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Ширина: {width}");
            Console.WriteLine($"Дължина: {length}");
            Console.WriteLine($"Лице: {GetArea()}");
            Console.WriteLine($"Периметър: {GetPerimeter()}");
        }
    }
}
