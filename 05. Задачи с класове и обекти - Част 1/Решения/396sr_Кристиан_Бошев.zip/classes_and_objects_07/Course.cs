﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_07
{
    internal class Course
    {
        public string course_name { get; set; }
        public string teacher_name { get; set; }

        public void EnrollStudent(Student student)
        {
            Console.WriteLine($"Студент {student.Name} с ФН {student.faculty_number} " +
                              $"е записан в курса \"{course_name}\", воден от доц. д-р {teacher_name}.");
        }
    }
}