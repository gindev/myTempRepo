﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            Console.Write("Въведете име на студент: ");
            student.Name = Console.ReadLine();
            Console.Write("Въведете факултетен номер: ");
            student.faculty_number = Console.ReadLine();


            Console.WriteLine();


            Course course = new Course();
            Console.Write("Въведете име на дисциплина: ");
            course.course_name = Console.ReadLine();
            Console.Write("Въведете име на преподавател: ");
            course.teacher_name = Console.ReadLine();


            Console.WriteLine();
            course.EnrollStudent(student);
        }
    }
}
