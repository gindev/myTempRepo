﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car c1 = new Car("Aston Martin", "Vantage", 2009, 305);
            Car c2 = new Car("Mazda", "RX7", 1985, 240);
            Car c3 = new Car("Nissan", "Silvia", 1999, 235);
            Car c4 = new Car("Ferrari", "F40", 1987, 324);

            c1.ShowCarInfo();
            c2.ShowCarInfo();
            c3.ShowCarInfo();
            c4.ShowCarInfo();
        }
    }
}
