﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_03
{
    internal class Car
    {
        public string brand;
        public string model;
        public int year_of_production;
        public int top_speed;

        public string Brand { get => brand; set => brand = value; }
        public string Model { get => model; set => model = value; }
        public int Year_of_production { get => year_of_production; set => year_of_production = value; }
        public int Top_speed { get => top_speed; set => top_speed = value; }

        public Car(string brand, string model, int year, int topSpeed)
        {
            Brand = brand;
            Model = model;
            Year_of_production = year;
            Top_speed = topSpeed;
        }
        public void ShowCarInfo()
        {
            Console.WriteLine($"The {brand} {model} is released {year_of_production} and reaches a top speed of {top_speed} kilometres per hour.");
        }
    }
}
