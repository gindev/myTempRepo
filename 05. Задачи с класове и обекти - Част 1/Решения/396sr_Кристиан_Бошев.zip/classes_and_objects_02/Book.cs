﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace classes_and_objects_02
{
    internal class Book
    {
        public string Title;
        public string Author;
        public string publishing_year;
        public int pages;

        public Book(string Title, string Author, string publishing_year, int pages)
        {
            this.Title = Title;
            this.Author = Author;
            this.publishing_year = publishing_year;
            this.pages = pages;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"{Title} is written {publishing_year} by {Author} and the book has {pages} number of pages.");
        }
    }
}

