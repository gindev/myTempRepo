﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace classes_and_objects_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "1925", 218);
            Book b2 = new Book("To Kill a Mockingbird", "Harper Lee", "1960", 281);
            Book b3 = new Book("1984", "George Orwell", "1949", 328);

            b1.PrintInfo();
            b2.PrintInfo();
            b3.PrintInfo();
        }

    }
}
