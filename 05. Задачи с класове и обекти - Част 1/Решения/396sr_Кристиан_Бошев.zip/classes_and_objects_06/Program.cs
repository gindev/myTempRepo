﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Movie> movies = new List<Movie>();

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Въведете данни за филм {i + 1}:");

                Movie movie = new Movie();

                Console.Write("Име: ");
                movie.Title = Console.ReadLine();

                Console.Write("Жанр: ");
                movie.Genre = Console.ReadLine();

                Console.Write("Продължителност: ");
                movie.Duration = int.Parse(Console.ReadLine());

                Console.Write("Оценка: ");
                movie.Rating = double.Parse(Console.ReadLine());

                movies.Add(movie);
                Console.WriteLine();
            }

            Console.WriteLine("Всички филми:");
            for (int i = 0; i < movies.Count; i++)
            {
                movies[i].PrintInfo(i + 1);
            }

            Movie bestMovie = movies[0];

            foreach (Movie movie in movies)
            {
                if (movie.Rating > bestMovie.Rating)
                {
                    bestMovie = movie;
                }
            }

            Console.WriteLine("\nФилм с най-висока оценка:");
            Console.WriteLine($"{bestMovie.Title} | Оценка: {bestMovie.Rating}");
        }
    }
}

