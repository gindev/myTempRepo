﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_06
{
    internal class Movie
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Duration { get; set; }
        public double Rating { get; set; }

        public void PrintInfo(int index)
        {
            Console.WriteLine($"Филм {index}: {Title} | Жанр: {Genre} | Продължителност: {Duration} мин. | Оценка: {Rating}");
        }
    }
}