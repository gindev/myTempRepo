﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете номер на сметка: ");
            string number = Console.ReadLine();

            Console.Write("Въведете име на титуляр: ");
            string name = Console.ReadLine();

            Console.Write("Начална наличност: ");
            decimal initialBalance = decimal.Parse(Console.ReadLine());

            BankAccount account = new BankAccount(number, name, initialBalance);

            Console.Write("Внесена сума: ");
            decimal depositAmount = decimal.Parse(Console.ReadLine());
            account.Deposit(depositAmount);

            Console.Write("Изтеглена сума: ");
            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
            account.Withdraw(withdrawAmount);

            account.PrintBalance();
        }
    }
}
