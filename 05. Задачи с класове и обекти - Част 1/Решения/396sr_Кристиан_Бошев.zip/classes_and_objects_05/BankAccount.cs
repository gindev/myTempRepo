﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_05
{
    internal class BankAccount
    {
        public string AccountNumber { get; set; }
        public string HolderName { get; set; }
        public decimal Balance { get; set; }

        public BankAccount(string accountNumber, string holderName, decimal initialBalance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            Balance += amount;
            Console.WriteLine($"Внесена сума: {amount:F2}");
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine($"Изтеглена сума: {amount:F2}");
            }
            else
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
        }

        public void PrintBalance()
        {
            Console.WriteLine($"Текуща наличност: {Balance:F2}");
        }
    }
}