﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_01
{
    internal class Student
    {
        public string Name;
        public string Surname;
        public int faculty_number;
        public string uni_major;
    }
}
