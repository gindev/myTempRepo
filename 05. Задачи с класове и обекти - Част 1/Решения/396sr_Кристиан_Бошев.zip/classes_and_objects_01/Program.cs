﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            s1.Name = "John";
            s1.Surname = "Smith";
            s1.faculty_number = 12345;
            s1.uni_major = "Computer Science";

            Console.WriteLine("Student Information:");
            Console.WriteLine($"Name: {s1.Name}");
            Console.WriteLine($"Surname: {s1.Surname}");
            Console.WriteLine($"Faculty Number: {s1.faculty_number}");
            Console.WriteLine($"University Major: {s1.uni_major}");



            Student s2 = new Student();
            s2.Name = "Jane";
            s2.Surname = "Doe";
            s2.faculty_number = 67890;
            s2.uni_major = "Physics";

            Console.WriteLine("\nStudent Information:");
            Console.WriteLine($"Name: {s2.Name}");
            Console.WriteLine($"Surname: {s2.Surname}");
            Console.WriteLine($"Faculty Number: {s2.faculty_number}");
            Console.WriteLine($"University Major: {s2.uni_major}");
        }
    }
}
