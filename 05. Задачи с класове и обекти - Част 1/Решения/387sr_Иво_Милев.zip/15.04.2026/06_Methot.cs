﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _15._04._2026
{
	internal class _06_Methot
	{
	}
}
