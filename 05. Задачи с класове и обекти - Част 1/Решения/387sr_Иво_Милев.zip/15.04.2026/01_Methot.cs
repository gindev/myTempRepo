﻿using System;

class Student
{
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public int FacultyNumber { get; set; }
	public string Specialty { get; set; }

	public void PrintInfo()
	{
		Console.WriteLine($"Име: {FirstName}");
		Console.WriteLine($"Фамилия: {LastName}");
		Console.WriteLine($"Факултетен номер: {FacultyNumber}");
		Console.WriteLine($"Специалност: {Specialty}");
	}
}

class Program
{
	static void Main(string[] args)
	{
		Student student = new Student();

		student.FirstName = "Иван";
		student.LastName = "Милев";
		student.FacultyNumber = 12345;
		student.Specialty = "Информационни системи";

		student.PrintInfo();
	}
}
