﻿namespace Exercise_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            Course course = new Course();

            Console.Write("Student Name: ");
            student.Name = Console.ReadLine();

            Console.Write("Faculty Number: ");
            student.FacultyNumber = Console.ReadLine();

            Console.Write("Course name: ");
            course.CourseName = Console.ReadLine();

            Console.Write("Lecturer: ");
            course.TeacherName = Console.ReadLine();

            course.EnrollStudent(student);
        }
        class Student
        {
            public string Name;
            public string FacultyNumber;
        }

        class Course
        {
            public string CourseName;
            public string TeacherName;

            public void EnrollStudent(Student student)
            {
                Console.WriteLine($"Student {student.Name} with faculty number {student.FacultyNumber} is enrolled in the course {CourseName} led by {TeacherName}");
            }
        }

    }
}
