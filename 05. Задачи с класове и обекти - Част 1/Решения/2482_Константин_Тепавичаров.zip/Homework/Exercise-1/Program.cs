﻿using System;
internal class Program
{
    static void Main(string[] args)
    {
        Student student = new Student();
        Console.Write("Enter a First Name: ");
        student.FirstName = Console.ReadLine();
        Console.Write("Enter a Last Name: ");
        student.LastName = Console.ReadLine();
        Console.Write("Enter a Faculty Number: ");
        student.FacultyNumber = Console.ReadLine();
        Console.Write("Enter a Specialty: ");
        student.Specialty = Console.ReadLine();

        Console.WriteLine();

        student.PrintInfo();
    }
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"First Name: {FirstName}");
            Console.WriteLine($"Last Name: {LastName}");
            Console.WriteLine($"Faculty: {FacultyNumber}");
            Console.WriteLine($"Specialty: {Specialty}");
        }
    }
}
