﻿internal class namespaceExercise_1
{
}