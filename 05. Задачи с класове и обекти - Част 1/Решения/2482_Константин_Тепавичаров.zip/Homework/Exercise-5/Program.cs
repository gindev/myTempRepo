﻿namespace Exercise_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount();

            Console.Write("Account number: ");
            account.AccountNumber = Console.ReadLine();

            Console.Write("Holder name: ");
            account.HolderName = Console.ReadLine();

            Console.Write("Initial stock: ");
            account.Balance = decimal.Parse(Console.ReadLine());

            Console.Write("Amount deposited: ");
            decimal deposit = decimal.Parse(Console.ReadLine());
            account.Deposit(deposit);

            Console.Write("Withdrawn amount: ");
            decimal withdraw = decimal.Parse(Console.ReadLine());
            account.Withdraw(withdraw);

            account.PrintBalance();
        }
        class BankAccount
        {
            public string AccountNumber;
            public string HolderName;
            public decimal Balance;
            public void Deposit(decimal amount)
            {
                Balance += amount;
            }
            public void Withdraw(decimal amount)
            {
                if (amount > Balance)
                    Console.WriteLine("\r\nInsufficient stock!");
                else
                    Balance -= amount;
            }
            public void PrintBalance()
            {
                Console.WriteLine("Current availability: " + Balance);
            }
        }
    }
}
