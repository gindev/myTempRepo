﻿namespace Exercise_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle();

            Console.Write("Enter a height: ");
            rect.Width = double.Parse(Console.ReadLine());

            Console.Write("Enter a width: ");
            rect.Height = double.Parse(Console.ReadLine());

            rect.PrintInfo();
        }
        class Rectangle
        {
            public double Width { get; set; }
            public double Height { get; set; }
            public double GetArea()
            {
                return Width * Height;
            }
            public double GetPerimeter()
            {
                return 2 * (Width + Height);
            }
            public void PrintInfo()
            {
                Console.WriteLine($"Width: {Width}");
                Console.WriteLine($"Height: {Height}");
                Console.WriteLine($"Area: {GetArea()}");
                Console.WriteLine($"Perimeter: {GetPerimeter()}");
            }
        }
    }
}
