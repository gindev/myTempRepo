﻿namespace Exercise_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Movie[] movies = new Movie[5];
            Movie bestMovie = null;

            for (int i = 0; i < 5; i++)
            {
                movies[i] = new Movie();

                Console.WriteLine($"Film {i + 1}");

                Console.Write("Name: ");
                movies[i].Name = Console.ReadLine();

                Console.Write("Genre: ");
                movies[i].Genre = Console.ReadLine();

                Console.Write("Duration: ");
                movies[i].Duration = int.Parse(Console.ReadLine());

                Console.Write("Grade: ");
                movies[i].Rating = double.Parse(Console.ReadLine());

                if (bestMovie == null || movies[i].Rating > bestMovie.Rating)
                    bestMovie = movies[i];
            }

            Console.WriteLine("All Films:");
            foreach (Movie movie in movies)
                movie.PrintInfo();

            Console.WriteLine("Film with the highest grade:");
            bestMovie.PrintInfo();
        }
        class Movie
        {
            public string Name;
            public string Genre;
            public int Duration;
            public double Rating;

            public void PrintInfo()
            {
                Console.WriteLine(Name + " | " + Genre + " | " + Duration + " minutes | Grade: " + Rating);
            }
        }
    }
}
