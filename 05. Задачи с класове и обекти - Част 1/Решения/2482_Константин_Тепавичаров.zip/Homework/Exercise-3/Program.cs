﻿namespace Exercise_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine($"Enter data for a car number - {i}:");

                Console.Write("Brand: ");
                string brand = Console.ReadLine();

                Console.Write("Model: ");
                string model = Console.ReadLine();

                Console.Write("Year: ");
                int year = int.Parse(Console.ReadLine());

                Console.Write("Max Speed: ");
                int speed = int.Parse(Console.ReadLine());

                Car car = new Car(brand, model, year, speed);
                car.ShowCarInfo();
            }
        }
        class Car
        {
            public string Brand;
            public string Model;
            public int Year;
            public int MaxSpeed;

            public Car(string brand, string model, int year, int maxSpeed)
            {
                Brand = brand;
                Model = model;
                Year = year;
                MaxSpeed = maxSpeed;
            }
            public void ShowCarInfo()
            {
                Console.WriteLine("Brand: " + Brand);
                Console.WriteLine("Model: " + Model);
                Console.WriteLine("Year: " + Year);
                Console.WriteLine("Max Speed: " + MaxSpeed);
            }
        }
    }
}
