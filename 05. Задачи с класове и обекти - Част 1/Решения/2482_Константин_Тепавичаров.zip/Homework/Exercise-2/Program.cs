﻿namespace Exercise_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book book1 = new Book();
            Book book2 = new Book();

            Console.WriteLine("Enter a data for book number 1:");
            Console.Write("Title: ");
            book1.Title = Console.ReadLine();
            Console.Write("Author: ");
            book1.Author = Console.ReadLine();
            Console.Write("Year: ");
            book1.Year = int.Parse(Console.ReadLine());
            Console.Write("Pages: ");
            book1.Pages = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a data for book number 2:");
            Console.Write("Title: ");
            book2.Title = Console.ReadLine();
            Console.Write("Author: ");
            book2.Author = Console.ReadLine();
            Console.Write("Year: ");
            book2.Year = int.Parse(Console.ReadLine());
            Console.Write("Page: ");
            book2.Pages = int.Parse(Console.ReadLine());

            book1.PrintInfo();
            book2.PrintInfo();
        }

        class Book
        {
            public string Title { get; set; }
            public string Author { get; set; }
            public string Year { get; set; }
            public string Pages { get; set; }

            public void PrintInfo()
            {
                Console.WriteLine($"Title: {Title}");
                Console.WriteLine($"Author: {Author}");
                Console.WriteLine($"Year: {Year}");
                Console.WriteLine($"Pages: {Pages}");
            }
        }
    }
}
