namespace Program
{
    public class Student
    {
    
       string firstName;
       string lastName;
       string FN;
       string specialnost;

       public Student(string fName, string lName, string fn, string spec)
        {
            firstName = fName;
            lastName = lName;
            FN = fn;
            specialnost = spec;
        }


        public void PrintInfo()
        {
            Console.WriteLine($"First name: {firstName}");
            Console.WriteLine($"Last name: {lastName}");
            Console.WriteLine($"FN: {FN}");
            Console.WriteLine($"Specialty: {specialnost}");
        }
    
    }   
}