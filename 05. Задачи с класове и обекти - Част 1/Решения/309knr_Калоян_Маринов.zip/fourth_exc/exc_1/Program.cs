﻿
namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student("Ivan", "Petrov", "12345", "KN");
            student.PrintInfo();
        }
    }
}