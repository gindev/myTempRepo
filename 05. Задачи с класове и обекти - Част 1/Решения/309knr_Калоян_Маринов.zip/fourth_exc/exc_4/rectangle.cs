namespace Program
{
    public class Rectangle
    {
        double height;
        double width;


        public Rectangle()
        {
            Console.WriteLine("Enter the height of the rectacngle");
            height = double.Parse(Console.ReadLine());
        
            Console.WriteLine("Enter the width of the rectacngle");
            width = double.Parse(Console.ReadLine());
        }

        private double GetArea()
        {
            return height * width;
        }


        private double GetPerimeter()
        {
            return height * 2 + width * 2;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Heigth: {height}");
            Console.WriteLine($"Width: {width}");
            Console.WriteLine($"Area: {GetArea()}");
            Console.WriteLine($"Perimeter: {GetPerimeter()}");
            }
    }
}