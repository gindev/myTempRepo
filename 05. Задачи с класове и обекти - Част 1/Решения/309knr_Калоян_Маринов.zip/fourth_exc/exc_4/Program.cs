﻿
namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle r1 = new Rectangle();
            r1.PrintInfo();
        }
    }
}