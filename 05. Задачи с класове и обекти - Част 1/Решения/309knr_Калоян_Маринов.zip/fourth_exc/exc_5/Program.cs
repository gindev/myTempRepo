﻿
namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount b1 = new BankAccount();
            b1.Withdraw(100);
            b1.Deposit(500);
            b1.PrintBalance();
        }
    }
}