namespace Program
{
    public class BankAccount
    {
        string cardNum;
        string ownerName;
        decimal balance;


        public BankAccount()
        {
            Console.WriteLine("Enter the card number");
            cardNum = Console.ReadLine();
            
            Console.WriteLine("Enter the owner's name");
            ownerName = Console.ReadLine();

            Console.WriteLine("Enter the amount");
            balance = decimal.Parse(Console.ReadLine());

        }


        public decimal Deposit(decimal dAmount)
        {
            balance += dAmount;
            Console.WriteLine($"Deposited: {dAmount}");
            return balance;
        }

        public decimal Withdraw(decimal wAmount)
        {
            if(wAmount > balance)
            {
                balance -= wAmount;
                Console.WriteLine($"Withdrawed: {wAmount}");
            }
            else
            {
                Console.WriteLine("Not enough money");
            }
            return balance;
        }

        public void PrintBalance()
        {
            Console.WriteLine($"Your balance: {balance}");
        }

    }
}