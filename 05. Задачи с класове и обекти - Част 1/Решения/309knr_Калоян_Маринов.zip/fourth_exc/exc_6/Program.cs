﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Movie> movies = new List<Movie>();

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Movie {i + 1}:");
                movies.Add(new Movie());
            }

            Console.WriteLine("All movies:");
            foreach (var movie in movies)
            {
                movie.PrintMovie();
            }

            Movie bestMovie = movies[0];

            foreach (var movie in movies)
            {
                if (movie.GetRating() > bestMovie.GetRating())
                {
                    bestMovie = movie;
                }
            }

            Console.WriteLine("Movie with best rating:");
            Console.WriteLine($"{bestMovie.GetName()} | Rating: {bestMovie.GetRating()}");
        }
    }
}