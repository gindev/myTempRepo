namespace Program
{
    public class Movie
    {
        string name;
        string genre;
        int duration;
        double rating;

        public Movie()
        {
            Console.WriteLine("Movie name");
            name = Console.ReadLine();

            Console.Write("Genre");
            genre = Console.ReadLine();

            Console.WriteLine("Duration");
            duration = int.Parse(Console.ReadLine());

            Console.WriteLine("Rating");
            rating = double.Parse(Console.ReadLine());

            Console.WriteLine();
        }
        public void PrintMovie()
        {
            Console.WriteLine($"{name} | Genre: {genre} | Duration: {duration} min. | Rating: {rating}");
        }
        public double GetRating()
        {
            return rating;
        }

        public string GetName()
        {
            return name;
        }
    }
}