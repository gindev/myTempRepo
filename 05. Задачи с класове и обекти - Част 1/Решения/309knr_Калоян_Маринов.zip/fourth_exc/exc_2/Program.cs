﻿using System.Collections.Concurrent;

namespace Program
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Book b1 = new Book("Garden of Spikes and Roses", "Sarah", 2021, 400);
            Book b2 = new Book("Garden of Mist and Grudge", "Sarah", 2023, 700);
            b1.PrintInfo();
            b2.PrintInfo();
        }
    }
}