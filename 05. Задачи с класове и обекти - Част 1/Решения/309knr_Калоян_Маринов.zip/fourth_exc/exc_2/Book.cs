namespace Program
{
    public class Book
    {
        string title;
        string author;
        int yearOfPublication;
        int pagesCount;


        public Book(string title, string author, int year, int pagesCount)
        {
            this.title = title;
            this.author = author;
            this.yearOfPublication = year;
            this.pagesCount = pagesCount;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Title: {title}");
            Console.WriteLine($"Author: {author}");
            Console.WriteLine($"Published in: {yearOfPublication}");
            Console.WriteLine($"Pages count: {pagesCount}\n");
        }
    }
}