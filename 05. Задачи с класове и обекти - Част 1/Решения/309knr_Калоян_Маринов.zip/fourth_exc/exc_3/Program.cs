﻿using System.Runtime.CompilerServices;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car();
            Car car2 = new Car();

            car1.ShowCarInfo();
            car2.ShowCarInfo();
        }
    }
}