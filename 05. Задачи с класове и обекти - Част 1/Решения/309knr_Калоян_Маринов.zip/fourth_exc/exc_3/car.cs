namespace Program
{
    public class Car
    {
        string brand;
        string model;
        int year;
        int topSpeed;


        public Car()
        {
            Console.WriteLine("Enter the brand of your car");
            brand = Console.ReadLine();

            Console.WriteLine("Enter the model of your car");
            model = Console.ReadLine();

            Console.WriteLine("Enter the year that your car have be produced");
            year = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the top speed of your car");
            topSpeed = int.Parse(Console.ReadLine());
        }

        public void ShowCarInfo()
        {
            Console.WriteLine($"Model: {model}");
            Console.WriteLine($"Brand: {brand}");
            Console.WriteLine($"Produced: {year}");
            Console.WriteLine($"Top Speed: {topSpeed}");
        }
    }
}