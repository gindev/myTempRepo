﻿using Task1;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Student student = new("Клод", "Акимзада", "2477", "ИТ");

student.PasteStudentInfo();