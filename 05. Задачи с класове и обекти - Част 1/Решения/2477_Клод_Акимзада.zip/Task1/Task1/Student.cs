﻿namespace Task1
{
    public class Student
    {

        public Student(string firstName, string lastName, string facultyNumber, string specialty) 
        {
            FirstName = firstName;
            LastName = lastName;
            FacultyNumber = facultyNumber;
            Specialty = specialty;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }


        public void PasteStudentInfo()
        {
            Console.WriteLine($"Име: {FirstName}");
            Console.WriteLine($"Фамилия: {LastName}");
            Console.WriteLine($"Факултетен номер: {FacultyNumber}");
            Console.WriteLine($"Специалност: {Specialty}");
        }
    }
}
