﻿using Task2;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Book firstBook = new ("Под игото", "Иван Вазов", 1894, 350);


Book secondBook = new ("Немили-недраги", "Иван Вазов", 1883, 120);

firstBook.PrintInfo();
secondBook.PrintInfo();