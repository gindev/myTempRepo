﻿namespace Task2
{
    public class Book
    {

        public Book(string title, string author, int yearPublished, int pagesCount)
        {
            Title = title;
            Author = author;
            YearPublished = yearPublished;
            PagesCount = pagesCount;
        }

        public string Title { get; set; }
        public string Author { get; set; }
        public int YearPublished { get; set; }
        public int PagesCount { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"Заглавие: {Title}");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Година на издаване: {YearPublished}");
            Console.WriteLine($"Брой страници: {PagesCount}\n");
        }
    }
}
