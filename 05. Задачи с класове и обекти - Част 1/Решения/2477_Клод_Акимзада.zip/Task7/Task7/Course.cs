﻿namespace Task7
{
    public class Course
    {
        public string CourseName { get; set; }
        public string TeacherName { get; set; }

        public void EnrollStudent(Student student)
        {
            Console.WriteLine($"Студент {student.Name} с ФН {student.FacultyNumber} е записан в курса \"{CourseName}\", воден от {TeacherName}.");
        }
    }
}
