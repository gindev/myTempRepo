﻿using Task7;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Student student = new Student
{
    Name = "Иван Петров",
    FacultyNumber = "12345"
};

Course course = new Course
{
    CourseName = "Увод в програмирането",
    TeacherName = "доц. д-р Мария Иванова"
};


course.EnrollStudent(student);