﻿namespace Task7
{
    public class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
    }
}
