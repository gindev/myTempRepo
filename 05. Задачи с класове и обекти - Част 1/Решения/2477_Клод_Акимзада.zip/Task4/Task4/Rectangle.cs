﻿namespace Task4
{
    public class Rectangle
    {
        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }
        public double Width { get; set; }
        public double Height { get; set; }

        public double GetArea()
        {
            return Width * Height;
        }

        public double GetPerimeter()
        {
            return 2 * (Width + Height);
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Ширина: {Width}");
            Console.WriteLine($"Височина: {Height}");
            Console.WriteLine($"Лице: {GetArea()}");
            Console.WriteLine($"Периметър: {GetPerimeter()}");
        }
    }
}
