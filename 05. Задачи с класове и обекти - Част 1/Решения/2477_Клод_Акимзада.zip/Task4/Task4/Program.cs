﻿using Task4;

Console.OutputEncoding = System.Text.Encoding.UTF8;


double width = double.Parse(Console.ReadLine());

double height = double.Parse(Console.ReadLine());


Rectangle rectangle = new Rectangle(width, height);

rectangle.PrintInfo();