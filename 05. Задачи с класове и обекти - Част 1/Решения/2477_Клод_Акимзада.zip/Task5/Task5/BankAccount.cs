﻿namespace Task5
{
    public class BankAccount
    {
        public BankAccount(string accountNumber, string accountHolder, decimal initialBalance)
        {
            AccountNumber = accountNumber;
            AccountHolder = accountHolder;
            Balance = initialBalance;
        }
        public string AccountNumber { get; set; }
        public string AccountHolder { get; set; }
        public decimal Balance { get; private set; }


        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                Balance += amount;
            }
        }

        public void Withdraw(decimal amount)
        {
            if (amount > Balance)
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
            else if (amount > 0)
            {
                Balance -= amount;
            }
        }
        public void PrintBalance()
        {
            Console.WriteLine($"Текуща наличност: {Balance:F2}");
        }
    }
}
