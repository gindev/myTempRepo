﻿using Task5;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.Write("Начална наличност: ");
decimal initialBalance = decimal.Parse(Console.ReadLine());

BankAccount account = new("BG9812345678", "Иван Иванов", initialBalance);

Console.Write("Внесена сума: ");
decimal depositAmount = decimal.Parse(Console.ReadLine());
account.Deposit(depositAmount);


Console.Write("Изтеглена сума: ");
decimal withdrawAmount = decimal.Parse(Console.ReadLine());
account.Withdraw(withdrawAmount);

account.PrintBalance();