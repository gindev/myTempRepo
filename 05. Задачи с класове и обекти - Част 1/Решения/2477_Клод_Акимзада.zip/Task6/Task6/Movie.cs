﻿namespace Task6
{
    public class Movie
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int DurationInMinutes { get; set; }
        public double Rating { get; set; }

        public void PrintInfo(int index)
        {
            Console.WriteLine($"Филм {index}: {Title} | Жанр: {Genre} | Продължителност: {DurationInMinutes} мин. | Оценка: {Rating}");
        }
    }
}
