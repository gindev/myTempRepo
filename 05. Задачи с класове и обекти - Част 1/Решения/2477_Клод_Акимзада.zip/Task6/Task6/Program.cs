﻿using Task6;

Console.OutputEncoding = System.Text.Encoding.UTF8;

List<Movie> movies = new List<Movie>();

for (int i = 1; i <= 5; i++)
{
    Console.WriteLine($"\nВъвеждане на данни за филм {i}");

    Console.Write("Име на филм: ");
    string title = Console.ReadLine();

    Console.Write("Жанр: ");
    string genre = Console.ReadLine();

    Console.Write("Продължителност (в минути): ");
    int duration = int.Parse(Console.ReadLine());

    Console.Write("Оценка: ");
    double rating = double.Parse(Console.ReadLine());

    movies.Add(new Movie
    {
        Title = title,
        Genre = genre,
        DurationInMinutes = duration,
        Rating = rating
    });
}

Console.WriteLine("\nСписък с всички филми");
for (int i = 0; i < movies.Count; i++)
{
    movies[i].PrintInfo(i + 1);
}

Movie topRatedMovie = movies.OrderByDescending(m => m.Rating).First();

Console.WriteLine("\nФилм с най-висока оценка");
Console.WriteLine($"{topRatedMovie.Title} | Оценка: {topRatedMovie.Rating}");