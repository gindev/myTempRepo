﻿namespace Task3
{
    public class Car
    {
        public Car(string brand, string model, int year, int maxSpeed)
        {
            Brand = brand;
            Model = model;
            Year = year;
            MaxSpeed = maxSpeed;
        }

        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int MaxSpeed { get; set; }


        public void ShowCarInfo()
        {
            Console.WriteLine($"Марка: {Brand}");
            Console.WriteLine($"Модел: {Model}");
            Console.WriteLine($"Година: {Year}");
            Console.WriteLine($"Максимална скорост: {MaxSpeed} км/ч\n");
        }
    }
}
