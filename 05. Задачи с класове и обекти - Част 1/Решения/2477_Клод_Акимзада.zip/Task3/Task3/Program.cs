﻿using Task3;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Car firstCar = new("Toyota", "Corolla", 2020, 180);
Car secondCar = new("BMW", "X5", 2022, 240);
Car thirdCar = new("Audi", "A6", 2021, 250);

firstCar.ShowCarInfo();
secondCar.ShowCarInfo();
thirdCar.ShowCarInfo();