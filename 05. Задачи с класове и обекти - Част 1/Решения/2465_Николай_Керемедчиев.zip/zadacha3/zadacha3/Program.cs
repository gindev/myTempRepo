﻿namespace zadacha3
{
    using System;

    class Car
    {
        
        public string Brand;
        public string Model;
        public int Year;
        public int MaxSpeed;

       
        public Car(string brand, string model, int year, int maxSpeed)
        {
            Brand = brand;
            Model = model;
            Year = year;
            MaxSpeed = maxSpeed;
        }

        
        public void ShowCarInfo()
        {
            Console.WriteLine("Marka: " + Brand);
            Console.WriteLine("Model: " + Model);
            Console.WriteLine("Godina: " + Year);
            Console.WriteLine("Maksimalna skorost: " + MaxSpeed + " km/h");
            Console.WriteLine(); 
        }
    }

    class Program
    {
        static void Main()
        {
            
            Car car1 = new Car("Toyota", "Corolla", 2020, 180);
            Car car2 = new Car("BMW", "X5", 2022, 240);
            Car car3 = new Car("Audi", "A4", 2019, 210);

           
            car1.ShowCarInfo();
            car2.ShowCarInfo();
            car3.ShowCarInfo();
        }
    }
}
