﻿namespace zadacha2
{
    using System;

    class Book
    {
        
        public string Title;
        public string Author;
        public int Year;
        public int Pages;

        
        public void PrintInfo()
        {
            Console.WriteLine("Zaglavie: " + Title);
            Console.WriteLine("Aftor: " + Author);
            Console.WriteLine("Godina na izdavane: " + Year);
            Console.WriteLine("Broi stranici: " + Pages);
            Console.WriteLine(); 
        }
    }

    class Program
    {
        static void Main()
        {
            
            Book book1 = new Book();
            book1.Title = "Pod Igoto";
            book1.Author = "Ivan Vazov";
            book1.Year = 1894;
            book1.Pages = 350;

            Book book2 = new Book();
            book2.Title = "Nemili-Nedragi";
            book2.Author = "Ivan Vazov";
            book2.Year = 1883;
            book2.Pages = 120;

            book1.PrintInfo();
            book2.PrintInfo();
        }
    }
}
