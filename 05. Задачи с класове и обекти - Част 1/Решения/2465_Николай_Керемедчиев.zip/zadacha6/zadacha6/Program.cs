﻿namespace zadacha6
{
    using System;
    using System.Collections.Generic;

    class Movie
    {
        
        public string Title;
        public string Genre;
        public int Duration;
        public double Rating;

        
        public void PrintInfo(int index)
        {
            Console.WriteLine(
                $"Movie {index}: {Title} | Genre: {Genre} | Duration: {Duration} min. | Rating: {Rating}"
            );
        }
    }

    class Program
    {
        static void Main()
        {
            List<Movie> movies = new List<Movie>();

           
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Enter data for movie {i + 1}:");

                Movie movie = new Movie();

                Console.Write("Title: ");
                movie.Title = Console.ReadLine();

                Console.Write("Genre: ");
                movie.Genre = Console.ReadLine();

                Console.Write("Duration (minutes): ");
                movie.Duration = int.Parse(Console.ReadLine());

                Console.Write("Rating: ");
                movie.Rating = double.Parse(Console.ReadLine());

                movies.Add(movie);

                Console.WriteLine();
            }

            
            Console.WriteLine("All movies:");

            for (int i = 0; i < movies.Count; i++)
            {
                movies[i].PrintInfo(i + 1);
            }

            
            Movie bestMovie = movies[0];

            foreach (Movie movie in movies)
            {
                if (movie.Rating > bestMovie.Rating)
                {
                    bestMovie = movie;
                }
            }

            
            Console.WriteLine();
            Console.WriteLine("Movie with highest rating:");
            Console.WriteLine($"{bestMovie.Title} | Rating: {bestMovie.Rating}");
        }
    }
}
