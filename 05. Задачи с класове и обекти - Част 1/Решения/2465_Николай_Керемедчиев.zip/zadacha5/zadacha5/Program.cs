﻿namespace zadacha5
{
    using System;

    class BankAccount
    {
        
        public string AccountNumber;
        public string HolderName;
        public decimal Balance;

        
        public BankAccount(string accountNumber, string holderName, decimal balance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = balance;
        }

        
        public void Deposit(decimal amount)
        {
            Balance += amount;
            Console.WriteLine("Vnesena suma: " + amount.ToString("F2"));
        }

        
        public void Withdraw(decimal amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine("Izteglena suma: " + amount.ToString("F2"));
            }
            else
            {
                Console.WriteLine("Nedostatuchna nalichnost!");
            }
        }

       
        public void PrintBalance()
        {
            Console.WriteLine("Tekushta nalichnost: " + Balance.ToString("F2"));
        }
    }

    class Program
    {
        static void Main()
        {
            
            Console.Write("Vuvedete nomer na smetka: ");
            string accNumber = Console.ReadLine();

            Console.Write("Vuvedete ime na tutulqr: ");
            string holder = Console.ReadLine();

            Console.Write("Vuvedete nachalna nalichnost: ");
            decimal initialBalance = decimal.Parse(Console.ReadLine());

            
            BankAccount account = new BankAccount(accNumber, holder, initialBalance);

            Console.WriteLine("Nachalna nalichnost: " + initialBalance.ToString("F2"));

            
            Console.Write("Vuvedete suma na vnasqne: ");
            decimal depositAmount = decimal.Parse(Console.ReadLine());
            account.Deposit(depositAmount);

            
            Console.Write("Vuvedete suma na teglene: ");
            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
            account.Withdraw(withdrawAmount);

            
            account.PrintBalance();
        }
    }
}
