﻿namespace zadacha1
{
    using System;

    class Student
    {
       
        public string FirstName;
        public string LastName;
        public string FacultyNumber;
        public string Specialty;

        
        public void PrintInfo()
        {
            Console.WriteLine("Name: " + FirstName);
            Console.WriteLine("Surname: " + LastName);
            Console.WriteLine("Number: " + FacultyNumber);
            Console.WriteLine("Specialnost: " + Specialty);
        }
    }

    class Program
    {
        static void Main()
        {
           
            Student student1 = new Student();

           
            student1.FirstName = "Ivan";
            student1.LastName = "Peetrov";
            student1.FacultyNumber = "12345";
            student1.Specialty = "Informacionni sistemi";

            
            student1.PrintInfo();
        }
    }
}
