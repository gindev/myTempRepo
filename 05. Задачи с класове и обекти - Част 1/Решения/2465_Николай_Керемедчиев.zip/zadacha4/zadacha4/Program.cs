﻿namespace zadacha4
{
    using System;

    class Rectangle
    {
       
        public double Width;
        public double Height;

        
        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        
        public double GetArea()
        {
            return Width * Height;
        }

        
        public double GetPerimeter()
        {
            return 2 * (Width + Height);
        }

        public void PrintInfo()
        {
            Console.WriteLine("Jirina: " + Width);
            Console.WriteLine("Visochina: " + Height);
            Console.WriteLine("Lice: " + GetArea());
            Console.WriteLine("Perimetur: " + GetPerimeter());
        }
    }

    class Program
    {
        static void Main()
        {
           
            Console.Write("Vuvedete jirina: ");
            double width = double.Parse(Console.ReadLine());

            Console.Write("Vuvedete visochina: ");
            double height = double.Parse(Console.ReadLine());

            
            Rectangle rect = new Rectangle(width, height);

            
            rect.PrintInfo();
        }
    }
}
