﻿namespace zadacha7
{
    using System;

    class Student
    {
        
        public string Name;
        public string FacultyNumber;

        
        public Student(string name, string facultyNumber)
        {
            Name = name;
            FacultyNumber = facultyNumber;
        }
    }

    class Course
    {
       
        public string CourseName;
        public string TeacherName;

        
        public Course(string courseName, string teacherName)
        {
            CourseName = courseName;
            TeacherName = teacherName;
        }

        
        public void EnrollStudent(Student student)
        {
            Console.WriteLine(
                $"Student {student.Name} with FN {student.FacultyNumber} " +
                $"is enrolled in the course \"{CourseName}\", " +
                $"taught by {TeacherName}."
            );
        }
    }

    class Program
    {
        static void Main()
        {
            
            Student student1 = new Student(
                "Ivan Petrov",
                "12345"
            );

            
            Course course1 = new Course(
                "Introduction to Programming",
                "Assoc. Prof. Dr. Maria Ivanova"
            );

            
            course1.EnrollStudent(student1);
        }
    }
}
