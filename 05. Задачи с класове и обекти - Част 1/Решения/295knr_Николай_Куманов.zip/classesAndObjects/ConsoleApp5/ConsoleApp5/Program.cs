﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount ba = new BankAccount("bgn001", "Stoqn", 1000);
            ba.PrintBalance();
            ba.Deposit(120);
            ba.PrintBalance();
            ba.Withdraw(500);
            ba.PrintBalance();
            ba.Withdraw(900);
            
        }
    }
}
