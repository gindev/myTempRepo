﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class BankAccount
    {
        string id;
        string owner;
        decimal amount;

        public BankAccount(string id, string owner, decimal amount)
        {
            this.id = id;
            this.owner = owner;
            this.amount = amount;
        }

        public void Deposit(decimal amount)
        {
            this.amount += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (this.amount < amount)
            {
                Console.WriteLine("not enough cash!!!");
            }
            else
            {
                this.amount -= amount;
            }
        
        }

        public void PrintBalance()
        {
            Console.WriteLine(amount);
        }
    }
}
