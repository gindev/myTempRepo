﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Movie
    {
        string name;
        string genre;
        int duration;
        double rating;

        public Movie() { }
        public Movie(string name, string genre, int duration, double rating)
        {
            this.name = name;
            this.genre = genre;
            this.duration = duration;
            this.rating = rating;
        }

        public string Name { get => name; set => name = value; }
        public string Genre { get => genre; set => genre = value; }
        public int Duration { get => duration; set => duration = value; }
        public double Rating { get => rating; set => rating = value; }
    }
}
