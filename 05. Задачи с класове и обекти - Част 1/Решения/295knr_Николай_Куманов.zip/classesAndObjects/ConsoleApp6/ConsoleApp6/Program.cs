﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Movie> movies = new List<Movie>();

            for (int i = 1; i <= 5; i++)
            {
                Movie movie = new Movie();  

                Console.Write($"Въведете име на филм {i}: ");
                movie.Name = Console.ReadLine();

                Console.Write($"Въведете жанр на филм {i}: ");
                movie.Genre = Console.ReadLine();

                Console.Write($"Въведете продължителност на филм {i} (в минути): ");
                movie.Duration = int.Parse(Console.ReadLine());

                Console.Write($"Въведете оценка на филм {i}: ");
                movie.Rating = double.Parse(Console.ReadLine());

                movies.Add(movie);
                Console.WriteLine();
            }

            Console.WriteLine("--- Информация за всички филми ---");
            for (int i = 0; i < movies.Count; i++)
            {
                Console.WriteLine($"Филм {i + 1}: {movies[i].Name} | Жанр: {movies[i].Genre} | Продължителност: {movies[i].Duration} мин. | Оценка: {movies[i].Rating}");
            }

            Movie topMovie = movies[0];
            for (int i = 1; i < movies.Count; i++)
            {
                if (movies[i].Rating > topMovie.Rating)
                {
                    topMovie = movies[i];
                }
            }

            Console.WriteLine();
            Console.WriteLine("Филм с най-висока оценка:");
            Console.WriteLine($"{topMovie.Name} | Оценка: {topMovie.Rating}");

        }
    }
}
