﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Car
    {
        string brand;
        string model;
        int year;
        double maxSpeed;

        public Car(string brand, string model, int year, double maxSpeed)
        {
            this.brand = brand;
            this.model = model;
            this.year = year;
            this.maxSpeed = maxSpeed;
        }

        public void ShowCarInfo()
        {
            Console.WriteLine(brand + " " + model + " " + year + " " +  maxSpeed);
        }
    }
}
