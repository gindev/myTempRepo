﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car("Porche", "Panamera", 2025, 321);
            Car car2 = new Car("peugeot", "206", 2004, 161);
            Car car3 = new Car("BMW", "Q4", 2014, 201);

            car1.ShowCarInfo();
            car2.ShowCarInfo();
            car3.ShowCarInfo();
        }
    }
}
