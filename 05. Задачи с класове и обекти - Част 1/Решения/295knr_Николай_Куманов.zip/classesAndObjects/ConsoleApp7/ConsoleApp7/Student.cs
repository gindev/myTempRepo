﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Student
    {
        string name;
        string facultyNumber;

        public Student() { }

        public Student(string name, string facultyNumber)
        {
            this.name = name;
            this.facultyNumber = facultyNumber;
        }

        public string Name { get => name; set => name = value; }
        public string FacultyNumber { get => facultyNumber; set => facultyNumber = value; }
    }
}
