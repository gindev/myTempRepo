﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Course
    {
        string name;
        string lecturer;

        public Course() { }

        public Course(string name, string lecturer)
        {
            this.name = name;
            this.lecturer = lecturer;
        }

        public string Name { get => name; set => name = value; }
        public string Lecturer { get => lecturer; set => lecturer = value; }

        public void EnrollStudent(Student student)
        {
            Console.WriteLine($"Студент {student.Name} с ФН {student.FacultyNumber} е записан в курса \"{Name}\", воден от {Lecturer}.");
        }


    }
}
