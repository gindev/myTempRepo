﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student.Name = "Иван";
            student.FacultyNumber = "кн125";

            Course course = new Course();
            course.Name = "Увод в програмирането";
            course.Lecturer = "Мария Иванова";

            course.EnrollStudent(student);
        }
    }
}
