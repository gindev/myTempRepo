﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Book
    {
        string title;
        string author;
        int year;
        int pages;

        public Book(string title, string author, int year, int pages)
        {
            this.title = title;
            this.author = author;
            this.year = year;
            this.pages = pages;
        }

        public void PrintInfo()
        {
            Console.WriteLine(title + " " + author + " " + year + " " + pages);
        }
    }
}
