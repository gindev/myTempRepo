﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book bk1 = new Book("1984", "George Orwell", 1949, 328);
            Book bk2 = new Book("A Game of Thrones", "George R. R. Martin", 1996, 694);

            bk1.PrintInfo();
            bk2.PrintInfo();

        }
    }
}
