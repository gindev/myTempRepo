﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student st = new Student("Ivan","Ivanov", "295knr", "komp nauki");
            Console.WriteLine(st);
        }
    }
}
