﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Student
    {
        string name;
        string familyName;
        string facultyNumber;
        string specialty;

        public Student(string name, string familyName, string facultyNumber, string specialty)
        {
            this.name = name;
            this.familyName = familyName;
            this.facultyNumber = facultyNumber;
            this.specialty = specialty;
        }

        public override string ToString()
        {
            return name + " " + familyName + " " + facultyNumber + " " + specialty;
        }
    }
}
