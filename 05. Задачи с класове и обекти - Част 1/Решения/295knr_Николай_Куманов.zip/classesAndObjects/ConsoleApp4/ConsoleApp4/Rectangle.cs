﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Rectangle
    {
        int width;
        int height;
        

        public Rectangle( int width, int height)
        {
            this.width = width;
            this.height = height;
        } 

        public int GetArea()
        {
            return height*width;
        }

        public int GetPerimeter()
        {
            return 2*width + 2*height;
        }

        public void PrintInfo()
        {
            Console.WriteLine(width + " " + height + " " + GetArea() + " " + GetPerimeter() );
        }
    }
}
