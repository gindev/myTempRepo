﻿using Zadacha_1;

Student student = new Student();
student.firstName = "Иван";
student.lastName = "Петров";
student.facultyNumber = "12345";
student.specialty = "Информационни системи";

Console.WriteLine($"Име: {student.firstName}");
Console.WriteLine($"Фамилия: {student.lastName}");
Console.WriteLine($"Факултетен номер: {student.facultyNumber}");
Console.WriteLine($"Специалност: {student.specialty}");