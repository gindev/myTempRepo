﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Student
    {
        public string firstName;
        public string lastName;
        public string facultyNumber;
        public string specialty;
    }
}
