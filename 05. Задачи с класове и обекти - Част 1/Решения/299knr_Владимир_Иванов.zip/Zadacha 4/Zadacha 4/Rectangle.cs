﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class Rectangle
    {
        public double Width;
        public double Height;

        public double GetArea()
        {
            return Width * Height;
        }
        public double GetPerimeter()
        {
            return 2 * (Width + Height);
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Ширина: {Width}");
            Console.WriteLine($"Височина: {Height}");
            Console.WriteLine($"Лице: {GetArea()}");
            Console.WriteLine($"Периметър: {GetPerimeter()}");
        }
    }
}
