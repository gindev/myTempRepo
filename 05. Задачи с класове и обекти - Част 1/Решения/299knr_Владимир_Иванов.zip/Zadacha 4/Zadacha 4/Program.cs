﻿using Zadacha_4;

Console.Write("Въведете ширина: ");
double width = double.Parse(Console.ReadLine());

Console.Write("Въведете височина: ");
double height = double.Parse(Console.ReadLine());

Rectangle rect = new Rectangle();
rect.Width = width;
rect.Height = height;

rect.PrintInfo();