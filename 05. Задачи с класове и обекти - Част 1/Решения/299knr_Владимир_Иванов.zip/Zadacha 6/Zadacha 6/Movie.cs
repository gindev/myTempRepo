﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_6
{
    internal class Movie
    {
        public string Title;
        public string Genre;
        public int DurationMinutes;
        public double Rating;

        public void PrintInfo(int index)
        {
            Console.WriteLine(
                $"Филм {index}: {Title} | Жанр: {Genre} | " +
                $"Продължителност: {DurationMinutes} мин. | Оценка: {Rating}");
        }
    }
}
