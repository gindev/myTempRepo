﻿using Zadacha_6;

Movie[] movies = new Movie[5];

for (int i = 0; i < movies.Length; i++)
{
    movies[i] = new Movie();
    Console.WriteLine($"Филм {i + 1}: ");

    Console.Write("Име: ");
    movies[i].Title = Console.ReadLine();

    Console.Write("Жанр: ");
    movies[i].Genre = Console.ReadLine();

    Console.Write("Продължителност (мин.): ");
    movies[i].DurationMinutes = int.Parse(Console.ReadLine());

    Console.Write("Оценка: ");
    movies[i].Rating = double.Parse(Console.ReadLine());

    Console.WriteLine();
}

Console.WriteLine("=== Всички филми ===");
for (int i = 0; i < movies.Length; i++)
    movies[i].PrintInfo(i + 1);

Movie best = movies[0];
foreach (Movie m in movies)
    if (m.Rating > best.Rating)
        best = m;

Console.WriteLine("\nФилм с най-висока оценка:");
Console.WriteLine($"{best.Title} | Оценка: {best.Rating}");