﻿using Zadacha_3;

Car car1 = new Car("Toyota", "Corolla", 2020, 180);
Car car2 = new Car("BMW", "X5", 2022, 240);

car1.ShowCarInfo();
car2.ShowCarInfo();