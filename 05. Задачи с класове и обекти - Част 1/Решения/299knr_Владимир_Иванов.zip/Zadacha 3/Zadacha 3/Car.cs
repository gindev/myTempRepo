﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class Car
    {
        public string Brand;
        public string Model;
        public int Year;
        public int MaxSpeed;

        public Car(string brand, string model, int year, int maxSpeed)
        {
            Brand = brand;
            Model = model;
            Year = year;
            MaxSpeed = maxSpeed;
        }

        public void ShowCarInfo()
        {
            Console.WriteLine($"Марка: {Brand}");
            Console.WriteLine($"Модел: {Model}");
            Console.WriteLine($"Година: {Year}");
            Console.WriteLine($"Максимална скорост: {MaxSpeed} км/ч");
            Console.WriteLine();
        }
    }
}
