﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal class Bank_Account
    {
        public string AccountNumber;
        public string HolderName;
        public decimal Balance;

        public void Deposit(decimal amount)
        {
            Balance += amount;
            Console.WriteLine($"Внесена сума: {amount:F2}");
        }

        public void Withdraw(decimal amount)
        {
            if (amount > Balance)
            {
                Console.WriteLine("Недостатъчна наличност!");
            }
            else
            {
                Balance -= amount;
                Console.WriteLine($"Изтеглена сума: {amount:F2}");
            }
        }

        public void PrintBalance()
        {
            Console.WriteLine($"Текуща наличност: {Balance:F2}");
        }
    }
}
