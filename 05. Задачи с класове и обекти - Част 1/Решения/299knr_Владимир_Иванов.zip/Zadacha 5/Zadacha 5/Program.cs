﻿using Zadacha_5;

Bank_Account account = new Bank_Account();
account.AccountNumber = "BG80";
account.HolderName = "Иван Петров";

Console.Write("Начална наличност: ");
account.Balance = decimal.Parse(Console.ReadLine());
Console.WriteLine($"Начална наличност: {account.Balance:F2}");

Console.Write("Сума за внасяне: ");
decimal depositAmount = decimal.Parse(Console.ReadLine());
account.Deposit(depositAmount);

Console.Write("Сума за теглене: ");
decimal withdrawAmount = decimal.Parse(Console.ReadLine());
account.Withdraw(withdrawAmount);

account.PrintBalance();