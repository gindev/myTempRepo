﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha7
{
    internal class Student
    {
        public string FirstName;
        public string FacultyNumber;
    }
}
