﻿using Zadacha7;

    Student student = new Student();
    student.FirstName = "Иван Петров";
    student.FacultyNumber = "12345";

    Course course = new Course();
    course.CourseName = "Увод в програмирането";
    course.TeacherName = "доц. д-р Мария Иванова";

    course.EnrollStudent(student);