﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha7
{
    internal class Course
    {
        public string CourseName;
        public string TeacherName;

        public void EnrollStudent(Student student)
        {
            Console.WriteLine(
                $"Студент {student.FirstName} с ФН {student.FacultyNumber} " +
                $"е записан в курса \"{CourseName}\", воден от {TeacherName}.");
        }
    }
}
