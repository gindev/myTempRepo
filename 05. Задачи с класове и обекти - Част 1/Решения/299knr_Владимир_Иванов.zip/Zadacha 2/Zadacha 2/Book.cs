﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Book
    {
        public string Title;
        public string Author;
        public int Year;
        public int Pages;

        public void PrintInfo()
        {
            Console.WriteLine($"Заглавие: {Title}");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Година на издаване: {Year}");
            Console.WriteLine($"Брой страници: {Pages}");
            Console.WriteLine();
        }
    }
}
