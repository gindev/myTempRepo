﻿using Zadacha_2;

Book book1 = new Book();
book1.Title = "Под игото";
book1.Author = "Иван Вазов";
book1.Year = 1894;
book1.Pages = 350;

Book book2 = new Book();
book2.Title = "Немили-недраги";
book2.Author = "Иван Вазов";
book2.Year = 1883;
book2.Pages = 120;

book1.PrintInfo();
book2.PrintInfo();
