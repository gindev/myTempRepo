﻿namespace zadacha1
{
    using System;

    class Processor
    {
        public string Model { get; set; }
        public int Cores { get; set; }

        public Processor(string model, int cores)
        {
            Model = model;
            Cores = cores;
        }
    }

    class Memory
    {
        public int SizeGB { get; set; }
        public string Type { get; set; }

        public Memory(int sizeGB, string type)
        {
            SizeGB = sizeGB;
            Type = type;
        }
    }

    class Storage
    {
        public int SizeGB { get; set; }
        public string DeviceType { get; set; }

        public Storage(int sizeGB, string deviceType)
        {
            SizeGB = sizeGB;
            DeviceType = deviceType;
        }
    }

    class Computer
    {
        public string Brand { get; set; }
        public string Model { get; set; }

        public Processor Processor { get; set; }
        public Memory Memory { get; set; }
        public Storage Storage { get; set; }

        public Computer(string brand, string model,
                        Processor processor,
                        Memory memory,
                        Storage storage)
        {
            Brand = brand;
            Model = model;
            Processor = processor;
            Memory = memory;
            Storage = storage;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"\nComputer: {Brand} {Model}");
            Console.WriteLine($"Processor: {Processor.Model}, Cores: {Processor.Cores}");
            Console.WriteLine($"Memory: {Memory.SizeGB} GB, Type: {Memory.Type}");
            Console.WriteLine($"Storage: {Storage.SizeGB} GB, Type: {Storage.DeviceType}");
        }
    }

    class Program
    {
        static void Main()
        {
            Console.Write("Enter brand: ");
            string brand = Console.ReadLine();

            Console.Write("Enter model: ");
            string computerModel = Console.ReadLine();

            Console.Write("Enter processor model: ");
            string processorModel = Console.ReadLine();

            Console.Write("Enter number of cores: ");
            int cores = int.Parse(Console.ReadLine());

            Console.Write("Enter RAM size (GB): ");
            int ramSize = int.Parse(Console.ReadLine());

            Console.Write("Enter RAM type: ");
            string ramType = Console.ReadLine();

            Console.Write("Enter storage size (GB): ");
            int storageSize = int.Parse(Console.ReadLine());

            Console.Write("Enter storage type: ");
            string storageType = Console.ReadLine();

            Processor processor = new Processor(processorModel, cores);
            Memory memory = new Memory(ramSize, ramType);
            Storage storage = new Storage(storageSize, storageType);

            Computer computer = new Computer(
                brand,
                computerModel,
                processor,
                memory,
                storage
            );

            computer.PrintInfo();
        }
    }
}
