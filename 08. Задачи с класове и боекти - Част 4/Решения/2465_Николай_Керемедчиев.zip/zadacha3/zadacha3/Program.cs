﻿namespace zadacha3
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    namespace LibraryManagement
    {
        
        public class Author
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }

            public Author(string firstName, string lastName)
            {
                FirstName = firstName;
                LastName = lastName;
            }
        }

        
        public class Book
        {
            public string Title { get; set; }
            public int Year { get; set; }
            public Author Author { get; set; }

            public Book(string title, int year, Author author)
            {
                Title = title;
                Year = year;
                Author = author;
            }
        }

        
        public class LibraryService
        {
            private List<Book> books = new List<Book>();

            public void AddBook(Book book)
            {
                books.Add(book);
                Console.WriteLine("Book added successfully.");
            }

            public void ShowAllBooks()
            {
                if (books.Count == 0)
                {
                    Console.WriteLine("No books available.");
                    return;
                }

                Console.WriteLine("Book list:");

                foreach (var book in books)
                {
                    Console.WriteLine($"{book.Title} - {book.Author.FirstName} {book.Author.LastName} ({book.Year})");
                }
            }

            public void FindBooksByAuthor(string authorName)
            {
                var result = books.Where(b =>
                    b.Author.FirstName.ToLower() == authorName.ToLower());

                Console.WriteLine("Results:");

                foreach (var book in result)
                {
                    Console.WriteLine($"{book.Title} - {book.Author.FirstName} {book.Author.LastName} ({book.Year})");
                }
            }
        }

        
        internal class Program
        {
            static void Main(string[] args)
            {
                LibraryService libraryService = new LibraryService();

                while (true)
                {
                    Console.WriteLine("\n1. Add Book");
                    Console.WriteLine("2. Show All Books");
                    Console.WriteLine("3. Search By Author");
                    Console.WriteLine("4. Exit");

                    Console.Write("Choose option: ");
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.Write("Title: ");
                            string title = Console.ReadLine();

                            Console.Write("Year: ");
                            int year = int.Parse(Console.ReadLine());

                            Console.Write("Author First Name: ");
                            string firstName = Console.ReadLine();

                            Console.Write("Author Last Name: ");
                            string lastName = Console.ReadLine();

                            Author author = new Author(firstName, lastName);
                            Book book = new Book(title, year, author);

                            libraryService.AddBook(book);
                            break;

                        case "2":
                            libraryService.ShowAllBooks();
                            break;

                        case "3":
                            Console.Write("Enter author first name: ");
                            string authorName = Console.ReadLine();

                            libraryService.FindBooksByAuthor(authorName);
                            break;

                        case "4":
                            Console.WriteLine("Exiting...");
                            return;

                        default:
                            Console.WriteLine("Invalid option.");
                            break;
                    }
                }
            }
        }
    }
}
