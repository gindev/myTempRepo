﻿namespace zadacha5
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.Json;

    namespace StudentRegistryApp
    {
        public class Student
        {
            public string FirstName { get; set; } = string.Empty;
            public string LastName { get; set; } = string.Empty;
            public string FacultyNumber { get; set; } = string.Empty;
            public string Specialty { get; set; } = string.Empty;
            public double AverageGrade { get; set; }

            public override string ToString()
            {
                return $"{FirstName} {LastName} | FN: {FacultyNumber} | Specialty: {Specialty} | Average Grade: {AverageGrade:F2}";
            }
        }

        public class StudentRegistryService
        {
            private List<Student> students = new List<Student>();

            public void AddStudent(Student student)
            {
                students.Add(student);
                Console.WriteLine("Student added successfully.");
            }

            public void ShowAllStudents()
            {
                if (students.Count == 0)
                {
                    Console.WriteLine("No students found.");
                    return;
                }

                Console.WriteLine();
                Console.WriteLine("Student list:");

                for (int i = 0; i < students.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {students[i]}");
                }
            }

            public void SaveToJson(string filePath)
            {
                try
                {
                    var options = new JsonSerializerOptions
                    {
                        WriteIndented = true
                    };

                    string json = JsonSerializer.Serialize(students, options);
                    File.WriteAllText(filePath, json);

                    Console.WriteLine("Data saved successfully to JSON file.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error while saving data: {ex.Message}");
                }
            }

            public void LoadFromJson(string filePath)
            {
                try
                {
                    if (!File.Exists(filePath))
                    {
                        Console.WriteLine("JSON file not found.");
                        return;
                    }

                    string json = File.ReadAllText(filePath);
                    var loadedStudents = JsonSerializer.Deserialize<List<Student>>(json);

                    if (loadedStudents != null)
                    {
                        students = loadedStudents;
                        Console.WriteLine("Data loaded successfully from JSON file.");
                    }
                    else
                    {
                        Console.WriteLine("No data found in JSON file.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error while loading data: {ex.Message}");
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                StudentRegistryService service = new StudentRegistryService();

                while (true)
                {
                    Console.WriteLine();
                    Console.WriteLine("===== Student Registry Menu =====");
                    Console.WriteLine("1. Add student");
                    Console.WriteLine("2. Show all students");
                    Console.WriteLine("3. Save to JSON file");
                    Console.WriteLine("4. Load from JSON file");
                    Console.WriteLine("5. Exit");
                    Console.Write("Choose an option: ");

                    string choice = Console.ReadLine() ?? string.Empty;

                    switch (choice)
                    {
                        case "1":
                            AddStudentMenu(service);
                            break;

                        case "2":
                            service.ShowAllStudents();
                            break;

                        case "3":
                            {
                                Console.Write("Enter file path: ");
                                string savePath = Console.ReadLine() ?? "students.json";
                                service.SaveToJson(savePath);
                                break;
                            }

                        case "4":
                            {
                                Console.Write("Enter file path: ");
                                string loadPath = Console.ReadLine() ?? "students.json";
                                service.LoadFromJson(loadPath);
                                break;
                            }

                        case "5":
                            Console.WriteLine("Goodbye!");
                            return;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
            }

            static void AddStudentMenu(StudentRegistryService service)
            {
                Console.Write("First name: ");
                string firstName = Console.ReadLine() ?? string.Empty;

                Console.Write("Last name: ");
                string lastName = Console.ReadLine() ?? string.Empty;

                Console.Write("Faculty number: ");
                string facultyNumber = Console.ReadLine() ?? string.Empty;

                Console.Write("Specialty: ");
                string specialty = Console.ReadLine() ?? string.Empty;

                double averageGrade;
                while (true)
                {
                    Console.Write("Average grade: ");
                    string input = Console.ReadLine() ?? string.Empty;

                    if (double.TryParse(input, out averageGrade))
                        break;

                    Console.WriteLine("Invalid number. Please enter a valid average grade.");
                }

                Student student = new Student
                {
                    FirstName = firstName,
                    LastName = lastName,
                    FacultyNumber = facultyNumber,
                    Specialty = specialty,
                    AverageGrade = averageGrade
                };

                service.AddStudent(student);
            }
        }
    }
}
