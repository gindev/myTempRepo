﻿namespace zadacha4
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    namespace NotesApp
    {
        
        public class Note
        {
            public string Title { get; set; }
            public string Content { get; set; }
            public DateTime CreatedDate { get; set; }

            public Note(string title, string content)
            {
                Title = title;
                Content = content;
                CreatedDate = DateTime.Now;
            }

            public override string ToString()
            {
                return $"{Title} | {Content} | {CreatedDate}";
            }
        }

        
        public class NoteService
        {
            private List<Note> notes = new List<Note>();

            public void AddNote(Note note)
            {
                notes.Add(note);
                Console.WriteLine("Note added successfully.");
            }

            public void ShowAllNotes()
            {
                if (notes.Count == 0)
                {
                    Console.WriteLine("No notes available.");
                    return;
                }

                Console.WriteLine("\nList of Notes:");
                for (int i = 0; i < notes.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {notes[i]}");
                }
            }

            public void SaveToFile(string filePath)
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (var note in notes)
                    {
                        writer.WriteLine(note.Title);
                        writer.WriteLine(note.Content);
                        writer.WriteLine(note.CreatedDate);
                        writer.WriteLine(); 
                    }
                }

                Console.WriteLine("Data saved successfully to file.");
            }

            public void LoadFromFile(string filePath)
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine("File does not exist.");
                    return;
                }

                notes.Clear();

                string[] lines = File.ReadAllLines(filePath);

                for (int i = 0; i < lines.Length; i += 4)
                {
                    if (i + 2 < lines.Length)
                    {
                        string title = lines[i];
                        string content = lines[i + 1];
                        DateTime date = DateTime.Parse(lines[i + 2]);

                        Note note = new Note(title, content);
                        note.CreatedDate = date;
                        notes.Add(note);
                    }
                }

                Console.WriteLine("Data loaded successfully from file.");
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                NoteService service = new NoteService();
                string filePath = "notes.txt";

                while (true)
                {
                    Console.WriteLine("\nMENU:");
                    Console.WriteLine("1. Add Note");
                    Console.WriteLine("2. Show All Notes");
                    Console.WriteLine("3. Save to File");
                    Console.WriteLine("4. Load from File");
                    Console.WriteLine("5. Exit");
                    Console.Write("Choose an option: ");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.Write("Enter title: ");
                            string title = Console.ReadLine();

                            Console.Write("Enter content: ");
                            string content = Console.ReadLine();

                            Note newNote = new Note(title, content);
                            service.AddNote(newNote);
                            break;

                        case "2":
                            service.ShowAllNotes();
                            break;

                        case "3":
                            service.SaveToFile(filePath);
                            break;

                        case "4":
                            service.LoadFromFile(filePath);
                            break;

                        case "5":
                            return;

                        default:
                            Console.WriteLine("Invalid option. Try again.");
                            break;
                    }
                }
            }
        }
    }
}
