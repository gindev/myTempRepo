namespace NotesApp
{
    public class Note
    {
        public string Title { get; set; }
        public string Content { get; set; }
        public DateTime CreatedAt { get; set; }

        public Note(string title, string content)
        {
            Title = title;
            Content = content;
            CreatedAt = DateTime.Now;
        }

        public Note(string title, string content, DateTime createdAt)
        {
            Title = title;
            Content = content;
            CreatedAt = createdAt;
        }

        public override string ToString()
        {
            return $"[{CreatedAt:dd.MM.yyyy HH:mm}] {Title}: {Content}";
        }
    }
}
