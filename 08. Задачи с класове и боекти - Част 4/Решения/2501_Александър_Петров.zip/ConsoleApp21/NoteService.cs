namespace NotesApp
{
    public class NoteService
    {
        private List<Note> notes = new List<Note>();

        public void AddNote(Note note)
        {
            notes.Add(note);
            Console.WriteLine($"The note \"{note.Title}\" was added.");
        }

        public void ShowAllNotes()
        {
            if (notes.Count == 0)
            {
                Console.WriteLine("No saved notes.");
                return;
            }

            Console.WriteLine("\n=== All notes ===");
            for (int i = 0; i < notes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {notes[i]}");
            }
        }

        public void SaveToFile(string filePath)
        {
            if (notes.Count == 0)
            {
                Console.WriteLine("No notes to save.");
                return;
            }

            using StreamWriter writer = new StreamWriter(filePath);
            foreach (Note note in notes)
            {
                writer.WriteLine(note.Title);
                writer.WriteLine(note.Content);
                writer.WriteLine(note.CreatedAt.ToString("o")); 
                writer.WriteLine("---");
            }

            Console.WriteLine($"Added {notes.Count} notes in \"{filePath}\".");
        }

        public void LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"The file \"{filePath}\" doesn't exist.");
                return;
            }

            notes.Clear();
            string[] lines = File.ReadAllLines(filePath);
            int i = 0;

            while (i < lines.Length)
            {
                string title   = lines[i++];
                string content = i < lines.Length ? lines[i++] : "";
                string dateStr = i < lines.Length ? lines[i++] : "";
                if (i < lines.Length) i++; 

                if (DateTime.TryParse(dateStr, out DateTime createdAt))
                    notes.Add(new Note(title, content, createdAt));
            }

            Console.WriteLine($"Loaded {notes.Count} notes from \"{filePath}\".");
        }
    }
}
