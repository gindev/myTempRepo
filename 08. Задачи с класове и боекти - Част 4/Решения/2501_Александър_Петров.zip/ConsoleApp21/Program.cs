namespace NotesApp
{
    class Program
    {
        static void Main(string[] args)
        {
            NoteService service = new NoteService();
            const string defaultFile = "notes.txt";
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n==============================");
                Console.WriteLine("      NOTE MANAGEMENT  ");
                Console.WriteLine("==============================");
                Console.WriteLine("1. Add note");
                Console.WriteLine("2. Show notes");
                Console.WriteLine("3. Save to file");
                Console.WriteLine("4. Loading file");
                Console.WriteLine("5. Exit");
                Console.Write("\nChoose an option: ");

                string choice = Console.ReadLine()?.Trim();

                switch (choice)
                {
                    case "1":
                        Console.Write("Title: ");
                        string title = Console.ReadLine() ?? "";

                        Console.Write("Contents: ");
                        string content = Console.ReadLine() ?? "";

                        service.AddNote(new Note(title, content));
                        break;

                    case "2":
                        service.ShowAllNotes();
                        break;

                    case "3":
                        Console.Write($"File path [{defaultFile}]: ");
                        string savePath = Console.ReadLine()?.Trim();
                        if (string.IsNullOrEmpty(savePath)) savePath = defaultFile;
                        service.SaveToFile(savePath);
                        break;

                    case "4":
                        Console.Write($"File path [{defaultFile}]: ");
                        string loadPath = Console.ReadLine()?.Trim();
                        if (string.IsNullOrEmpty(loadPath)) loadPath = defaultFile;
                        service.LoadFromFile(loadPath);
                        service.ShowAllNotes();
                        break;

                    case "5":
                        Console.WriteLine("Bye!");
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please, choose between 1 and 5.");
                        break;
                }
            }
        }
    }
}
