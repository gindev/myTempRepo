namespace LibraryApp
{
    public class LibraryService
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine($"The book \"{book.Title}\" was added succesfully.");
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("No books in library.");
                return;
            }

            Console.WriteLine("\n=== All books ===");
            for (int i = 0; i < books.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {books[i]}");
            }
        }

        public void FindBooksByAuthor(string authorName)
        {
            var result = books.Where(b =>
                b.Author.FirstName.Contains(authorName, StringComparison.OrdinalIgnoreCase) ||
                b.Author.LastName.Contains(authorName, StringComparison.OrdinalIgnoreCase) ||
                b.Author.ToString().Contains(authorName, StringComparison.OrdinalIgnoreCase)
            ).ToList();

            if (result.Count == 0)
            {
                Console.WriteLine($"There's no books from the author \"{authorName}\".");
                return;
            }

            Console.WriteLine($"\n=== Books by \"{authorName}\" ===");
            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {result[i]}");
            }
        }
    }
}
