namespace LibraryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            LibraryService library = new LibraryService();

            library.AddBook(new Book("Pod igoto", 1894, new Author("Ivan", "Vazov")));
            library.AddBook(new Book("Nemili-Nedragi", 1883, new Author("Ivan", "Vazov")));
            library.AddBook(new Book("Bai Ganio", 1895, new Author("Aleko", "Konstantinov")));

            bool running = true;

            while (running)
            {
                Console.WriteLine("\n=============================");
                Console.WriteLine("    LIBRARY MANAGEMENT");
                Console.WriteLine("=============================");
                Console.WriteLine("1. Add book");
                Console.WriteLine("2. Show all books");
                Console.WriteLine("3. Search Author");
                Console.WriteLine("4. Exit");
                Console.Write("\nChoose an option: ");

                string choice = Console.ReadLine()?.Trim();

                switch (choice)
                {
                    case "1":
                        Console.Write("Title: ");
                        string title = Console.ReadLine();

                        Console.Write("Year of publication: ");
                        if (!int.TryParse(Console.ReadLine(), out int year))
                        {
                            Console.WriteLine("Invalid year!");
                            break;
                        }

                        Console.Write("First name of author: ");
                        string firstName = Console.ReadLine();

                        Console.Write("Last name of author: ");
                        string lastName = Console.ReadLine();

                        Author author = new Author(firstName, lastName);
                        Book book = new Book(title, year, author);
                        library.AddBook(book);
                        break;

                    case "2":
                        library.ShowAllBooks();
                        break;

                    case "3":
                        Console.Write("Enter first or last name of the author: ");
                        string authorName = Console.ReadLine();
                        library.FindBooksByAuthor(authorName);
                        break;

                    case "4":
                        Console.WriteLine("Bye!");
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please, choose between 1 and 4.");
                        break;
                }
            }
        }
    }
}
