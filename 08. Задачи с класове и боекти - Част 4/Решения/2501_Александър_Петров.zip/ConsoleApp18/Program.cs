﻿namespace ConsoleApp18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer("Aleksandar Petrov", "0888-123-456");

            Product laptop = new Product("Laptop Dell", 1499.99m);
            Product mouse = new Product("Mouse Logitech", 39.99m);
            Product keyboard = new Product("Keyboard", 59.99m);

            Order order = new Order(1001, customer);
            order.AddItem(new OrderItem(laptop, 1));
            order.AddItem(new OrderItem(mouse, 2));
            order.AddItem(new OrderItem(keyboard, 1));

            order.PrintOrderInfo();
        }

    }
}

