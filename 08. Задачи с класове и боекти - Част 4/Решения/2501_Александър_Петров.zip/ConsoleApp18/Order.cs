﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp18
{
    internal class Order
    {
        public int OrderNumber { get; set; }
        public Customer Customer { get; set; }
        private List<OrderItem> Items { get; set; }

        public Order(int orderNumber, Customer customer)
        {
            OrderNumber = orderNumber;
            Customer = customer;
            Items = new List<OrderItem>();
        }

        public void AddItem(OrderItem item)
        {
            Items.Add(item);
        }

        public decimal GetOrderTotal()
        {
            decimal total = 0;
            foreach (var item in Items)
            {
                total += item.GetTotalPrice();
            }
            return total;
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"========== Order Number #{OrderNumber} ==========");
            Console.WriteLine($"Customer:   {Customer.Name}");
            Console.WriteLine($"Phone:  {Customer.Phone}");
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine($"{"Product",-20} {"Price",8} {"How much",5} {"Ammount",10}");
            Console.WriteLine("--------------------------------------------");

            foreach (var item in Items)
            {
                Console.WriteLine($"{item.Product.Name,-20} {item.Product.Price,7:F2} {item.Quantity,4} {item.GetTotalPrice(),9:F2}");
            }

            Console.WriteLine("--------------------------------------------");
            Console.WriteLine($"{"TOTAL:",-20} {GetOrderTotal(),25:F2}");
            Console.WriteLine("============================================");
        }

    }
}
