using System.Text.Json;

namespace StudentRegistry
{
    public class StudentRegistryService
    {
        private List<Student> students = new List<Student>();

        private static readonly JsonSerializerOptions jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };

        public void AddStudent(Student student)
        {
            if (students.Any(s => s.FacultyNumber == student.FacultyNumber))
            {
                Console.WriteLine($"Student with faculty number \"{student.FacultyNumber}\" already exists!");
                return;
            }

            students.Add(student);
            Console.WriteLine($"Student {student.FirstName} {student.LastName} was registered succesfully.");
        }

        public void ShowAllStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("No students registered.");
                return;
            }

            Console.WriteLine($"\n=== All students ({students.Count}) ===");
            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {students[i]}");
            }
        }

        public void SaveToJson(string filePath)
        {
            if (students.Count == 0)
            {
                Console.WriteLine("No students to enroll.");
                return;
            }

            string json = JsonSerializer.Serialize(students, jsonOptions);
            File.WriteAllText(filePath, json);
            Console.WriteLine($"Registered {students.Count} student(s) in \"{filePath}\".");
        }

        public void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"File \"{filePath}\" doesn't exist.");
                return;
            }

            string json = File.ReadAllText(filePath);
            var loaded = JsonSerializer.Deserialize<List<Student>>(json, jsonOptions);

            if (loaded == null || loaded.Count == 0)
            {
                Console.WriteLine("File is empty or invalid.");
                return;
            }

            students = loaded;
            Console.WriteLine($"Load {students.Count} student(s) from \"{filePath}\".");
        }
    }
}
