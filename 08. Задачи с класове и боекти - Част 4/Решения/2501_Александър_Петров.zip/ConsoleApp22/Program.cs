namespace StudentRegistry
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentRegistryService registry = new StudentRegistryService();
            const string defaultFile = "students.json";
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n==============================");
                Console.WriteLine("    STUDENT REGISTER     ");
                Console.WriteLine("==============================");
                Console.WriteLine("1. Add student");
                Console.WriteLine("2. Show all students");
                Console.WriteLine("3. Add a JSON file");
                Console.WriteLine("4. Load a JSON file");
                Console.WriteLine("5. Exit");
                Console.Write("\nChoose an option: ");

                string choice = Console.ReadLine()?.Trim();

                switch (choice)
                {
                    case "1":
                        Console.Write("First name: ");
                        string firstName = Console.ReadLine() ?? "";

                        Console.Write("Last name: ");
                        string lastName = Console.ReadLine() ?? "";

                        Console.Write("Faculty number: ");
                        string facultyNumber = Console.ReadLine() ?? "";

                        Console.Write("Specialty: ");
                        string specialty = Console.ReadLine() ?? "";

                        Console.Write("Average grade: ");
                        if (!double.TryParse(Console.ReadLine()?.Replace(',', '.'),
                                System.Globalization.NumberStyles.Any,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out double grade) || grade < 2.0 || grade > 6.0)
                        {
                            Console.WriteLine("Invalid grade! It has to be between 2.00 and 6.00.");
                            break;
                        }

                        registry.AddStudent(new Student(firstName, lastName, facultyNumber, specialty, grade));
                        break;

                    case "2":
                        registry.ShowAllStudents();
                        break;

                    case "3":
                        Console.Write($"File path [{defaultFile}]: ");
                        string savePath = Console.ReadLine()?.Trim();
                        if (string.IsNullOrEmpty(savePath)) savePath = defaultFile;
                        registry.SaveToJson(savePath);
                        break;

                    case "4":
                        Console.Write($"File path [{defaultFile}]: ");
                        string loadPath = Console.ReadLine()?.Trim();
                        if (string.IsNullOrEmpty(loadPath)) loadPath = defaultFile;
                        registry.LoadFromJson(loadPath);
                        registry.ShowAllStudents();
                        break;

                    case "5":
                        Console.WriteLine("Bye!");
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please, choose between 1 and 5.");
                        break;
                }
            }
        }
    }
}
