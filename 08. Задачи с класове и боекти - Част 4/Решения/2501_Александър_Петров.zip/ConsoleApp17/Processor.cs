﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    internal class Processor
    {
        public string Model { get; set; }
        public int Cores { get; set; }
    }
}
