﻿namespace ConsoleApp17
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Computer pc = new Computer
            {
                Manufacturer = "Dell",
                Model = "Inspiron 5000",
                Processor = new Processor
                {
                    Model = "Intel Core i5-12400",
                    Cores = 6
                },
                Memory = new Memory
                {
                    SizeGB = 16,
                    Type = "DDR4"
                },
                Storage = new Storage
                {
                    SizeGB = 512,
                    DeviceType = "SSD"
                }
            };

            pc.PrintInfo();
        }
    }
}

