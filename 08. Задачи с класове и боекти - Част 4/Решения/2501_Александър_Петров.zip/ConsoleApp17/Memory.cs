﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    internal class Memory
    {
        public int SizeGB { get; set; }
        public string Type { get; set; }
    }
}
