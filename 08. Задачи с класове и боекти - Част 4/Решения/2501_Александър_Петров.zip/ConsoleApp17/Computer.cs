﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    internal class Computer
    {

        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public Processor Processor { get; set; }
        public Memory Memory { get; set; }
        public Storage Storage { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"Manufacturer: {Manufacturer}");
            Console.WriteLine($"Model: {Model}");
            Console.WriteLine();
            Console.WriteLine("=== Processor ===");
            Console.WriteLine($"Model: {Processor.Model}");
            Console.WriteLine($"Cores: {Processor.Cores}");
            Console.WriteLine();
            Console.WriteLine("=== Memory ===");
            Console.WriteLine($"Size: {Memory.SizeGB} GB");
            Console.WriteLine($"Type: {Memory.Type}");
            Console.WriteLine();
            Console.WriteLine("=== Storage ===");
            Console.WriteLine($"Size: {Storage.SizeGB} GB");
            Console.WriteLine($"Device Type: {Storage.DeviceType}");
        }
    }
}
