﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;


namespace classes_and_objects_part4_05
{
    internal class StudentRegistryService
    {
        private List<Student> students = new List<Student>();

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void ShowAllStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("Няма студенти.");
                return;
            }

            Console.WriteLine("\nСписък със студенти:");

            int index = 1;

            foreach (Student student in students)
            {
                Console.WriteLine($"{index}. {student.FirstName} {student.LastName}");
                Console.WriteLine($"ФН: {student.FacultyNumber}");
                Console.WriteLine($"Специалност: {student.Specialty}");
                Console.WriteLine($"Успех: {student.AverageGrade:F2}");
                Console.WriteLine();

                index++;
            }
        }

        public void SaveToJson(string filePath)
        {
            string json = JsonSerializer.Serialize(
                students,
                new JsonSerializerOptions { WriteIndented = true });

            File.WriteAllText(filePath, json);

            Console.WriteLine("Данните са записани успешно в JSON файл.");
        }

        public void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файлът не съществува.");
                return;
            }

            string json = File.ReadAllText(filePath);

            students = JsonSerializer.Deserialize<List<Student>>(json);

            Console.WriteLine("Данните са заредени успешно от JSON файл.");
        }
    }
}
