﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;

namespace classes_and_objects_part4_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentRegistryService service = new StudentRegistryService();

            int choice;

            do
            {
                Console.WriteLine("\n1. Добавяне на студент");
                Console.WriteLine("2. Показване на всички студенти");
                Console.WriteLine("3. Запис в JSON файл");
                Console.WriteLine("4. Зареждане от JSON файл");
                Console.WriteLine("5. Изход");

                Console.Write("Изберете опция: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:

                        Console.Write("Име: ");
                        string firstName = Console.ReadLine();

                        Console.Write("Фамилия: ");
                        string lastName = Console.ReadLine();

                        Console.Write("ФН: ");
                        string facultyNumber = Console.ReadLine();

                        Console.Write("Специалност: ");
                        string specialty = Console.ReadLine();

                        Console.Write("Среден успех: ");
                        double grade = double.Parse(Console.ReadLine());

                        Student student = new Student
                        {
                            FirstName = firstName,
                            LastName = lastName,
                            FacultyNumber = facultyNumber,
                            Specialty = specialty,
                            AverageGrade = grade
                        };

                        service.AddStudent(student);

                        Console.WriteLine("Студентът е добавен успешно.");
                        break;

                    case 2:
                        service.ShowAllStudents();
                        break;

                    case 3:

                        Console.Write("Име на JSON файл: ");
                        string savePath = Console.ReadLine();

                        service.SaveToJson(savePath);
                        break;

                    case 4:

                        Console.Write("Име на JSON файл: ");
                        string loadPath = Console.ReadLine();

                        service.LoadFromJson(loadPath);
                        break;

                    case 5:
                        Console.WriteLine("Изход...");
                        break;

                    default:
                        Console.WriteLine("Невалиден избор.");
                        break;
                }

            } while (choice != 5);
        }
    }
}
