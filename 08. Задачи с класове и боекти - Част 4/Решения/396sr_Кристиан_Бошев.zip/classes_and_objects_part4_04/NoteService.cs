﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_04
{
    internal class NoteService
    {
        private List<Note> notes = new List<Note>();

        public void AddNote(Note n1)
        {
            notes.Add(n1);
        }

        public void ShowAllNotes()
        {
            if (notes.Count == 0)
            {
                Console.WriteLine("Няма бележки.");
                return;
            }

            Console.WriteLine("\nСписък с бележки:");

            int index = 1;

            foreach (Note note in notes)
            {
                Console.WriteLine($"{index}. {note.Title}");
                Console.WriteLine(note.Content);
                Console.WriteLine($"Дата: {note.CreatedAt}");
                Console.WriteLine();

                index++;
            }
        }

        public void SaveToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (Note note in notes)
                {
                    writer.WriteLine(note.Title);
                    writer.WriteLine(note.Content);
                    writer.WriteLine(note.CreatedAt);
                    writer.WriteLine("---");
                }
            }

            Console.WriteLine("Данните са записани успешно във файл.");
        }

        public void LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файлът не съществува.");
                return;
            }

            notes.Clear();

            string[] lines = File.ReadAllLines(filePath);

            for (int i = 0; i < lines.Length; i += 4)
            {
                Note note = new Note
                {
                    Title = lines[i],
                    Content = lines[i + 1],
                    CreatedAt = DateTime.Parse(lines[i + 2])
                };

                notes.Add(note);
            }

            Console.WriteLine("Данните са заредени успешно от файл.");
        }
    }
}
