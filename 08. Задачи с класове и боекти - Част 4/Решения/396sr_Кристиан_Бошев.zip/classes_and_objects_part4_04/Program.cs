﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NoteService service = new NoteService();

            int choice;

            do
            {
                Console.WriteLine("\n1. Добавяне на бележка");
                Console.WriteLine("2. Показване на бележките");
                Console.WriteLine("3. Запис във файл");
                Console.WriteLine("4. Зареждане от файл");
                Console.WriteLine("5. Изход");

                Console.Write("Изберете опция: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:

                        Console.Write("Заглавие: ");
                        string title = Console.ReadLine();

                        Console.Write("Съдържание: ");
                        string content = Console.ReadLine();

                        Note note = new Note
                        {
                            Title = title,
                            Content = content,
                            CreatedAt = DateTime.Now
                        };

                        service.AddNote(note);

                        Console.WriteLine("Бележката е добавена успешно.");
                        break;

                    case 2:
                        service.ShowAllNotes();
                        break;

                    case 3:

                        Console.Write("Име на файл: ");
                        string savePath = Console.ReadLine();

                        service.SaveToFile(savePath);
                        break;

                    case 4:

                        Console.Write("Име на файл: ");
                        string loadPath = Console.ReadLine();

                        service.LoadFromFile(loadPath);
                        break;

                    case 5:
                        Console.WriteLine("Изход...");
                        break;

                    default:
                        Console.WriteLine("Невалиден избор.");
                        break;
                }

            } while (choice != 5);
        }
    }
}

