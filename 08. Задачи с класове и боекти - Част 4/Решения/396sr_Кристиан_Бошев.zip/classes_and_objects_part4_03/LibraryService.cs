﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_03
{
    internal class LibraryService
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Няма добавени книги.");
                return;
            }

            Console.WriteLine("\nСписък с книги:");

            foreach (Book book in books)
            {
                Console.WriteLine(
                    $"{book.Title} - " +
                    $"{book.Author.FirstName} {book.Author.LastName} " +
                    $"({book.Year})");
            }
        }

        public void FindBooksByAuthor(string authorName)
        {
            bool found = false;

            Console.WriteLine("\nРезултати:");

            foreach (Book book in books)
            {
                if (book.Author.FirstName.ToLower() == authorName.ToLower())
                {
                    Console.WriteLine(
                        $"{book.Title} - " +
                        $"{book.Author.FirstName} {book.Author.LastName} " +
                        $"({book.Year})");

                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Няма намерени книги.");
            }
        }
    }
}
