﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LibraryService library = new LibraryService();

            int choice;

            do
            {
                Console.WriteLine("\n1. Добавяне на книга");
                Console.WriteLine("2. Показване на всички книги");
                Console.WriteLine("3. Търсене по автор");
                Console.WriteLine("4. Изход");

                Console.Write("Изберете опция: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:

                        Console.Write("Заглавие: ");
                        string title = Console.ReadLine();

                        Console.Write("Година: ");
                        int year = int.Parse(Console.ReadLine());

                        Console.Write("Име на автор: ");
                        string firstName = Console.ReadLine();

                        Console.Write("Фамилия на автор: ");
                        string lastName = Console.ReadLine();

                        Author author = new Author
                        {
                            FirstName = firstName,
                            LastName = lastName
                        };

                        Book book = new Book
                        {
                            Title = title,
                            Year = year,
                            Author = author
                        };

                        library.AddBook(book);

                        Console.WriteLine("Книгата е добавена успешно.");
                        break;

                    case 2:
                        library.ShowAllBooks();
                        break;

                    case 3:

                        Console.Write("Въведете име на автор: ");
                        string searchName = Console.ReadLine();

                        library.FindBooksByAuthor(searchName);
                        break;

                    case 4:
                        Console.WriteLine("Изход...");
                        break;

                    default:
                        Console.WriteLine("Невалиден избор.");
                        break;
                }

            } while (choice != 4);
        }
    }
}
