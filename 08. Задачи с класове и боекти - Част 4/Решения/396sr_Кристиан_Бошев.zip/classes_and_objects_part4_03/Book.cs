﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_03
{
    internal class Book
    {
        public string Title { get; set; }
        public int Year { get; set; }

        public Author Author { get; set; }
    }
}
