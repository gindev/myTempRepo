﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_01
{
    internal class Computer
    {
        public string Brand { get; set; }
        public string Model { get; set; }

        public Processor Processor { get; set; }
        public Memory Memory { get; set; }
        public Storage Storage { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"\nКомпютър: {Brand} {Model}");
            Console.WriteLine($"Процесор: {Processor.Model}, Ядра: {Processor.Cores}");
            Console.WriteLine($"Памет: {Memory.SizeGB} GB, Тип: {Memory.MemoryType}");
            Console.WriteLine($"Устройство за съхранение: {Storage.SizeGB} GB, Тип: {Storage.StorageType}");
        }
    }
}
