﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_01
{
    internal class Storage
    {
        public int SizeGB { get; set; }
        public string StorageType { get; set; }
    }
}
