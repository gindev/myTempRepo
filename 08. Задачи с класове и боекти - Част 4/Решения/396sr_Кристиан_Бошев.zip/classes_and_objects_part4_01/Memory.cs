﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_01
{
    internal class Memory
    {
        public int SizeGB { get; set; }
        public string MemoryType { get; set; }
    }
}
