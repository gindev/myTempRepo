﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_01
{
    internal class Processor
    {
        public string Model { get; set; }
        public int Cores { get; set; }
    }
}

