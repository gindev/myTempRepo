﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете производител: ");
            string brand = Console.ReadLine();

            Console.Write("Въведете модел: ");
            string computerModel = Console.ReadLine();

            Console.Write("Въведете модел на процесора: ");
            string processorModel = Console.ReadLine();

            Console.Write("Въведете брой ядра: ");
            int cores = int.Parse(Console.ReadLine());

            Console.Write("Въведете размер на RAM: ");
            int ramSize = int.Parse(Console.ReadLine());

            Console.Write("Въведете тип RAM: ");
            string ramType = Console.ReadLine();

            Console.Write("Въведете размер на диска: ");
            int storageSize = int.Parse(Console.ReadLine());

            Console.Write("Въведете тип устройство: ");
            string storageType = Console.ReadLine();

            Processor processor = new Processor
            {
                Model = processorModel,
                Cores = cores
            };

            Memory memory = new Memory
            {
                SizeGB = ramSize,
                MemoryType = ramType
            };

            Storage storage = new Storage
            {
                SizeGB = storageSize,
                StorageType = storageType
            };

            Computer computer = new Computer
            {
                Brand = brand,
                Model = computerModel,
                Processor = processor,
                Memory = memory,
                Storage = storage
            };

            computer.PrintInfo();
        }

    }
}
