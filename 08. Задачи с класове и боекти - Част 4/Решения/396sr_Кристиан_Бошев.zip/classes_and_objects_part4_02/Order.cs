﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_02
{
    internal class Order
    {
        public int OrderNumber { get; set; }
        public Customer Customer { get; set; }

        public List<OrderItem> Items { get; set; }

        public Order()
        {
            Items = new List<OrderItem>();
        }

        public void AddItem(OrderItem item)
        {
            Items.Add(item);
        }

        public decimal GetOrderTotal()
        {
            decimal total = 0;

            foreach (OrderItem item in Items)
            {
                total += item.GetTotalPrice();
            }

            return total;
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"Поръчка №{OrderNumber}");
            Console.WriteLine($"Клиент: {Customer.Name}, Телефон: {Customer.Phone}");

            Console.WriteLine("\nПозиции:");

            int index = 1;

            foreach (OrderItem item in Items)
            {
                Console.WriteLine(
                    $"{index}. {item.Product.Name} | " +
                    $"{item.Quantity} бр. | " +
                    $"Ед. цена: {item.Product.Price:F2} | " +
                    $"Стойност: {item.GetTotalPrice():F2}");

                index++;
            }

            Console.WriteLine($"\nОбща стойност на поръчката: {GetOrderTotal():F2} лв.");
        }
    }
}
