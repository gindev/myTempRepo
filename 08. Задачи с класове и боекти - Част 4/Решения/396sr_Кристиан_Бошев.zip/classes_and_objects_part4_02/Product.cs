﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_02
{
    internal class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
