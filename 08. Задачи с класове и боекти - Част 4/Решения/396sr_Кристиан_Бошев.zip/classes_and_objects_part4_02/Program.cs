﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part4_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer
            {
                Name = "Иван Петров",
                Phone = "0888123456"
            };

            Product mouse = new Product
            {
                Name = "Мишка",
                Price = 25.00m
            };

            Product keyboard = new Product
            {
                Name = "Клавиатура",
                Price = 60.00m
            };

            Product monitor = new Product
            {
                Name = "Монитор",
                Price = 320.00m
            };

            Order order = new Order
            {
                OrderNumber = 5001,
                Customer = customer
            };

            order.AddItem(new OrderItem
            {
                Product = mouse,
                Quantity = 2
            });

            order.AddItem(new OrderItem
            {
                Product = keyboard,
                Quantity = 1
            });

            order.AddItem(new OrderItem
            {
                Product = monitor,
                Quantity = 1
            });

            order.PrintOrderInfo();
        }
    }
}
