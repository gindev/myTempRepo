﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise_4
{
    class Note
    {
        public string Title { get; set; }
        public string Content { get; set; }
        public DateTime CreatedOn { get; set; }

        public Note(string title, string content)
        {
            Title = title;
            Content = content;
            CreatedOn = DateTime.Now;
        }

        public Note(string title, string content, DateTime createdOn)
        {
            Title = title;
            Content = content;
            CreatedOn = createdOn;
        }
    }
}
