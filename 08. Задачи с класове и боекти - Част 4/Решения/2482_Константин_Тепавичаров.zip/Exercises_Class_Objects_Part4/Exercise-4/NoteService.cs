﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise_4
{
    class NoteService
    {
        private List<Note> notes = new List<Note>();

        public void AddNote(Note note)
        {
            notes.Add(note);
        }

        public void ShowAllNotes()
        {
            if (notes.Count == 0)
            {
                Console.WriteLine("No notes available.");
                return;
            }

            Console.WriteLine("\nNotes list:");
            int i = 1;

            foreach (var note in notes)
            {
                Console.WriteLine($"{i}. {note.Title} | {note.Content}");
                i++;
            }
        }

        public void SaveToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var note in notes)
                {
                    writer.WriteLine($"{note.Title}|{note.Content}|{note.CreatedOn}");
                }
            }

            Console.WriteLine("Data saved successfully to file.");
        }

        public void LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File not found.");
                return;
            }

            notes.Clear();

            string[] lines = File.ReadAllLines(filePath);

            foreach (var line in lines)
            {
                string[] parts = line.Split('|');

                string title = parts[0];
                string content = parts[1];
                DateTime date = DateTime.Parse(parts[2]);

                notes.Add(new Note(title, content, date));
            }

            Console.WriteLine("Data loaded successfully from file.");
        }
    }
}
