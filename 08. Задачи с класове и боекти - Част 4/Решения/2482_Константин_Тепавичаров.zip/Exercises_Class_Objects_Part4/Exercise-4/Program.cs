﻿namespace Exercise_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NoteService service = new NoteService();

            while (true)
            {
                Console.WriteLine("\n1. Add note");
                Console.WriteLine("2. Show notes");
                Console.WriteLine("3. Save to file");
                Console.WriteLine("4. Load from file");
                Console.WriteLine("5. Exit");
                Console.Write("Choose option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Title: ");
                        string title = Console.ReadLine();

                        Console.Write("Content: ");
                        string content = Console.ReadLine();

                        service.AddNote(new Note(title, content));
                        Console.WriteLine("Note added successfully.");
                        break;

                    case "2":
                        service.ShowAllNotes();
                        break;

                    case "3":
                        Console.Write("File path: ");
                        string savePath = Console.ReadLine();

                        service.SaveToFile(savePath);
                        break;

                    case "4":
                        Console.Write("File path: ");
                        string loadPath = Console.ReadLine();

                        service.LoadFromFile(loadPath);
                        break;

                    case "5":
                        return;

                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
        }
    }
}
