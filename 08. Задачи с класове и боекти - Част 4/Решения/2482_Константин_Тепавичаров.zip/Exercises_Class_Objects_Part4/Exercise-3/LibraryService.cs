﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise_3
{

    class LibraryService
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("No books available.");
                return;
            }

            Console.WriteLine("Book list:");

            foreach (var book in books)
            {
                Console.WriteLine($"{book.Title} - {book.Author.GetFullName()} ({book.Year})");
            }
        }

        public void FindBooksByAuthor(string authorName)
        {
            var results = books
                .Where(b => b.Author.FirstName.Equals(authorName, StringComparison.OrdinalIgnoreCase)
                         || b.Author.LastName.Equals(authorName, StringComparison.OrdinalIgnoreCase)
                         || b.Author.GetFullName().Equals(authorName, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (results.Count == 0)
            {
                Console.WriteLine("No books found for this author.");
                return;
            }

            Console.WriteLine("Results:");
            foreach (var book in results)
            {
                Console.WriteLine($"{book.Title} - {book.Author.GetFullName()} ({book.Year})");
            }
        }
    }
}
