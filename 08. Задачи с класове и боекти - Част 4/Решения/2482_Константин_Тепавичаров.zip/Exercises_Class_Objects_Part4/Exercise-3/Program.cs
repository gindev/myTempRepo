﻿namespace Exercise_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
                LibraryService library = new LibraryService();

                while (true)
                {
                    Console.WriteLine("\n1. Add book");
                    Console.WriteLine("2. Show all books");
                    Console.WriteLine("3. Search by author");
                    Console.WriteLine("4. Exit");
                    Console.Write("Choose option: ");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.Write("Title: ");
                            string title = Console.ReadLine();

                            Console.Write("Year: ");
                            int year = int.Parse(Console.ReadLine());

                            Console.Write("Author first name: ");
                            string firstName = Console.ReadLine();

                            Console.Write("Author last name: ");
                            string lastName = Console.ReadLine();

                            Author author = new Author(firstName, lastName);
                            Book book = new Book(title, year, author);

                            library.AddBook(book);

                            Console.WriteLine("Book added successfully.");
                            break;

                        case "2":
                            library.ShowAllBooks();
                            break;

                        case "3":
                            Console.Write("Enter author name: ");
                            string name = Console.ReadLine();

                            library.FindBooksByAuthor(name);
                            break;

                        case "4":
                            return;

                        default:
                            Console.WriteLine("Invalid option.");
                            break;
                    }
                }
        }
    }
}
