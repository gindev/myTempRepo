﻿namespace Exercise_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentRegistryService service = new StudentRegistryService();

            while (true)
            {
                Console.WriteLine("\n1. Add student");
                Console.WriteLine("2. Show all students");
                Console.WriteLine("3. Save to JSON");
                Console.WriteLine("4. Load from JSON");
                Console.WriteLine("5. Exit");
                Console.Write("Choose option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("First name: ");
                        string firstName = Console.ReadLine();

                        Console.Write("Last name: ");
                        string lastName = Console.ReadLine();

                        Console.Write("Faculty number: ");
                        string fn = Console.ReadLine();

                        Console.Write("Specialty: ");
                        string specialty = Console.ReadLine();

                        Console.Write("Average grade: ");
                        double grade = double.Parse(Console.ReadLine());

                        service.AddStudent(new Student(firstName, lastName, fn, specialty, grade));
                        Console.WriteLine("Student added successfully.");
                        break;

                    case "2":
                        service.ShowAllStudents();
                        break;

                    case "3":
                        Console.Write("File path: ");
                        string savePath = Console.ReadLine();

                        service.SaveToJson(savePath);
                        break;

                    case "4":
                        Console.Write("File path: ");
                        string loadPath = Console.ReadLine();

                        service.LoadFromJson(loadPath);
                        break;

                    case "5":
                        return;

                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
        }
    }
}
