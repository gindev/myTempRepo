﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace Exercise_5
{
    class StudentRegistryService
    {
        private List<Student> students = new List<Student>();

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void ShowAllStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("No students available.");
                return;
            }

            Console.WriteLine("\nStudent list:");

            int i = 1;
            foreach (var s in students)
            {
                Console.WriteLine($"{i}. {s.FirstName} {s.LastName} | FN: {s.FacultyNumber} | Specialty: {s.Specialty} | Grade: {s.AverageGrade:F2}");
                i++;
            }
        }

        public void SaveToJson(string filePath)
        {
            string json = JsonSerializer.Serialize(students, new JsonSerializerOptions
            {
                WriteIndented = true
            });

            File.WriteAllText(filePath, json);

            Console.WriteLine("Data saved successfully to JSON file.");
        }

        public void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File not found.");
                return;
            }

            string json = File.ReadAllText(filePath);
            students = JsonSerializer.Deserialize<List<Student>>(json) ?? new List<Student>();

            Console.WriteLine("Data loaded successfully from JSON file.");
        }
    }
}
