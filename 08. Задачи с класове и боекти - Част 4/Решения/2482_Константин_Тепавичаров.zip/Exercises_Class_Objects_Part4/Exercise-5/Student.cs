﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise_5
{
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }
        public double AverageGrade { get; set; }

        public Student() { }

        public Student(string firstName, string lastName, string facultyNumber, string specialty, double averageGrade)
        {
            FirstName = firstName;
            LastName = lastName;
            FacultyNumber = facultyNumber;
            Specialty = specialty;
            AverageGrade = averageGrade;
        }
    }
}
