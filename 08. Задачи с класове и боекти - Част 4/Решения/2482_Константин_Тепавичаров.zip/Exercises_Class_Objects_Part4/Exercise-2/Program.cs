﻿namespace Exercise_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer("Ivan Petrov", "0888123456");

            Product mouse = new Product("Mouse", 25.00m);
            Product keyboard = new Product("Keyboard", 60.00m);
            Product monitor = new Product("Monitor", 320.00m);

            Order order = new Order(5001, customer);

            order.AddItem(new OrderItem(mouse, 2));
            order.AddItem(new OrderItem(keyboard, 1));
            order.AddItem(new OrderItem(monitor, 1));

            order.PrintOrderInfo();
        }
        class Customer
        {
            public string Name { get; set; }
            public string Phone { get; set; }

            public Customer(string name, string phone)
            {
                Name = name;
                Phone = phone;
            }
        }

        class Product
        {
            public string Name { get; set; }
            public decimal Price { get; set; }

            public Product(string name, decimal price)
            {
                Name = name;
                Price = price;
            }
        }

        class OrderItem
        {
            public Product Product { get; set; }
            public int Quantity { get; set; }

            public OrderItem(Product product, int quantity)
            {
                Product = product;
                Quantity = quantity;
            }

            public decimal GetTotalPrice()
            {
                return Product.Price * Quantity;
            }
        }

        class Order
        {
            public int OrderNumber { get; set; }
            public Customer Customer { get; set; }
            public List<OrderItem> Items { get; set; }

            public Order(int orderNumber, Customer customer)
            {
                OrderNumber = orderNumber;
                Customer = customer;
                Items = new List<OrderItem>();
            }

            public void AddItem(OrderItem item)
            {
                Items.Add(item);
            }

            public decimal GetOrderTotal()
            {
                decimal total = 0;

                foreach (var item in Items)
                {
                    total += item.GetTotalPrice();
                }

                return total;
            }

            public void PrintOrderInfo()
            {
                Console.WriteLine($"Order #{OrderNumber}");
                Console.WriteLine($"Customer: {Customer.Name}, Phone: {Customer.Phone}\n");

                Console.WriteLine("Items:");

                int index = 1;
                foreach (var item in Items)
                {
                    Console.WriteLine($"{index}. {item.Product.Name} | {item.Quantity} pcs | Unit price: {item.Product.Price:F2} | Total: {item.GetTotalPrice():F2}");
                    index++;
                }

                Console.WriteLine($"\nTotal order value: {GetOrderTotal():F2} lv.");
            }
        }
    }
}
