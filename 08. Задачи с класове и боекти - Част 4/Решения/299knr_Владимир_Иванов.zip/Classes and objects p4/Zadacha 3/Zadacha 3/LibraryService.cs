﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class LibraryService
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine("Книгата е добавена успешно.");
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Няма добавени книги.");
                return;
            }

            Console.WriteLine("Списък с книги:");
            foreach (var book in books)
                Console.WriteLine(book);
        }

        public void FindBooksByAuthor(string authorName)
        {
            var results = new List<Book>();

            foreach (var book in books)
            {
                if (book.Author.FirstName.Contains(authorName, StringComparison.OrdinalIgnoreCase) ||
                    book.Author.LastName.Contains(authorName, StringComparison.OrdinalIgnoreCase))
                {
                    results.Add(book);
                }
            }

            if (results.Count == 0)
            {
                Console.WriteLine("Няма намерени книги.");
                return;
            }

            Console.WriteLine("Резултати:");
            foreach (var book in results)
                Console.WriteLine(book);
        }

    }
}
