﻿using Zadacha_3;

LibraryService service = new LibraryService();

while (true)
{
    Console.WriteLine();
    Console.WriteLine("1. Добавяне на книга");
    Console.WriteLine("2. Показване на всички книги");
    Console.WriteLine("3. Търсене по автор");
    Console.WriteLine("4. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            Console.Write("Заглавие: ");
            string title = Console.ReadLine();

            Console.Write("Година: ");
            int year = int.Parse(Console.ReadLine());

            Console.Write("Име на автор: ");
            string firstName = Console.ReadLine();

            Console.Write("Фамилия на автор: ");
            string lastName = Console.ReadLine();

            Author author = new Author(firstName, lastName);
            Book book = new Book(title, year, author);
            service.AddBook(book);
            break;

        case "2":
            service.ShowAllBooks();
            break;

        case "3":
            Console.Write("Търсене по автор: ");
            string name = Console.ReadLine();
            service.FindBooksByAuthor(name);
            break;

        case "4":
            return;

        default:
            Console.WriteLine("Невалидна опция.");
            break;
    }
}
