﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class Book
    {
        public string Title { get; set; }
        public int Year { get; set; }
        public Author Author { get; set; }

        public Book(string title, int year, Author author)
        {
            Title = title;
            Year = year;
            Author = author;
        }

        public override string ToString() => $"{Title} - {Author} ({Year})";
    }

}

