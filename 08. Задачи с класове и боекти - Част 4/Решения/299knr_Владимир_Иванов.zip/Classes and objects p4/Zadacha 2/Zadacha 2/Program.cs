﻿using Zadacha_2;

Customer customer = new Customer("Иван Петров", "0888123456");

Product mouse = new Product("Мишка", 25.00m);
Product keyboard = new Product("Клавиатура", 60.00m);
Product monitor = new Product("Монитор", 320.00m);

Order order = new Order(5001, customer);
order.AddItem(new OrderItem(mouse, 2));
order.AddItem(new OrderItem(keyboard, 1));
order.AddItem(new OrderItem(monitor, 1));

order.PrintOrderInfo();
