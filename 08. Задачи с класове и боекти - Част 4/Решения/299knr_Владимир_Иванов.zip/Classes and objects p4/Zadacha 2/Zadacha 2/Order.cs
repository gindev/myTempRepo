﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Order
    {
        public int OrderNumber { get; set; }
        public Customer Customer { get; set; }
        private List<OrderItem> items = new List<OrderItem>();

        public Order(int orderNumber, Customer customer)
        {
            OrderNumber = orderNumber;
            Customer = customer;
        }

        public void AddItem(OrderItem item)
        {
            items.Add(item);
        }

        public decimal GetOrderTotal()
        {
            decimal total = 0;
            foreach (var item in items)
                total += item.GetTotalPrice();
            return total;
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"Поръчка №{OrderNumber}");
            Console.WriteLine($"Клиент: {Customer.Name}, Телефон: {Customer.Phone}");
            Console.WriteLine();
            Console.WriteLine("Позиции:");
            for (int i = 0; i < items.Count; i++)
            {
                var item = items[i];
                Console.WriteLine($"{i + 1}. {item.Product.Name} | {item.Quantity} бр. | Ед. цена: {item.Product.Price:F2} | Стойност: {item.GetTotalPrice():F2}");
            }
            Console.WriteLine();
            Console.WriteLine($"Обща стойност на поръчката: {GetOrderTotal():F2} лв.");
        }

    }
}
