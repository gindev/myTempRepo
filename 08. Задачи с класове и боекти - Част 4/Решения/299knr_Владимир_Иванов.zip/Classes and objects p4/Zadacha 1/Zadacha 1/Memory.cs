﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Memory
    {
        public int SizeGB { get; set; }
        public string Type { get; set; }

        public Memory(int sizeGB, string type)
        {
            SizeGB = sizeGB;
            Type = type;
        }

    }
}
