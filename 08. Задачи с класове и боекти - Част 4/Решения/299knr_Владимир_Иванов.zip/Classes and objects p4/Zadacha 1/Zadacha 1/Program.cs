﻿using Zadacha_1;

Console.Write("Въведете производител: ");
string manufacturer = Console.ReadLine();

Console.Write("Въведете модел: ");
string model = Console.ReadLine();

Console.Write("Въведете модел на процесора: ");
string cpuModel = Console.ReadLine();

Console.Write("Въведете брой ядра: ");
int cores = int.Parse(Console.ReadLine());

Console.Write("Въведете размер на RAM: ");
int ramSize = int.Parse(Console.ReadLine());

Console.Write("Въведете тип RAM: ");
string ramType = Console.ReadLine();

Console.Write("Въведете размер на диска: ");
int diskSize = int.Parse(Console.ReadLine());

Console.Write("Въведете тип устройство: ");
string diskType = Console.ReadLine();

Processor processor = new Processor(cpuModel, cores);
Memory memory = new Memory(ramSize, ramType);
Storage storage = new Storage(diskSize, diskType);
Computer computer = new Computer(manufacturer, model, processor, memory, storage);

Console.WriteLine();
computer.PrintInfo();
