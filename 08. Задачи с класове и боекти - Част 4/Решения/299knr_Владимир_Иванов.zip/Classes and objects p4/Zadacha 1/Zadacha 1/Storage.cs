﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Storage
    {
        public int SizeGB { get; set; }
        public string DeviceType { get; set; }

        public Storage(int sizeGB, string deviceType)
        {
            SizeGB = sizeGB;
            DeviceType = deviceType;
        }

    }
}
