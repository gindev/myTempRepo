﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Computer
    {
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public Processor Processor { get; set; }
        public Memory Memory { get; set; }
        public Storage Storage { get; set; }

        public Computer(string manufacturer, string model, Processor processor, Memory memory, Storage storage)
        {
            Manufacturer = manufacturer;
            Model = model;
            Processor = processor;
            Memory = memory;
            Storage = storage;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Компютър: {Manufacturer} {Model}");
            Console.WriteLine($"Процесор: {Processor.Model}, Ядра: {Processor.Cores}");
            Console.WriteLine($"Памет: {Memory.SizeGB} GB, Тип: {Memory.Type}");
            Console.WriteLine($"Устройство за съхранение: {Storage.SizeGB} GB, Тип: {Storage.DeviceType}");

        }


    }
}
