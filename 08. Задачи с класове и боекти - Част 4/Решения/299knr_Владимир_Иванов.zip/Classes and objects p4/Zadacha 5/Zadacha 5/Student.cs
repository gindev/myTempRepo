﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }
        public double GPA { get; set; }

        public Student() { } 

        public Student(string firstName, string lastName, string facultyNumber, string specialty, double gpa)
        {
            FirstName = firstName;
            LastName = lastName;
            FacultyNumber = facultyNumber;
            Specialty = specialty;
            GPA = gpa;
        }

        public override string ToString() =>
            $"{FirstName} {LastName} | ФН: {FacultyNumber} | Специалност: {Specialty} | Успех: {GPA:F2}";

    }
}
