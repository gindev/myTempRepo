﻿using Zadacha_5;
using System.Text.Encodings.Web;
using System.Text.Unicode;

StudentRegistryService service = new StudentRegistryService();

while (true)
{
    Console.WriteLine();
    Console.WriteLine("1. Добавяне на студент");
    Console.WriteLine("2. Показване на всички студенти");
    Console.WriteLine("3. Запис в JSON файл");
    Console.WriteLine("4. Зареждане от JSON файл");
    Console.WriteLine("5. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            Console.Write("Име: ");
            string firstName = Console.ReadLine();
            Console.Write("Фамилия: ");
            string lastName = Console.ReadLine();
            Console.Write("ФН: ");
            string fn = Console.ReadLine();
            Console.Write("Специалност: ");
            string specialty = Console.ReadLine();
            Console.Write("Среден успех: ");
            double gpa = double.Parse(Console.ReadLine());
            service.AddStudent(new Student(firstName, lastName, fn, specialty, gpa));
            break;

        case "2":
            service.ShowAllStudents();
            break;

        case "3":
            Console.Write("Път до файл: ");
            string savePath = Console.ReadLine();
            service.SaveToJson(savePath);
            break;

        case "4":
            Console.Write("Път до файл: ");
            string loadPath = Console.ReadLine();
            service.LoadFromJson(loadPath);
            break;

        case "5":
            return;

        default:
            Console.WriteLine("Невалидна опция.");
            break;
    }
}
