﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class NoteService
    {
        private List<Note> notes = new List<Note>();

        public void AddNote(Note note)
        {
            notes.Add(note);
            Console.WriteLine("Бележката е добавена успешно.");
        }

        public void ShowAllNotes()
        {
            if (notes.Count == 0)
            {
                Console.WriteLine("Няма добавени бележки.");
                return;
            }
            Console.WriteLine("Списък с бележки:");
            for (int i = 0; i < notes.Count; i++)
                Console.WriteLine($"{i + 1}. {notes[i]}");
        }
        public void SaveToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath, false))
            {
                foreach (var note in notes)
                {
                    writer.WriteLine(note.Title);
                    writer.WriteLine(note.Content);
                    writer.WriteLine(note.CreatedAt.ToString("O")); 
                    writer.WriteLine("---");
                }
            }
            Console.WriteLine("Данните са записани успешно във файл.");
        }

        public void LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файлът не съществува.");
                return;
            }

            notes.Clear();
            string[] lines = File.ReadAllLines(filePath);
            int i = 0;
            while (i + 3 <= lines.Length)
            {
                string title = lines[i];
                string content = lines[i + 1];
                DateTime createdAt = DateTime.Parse(lines[i + 2]);
                notes.Add(new Note(title, content, createdAt));
                i += 4; // skip "---"
            }
            Console.WriteLine("Данните са заредени успешно от файл.");
        }

    }
}
