﻿using Zadacha_4;

NoteService service = new NoteService();

while (true)
{
    Console.WriteLine();
    Console.WriteLine("1. Добавяне на бележка");
    Console.WriteLine("2. Показване на бележките");
    Console.WriteLine("3. Запис във файл");
    Console.WriteLine("4. Зареждане от файл");
    Console.WriteLine("5. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            Console.Write("Заглавие: ");
            string title = Console.ReadLine();
            Console.Write("Съдържание: ");
            string content = Console.ReadLine();
            service.AddNote(new Note(title, content));
            break;

        case "2":
            service.ShowAllNotes();
            break;

        case "3":
            Console.Write("Път до файл: ");
            string savePath = Console.ReadLine();
            service.SaveToFile(savePath);
            break;

        case "4":
            Console.Write("Път до файл: ");
            string loadPath = Console.ReadLine();
            service.LoadFromFile(loadPath);
            break;

        case "5":
            return;

        default:
            Console.WriteLine("Невалидна опция.");
            break;
    }
}