﻿namespace Task2
{
    public class Order
    {
        public string OrderNumber { get; set; }
        public Customer Customer { get; set; }
        public List<OrderItem> Items { get; set; }

        public Order()
        {
            Items = new List<OrderItem>();
        }

        public void AddItem(OrderItem item)
        {
            Items.Add(item);
        }

        public decimal GetOrderTotal()
        {
            return Items.Sum(item => item.GetTotalPrice());
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"Поръчка №{OrderNumber}");
            Console.WriteLine($"Клиент: {Customer.Name}, Телефон: {Customer.Phone}\n");

            Console.WriteLine("Позиции:");
            for (int i = 0; i < Items.Count; i++)
            {
                var item = Items[i];
                Console.WriteLine($"{i + 1}. {item.Product.Name} | {item.Quantity} бр. | Ед. цена: {item.Product.Price:F2} | Стойност: {item.GetTotalPrice():F2}");
            }

            Console.WriteLine($"\nОбща стойност на поръчката: {GetOrderTotal():F2} лв.");
        }
    }
}
