﻿using Task2;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Customer customer = new Customer
{
    Name = "Иван Петров",
    Phone = "0888123456"
};

Product mouse = new Product { Name = "Мишка", Price = 25.00m };
Product keyboard = new Product { Name = "Клавиатура", Price = 60.00m };
Product monitor = new Product { Name = "Монитор", Price = 320.00m };

Order order = new Order
{
    OrderNumber = "5001",
    Customer = customer
};

order.AddItem(new OrderItem { Product = mouse, Quantity = 2 });
order.AddItem(new OrderItem { Product = keyboard, Quantity = 1 });
order.AddItem(new OrderItem { Product = monitor, Quantity = 1 });

order.PrintOrderInfo();