﻿namespace Task3.Models
{
    public class Book
    {
        public string Title { get; set; }
        public int Year { get; set; }
        public Author Author { get; set; }
    }
}
