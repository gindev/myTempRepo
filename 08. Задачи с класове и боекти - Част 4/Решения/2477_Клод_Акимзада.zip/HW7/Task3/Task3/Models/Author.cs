﻿namespace Task3.Models
{
    public class Author
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
