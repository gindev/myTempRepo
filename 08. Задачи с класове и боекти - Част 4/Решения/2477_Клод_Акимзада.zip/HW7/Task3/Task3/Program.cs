﻿using Task3.Models;
using Task3.Services;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

LibraryService libraryService = new LibraryService();
bool isRunning = true;

while (isRunning)
{
    Console.WriteLine("\n1. Добавяне на книга");
    Console.WriteLine("2. Показване на всички книги");
    Console.WriteLine("3. Търсене по автор");
    Console.WriteLine("4. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1":
            Book newBook = new Book();
            newBook.Author = new Author();

            Console.Write("Заглавие: ");
            newBook.Title = Console.ReadLine();

            Console.Write("Година: ");
            newBook.Year = int.Parse(Console.ReadLine());

            Console.Write("Име на автор: ");
            newBook.Author.FirstName = Console.ReadLine();

            Console.Write("Фамилия на автор: ");
            newBook.Author.LastName = Console.ReadLine();

            Console.WriteLine();
            libraryService.AddBook(newBook);
            break;

        case "2":
            libraryService.ShowAllBooks();
            break;

        case "3":
            Console.Write("Въведете име за търсене: ");
            string searchAuthor = Console.ReadLine();

            Console.WriteLine();
            libraryService.FindBooksByAuthor(searchAuthor);
            break;

        case "4":
            isRunning = false;
            break;

        default:
            break;
    }
}