﻿using Task3.Models;

namespace Task3.Services
{
    public class LibraryService
    {
        private List<Book> books;

        public LibraryService()
        {
            books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine("Книгата е добавена успешно.");
        }

        public void ShowAllBooks()
        {
            Console.WriteLine("Списък с книги:");
            foreach (var book in books)
            {
                Console.WriteLine($"{book.Title} - {book.Author.FirstName} {book.Author.LastName} ({book.Year})");
            }
        }

        public void FindBooksByAuthor(string authorName)
        {
            Console.WriteLine("Резултати:");

            var foundBooks = books.Where(b =>
                b.Author.FirstName.Contains(authorName, StringComparison.OrdinalIgnoreCase) ||
                b.Author.LastName.Contains(authorName, StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var book in foundBooks)
            {
                Console.WriteLine($"{book.Title} - {book.Author.FirstName} {book.Author.LastName} ({book.Year})");
            }
        }
    }
}
