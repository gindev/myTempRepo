﻿using System.Text.Json;

namespace Task5
{
    public class StudentRegistryService
    {
        private List<Student> students;

        public StudentRegistryService()
        {
            students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            students.Add(student);
            Console.WriteLine("Студентът е добавен успешно.");
        }

        public void ShowAllStudents()
        {
            Console.WriteLine("Списък със студенти:");
            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {students[i].FirstName} {students[i].LastName} | ФН: {students[i].FacultyNumber} | Специалност: {students[i].Specialty} | Успех: {students[i].AverageGrade:F2}");
            }
        }

        public void SaveToJson(string filePath)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(students, options);
            File.WriteAllText(filePath, jsonString);

            Console.WriteLine("Данните са записани успешно в JSON файл.");
        }

        public void LoadFromJson(string filePath)
        {
            if (File.Exists(filePath))
            {
                string jsonString = File.ReadAllText(filePath);
                students = JsonSerializer.Deserialize<List<Student>>(jsonString);

                Console.WriteLine("Данните са заредени успешно от JSON файл.");
            }
            else
            {
                Console.WriteLine("Файлът не съществува.");
            }
        }
    }
}
