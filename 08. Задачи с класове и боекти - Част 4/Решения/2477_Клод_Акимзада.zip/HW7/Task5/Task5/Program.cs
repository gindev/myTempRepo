﻿using Task5;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

StudentRegistryService service = new StudentRegistryService();
bool isRunning = true;

while (isRunning)
{
    Console.WriteLine("\n1. Добавяне на студент");
    Console.WriteLine("2. Показване на всички студенти");
    Console.WriteLine("3. Запис в JSON файл");
    Console.WriteLine("4. Зареждане от JSON файл");
    Console.WriteLine("5. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1":
            Student student = new Student();

            Console.Write("Име: ");
            student.FirstName = Console.ReadLine();

            Console.Write("Фамилия: ");
            student.LastName = Console.ReadLine();

            Console.Write("ФН: ");
            student.FacultyNumber = Console.ReadLine();

            Console.Write("Специалност: ");
            student.Specialty = Console.ReadLine();

            Console.Write("Среден успех: ");
            student.AverageGrade = double.Parse(Console.ReadLine());

            Console.WriteLine();
            service.AddStudent(student);
            break;

        case "2":
            service.ShowAllStudents();
            break;

        case "3":
            Console.Write("Въведете име на файл: ");
            string savePath = Console.ReadLine();

            Console.WriteLine();
            service.SaveToJson(savePath);
            break;

        case "4":
            Console.Write("Въведете име на файл: ");
            string loadPath = Console.ReadLine();

            Console.WriteLine();
            service.LoadFromJson(loadPath);
            break;

        case "5":
            isRunning = false;
            break;

        default:
            break;
    }
}