﻿namespace Task5
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }
        public double AverageGrade { get; set; }
    }
}
