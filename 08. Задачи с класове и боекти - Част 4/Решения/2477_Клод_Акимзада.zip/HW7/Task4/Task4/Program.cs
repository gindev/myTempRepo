﻿using Task4;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

NotesService service = new NotesService();
bool isRunning = true;

while (isRunning)
{
    Console.WriteLine("\n1. Добавяне на бележка");
    Console.WriteLine("2. Показване на бележките");
    Console.WriteLine("3. Запис във файл");
    Console.WriteLine("4. Зареждане от файл");
    Console.WriteLine("5. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1":
            Note note = new Note();

            Console.Write("Заглавие: ");
            note.Title = Console.ReadLine();

            Console.Write("Съдържание: ");
            note.Content = Console.ReadLine();

            note.CreationDate = DateTime.Now;

            service.AddNote(note);
            break;

        case "2":
            service.ShowAllNotes();
            break;

        case "3":
            Console.Write("Въведете име на файл за запис: ");
            string savePath = Console.ReadLine();
            service.SaveToFile(savePath);
            break;

        case "4":
            Console.Write("Въведете име на файл за зареждане: ");
            string loadPath = Console.ReadLine();
            service.LoadFromFile(loadPath);
            break;

        case "5":
            isRunning = false;
            break;

        default:
            break;
    }
}