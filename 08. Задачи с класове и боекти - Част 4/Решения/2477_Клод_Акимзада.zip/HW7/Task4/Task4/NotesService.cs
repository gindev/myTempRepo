﻿namespace Task4
{
    public class NotesService
    {
        private List<Note> notes;

        public NotesService()
        {
            notes = new List<Note>();
        }

        public void AddNote(Note note)
        {
            notes.Add(note);
            Console.WriteLine("Бележката е добавена успешно.");
        }

        public void ShowAllNotes()
        {
            Console.WriteLine("Списък с бележки:");
            for (int i = 0; i < notes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {notes[i].Title} | {notes[i].Content}");
            }
        }

        public void SaveToFile(string filePath)
        {
            List<string> lines = new List<string>();
            foreach (var note in notes)
            {
                lines.Add($"{note.Title}|{note.Content}|{note.CreationDate:O}");
            }

            File.WriteAllLines(filePath, lines);
            Console.WriteLine("Данните са записани успешно във файл.");
        }

        public void LoadFromFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                notes.Clear();
                string[] lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    string[] parts = line.Split('|');
                    if (parts.Length == 3)
                    {
                        Note note = new Note
                        {
                            Title = parts[0],
                            Content = parts[1],
                            CreationDate = DateTime.Parse(parts[2])
                        };
                        notes.Add(note);
                    }
                }
                Console.WriteLine("Данните са заредени успешно от файл.");
            }
            else
            {
                Console.WriteLine("Файлът не съществува.");
            }
        }
    }
}
