﻿using Task1;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Computer computer = new Computer();
computer.Processor = new Processor();
computer.Memory = new Memory();
computer.Storage = new Storage();

Console.Write("Въведете производител: ");
computer.Manufacturer = Console.ReadLine();

Console.Write("Въведете модел: ");
computer.Model = Console.ReadLine();

Console.Write("Въведете модел на процесора: ");
computer.Processor.Model = Console.ReadLine();

Console.Write("Въведете брой ядра: ");
computer.Processor.Cores = int.Parse(Console.ReadLine());

Console.Write("Въведете размер на RAM: ");
computer.Memory.SizeGB = int.Parse(Console.ReadLine());

Console.Write("Въведете тип RAM: ");
computer.Memory.Type = Console.ReadLine();

Console.Write("Въведете размер на диска: ");
computer.Storage.SizeGB = int.Parse(Console.ReadLine());

Console.Write("Въведете тип устройство: ");
computer.Storage.Type = Console.ReadLine();

Console.WriteLine();

computer.PrintInfo();