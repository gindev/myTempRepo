﻿namespace Task1
{
    public class Computer
    {
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public Processor Processor { get; set; }
        public Memory Memory { get; set; }
        public Storage Storage { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"Компютър: {Manufacturer} {Model}");
            Console.WriteLine($"Процесор: {Processor.Model}, Ядра: {Processor.Cores}");
            Console.WriteLine($"Памет: {Memory.SizeGB} GB, Тип: {Memory.Type}");
            Console.WriteLine($"Устройство за съхранение: {Storage.SizeGB} GB, Тип: {Storage.Type}");
        }
    }
}
