﻿namespace Task1
{
    public class Memory
    {
        public int SizeGB { get; set; }
        public string Type { get; set; }
    }
}
