﻿namespace Task1
{
    public class Storage
    {
        public int SizeGB { get; set; }
        public string Type { get; set; }
    }
}
