﻿namespace Task1
{
    public class Processor
    {
        public string Model { get; set; }
        public int Cores { get; set; }
    }
}
