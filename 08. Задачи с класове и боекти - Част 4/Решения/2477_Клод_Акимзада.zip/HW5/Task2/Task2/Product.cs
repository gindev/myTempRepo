﻿namespace Task2
{
    public class Product
    {
        private decimal _price;
        private int _quantity;

        public string Name { get; set; }
        public decimal Price
        {
            get { return _price; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine($"Цената на \"{Name}\" не може да бъде отрицателна.\n");
                    _price = 0;
                }
                else
                {
                    _price = value;
                }
            }
        }

        public int Quantity
        {
            get { return _quantity; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine($"Количеството на \"{Name}\" не може да бъде отрицателно.\n");
                    _quantity = 0;
                }
                else
                {
                    _quantity = value;
                }
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукт: {Name}");
            Console.WriteLine($"Цена: {Price:F2}");
            Console.WriteLine($"Количество: {Quantity}\n");
        }
    }
}
