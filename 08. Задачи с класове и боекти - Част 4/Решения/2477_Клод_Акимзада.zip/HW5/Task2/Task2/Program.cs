﻿using Task2;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Product validProduct = new Product
{
    Name = "Лаптоп",
    Price = 1450.00m,
    Quantity = 3
};
validProduct.PrintInfo();

Console.WriteLine("Невалиден инпут:\n");

Product invalidProduct = new Product();
invalidProduct.Name = "Дефектна мишка";

invalidProduct.Price = -25.50m;
invalidProduct.Quantity = -5;

invalidProduct.PrintInfo();
