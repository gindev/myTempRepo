﻿using Task5;

Console.OutputEncoding = System.Text.Encoding.UTF8;

BankAccount account1 = new BankAccount("BG11AAAA1234", "Иван Иванов", 500.00m);
BankAccount account2 = new BankAccount("BG22BBBB5678", "Мария Петрова", 820.00m);
BankAccount account3 = new BankAccount("BG33CCCC9999", "Георги Димитров", 1200.00m);

account1.PrintInfo();
account2.PrintInfo();
account3.PrintInfo();

BankAccount.PrintTotalAccounts();