﻿namespace Task5
{
    public class BankAccount
    {
        private static int _totalAccounts = 0;

        public int Id { get; private set; }
        public string AccountNumber { get; set; }
        public string AccountHolder { get; set; }
        public decimal Balance { get; set; }

        public BankAccount(string accountNumber, string accountHolder, decimal balance)
        {
            AccountNumber = accountNumber;
            AccountHolder = accountHolder;
            Balance = balance;

            _totalAccounts++;
            Id = _totalAccounts;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Сметка {Id}: {AccountNumber} | {AccountHolder} | {Balance:F2}");
        }

        public static void PrintTotalAccounts()
        {
            Console.WriteLine($"\nОбщ брой създадени сметки: {_totalAccounts}");
        }
    }
}
