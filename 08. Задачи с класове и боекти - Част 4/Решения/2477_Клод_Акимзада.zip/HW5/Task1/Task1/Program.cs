﻿using Task1;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Person person = new Person
{
    FirstName = "Мария",
    LastName = "Георгиева",
    Age = 21
};

Console.WriteLine($"Име: {person.FirstName}");
Console.WriteLine($"Фамилия: {person.LastName}");
Console.WriteLine($"Възраст: {person.Age}");