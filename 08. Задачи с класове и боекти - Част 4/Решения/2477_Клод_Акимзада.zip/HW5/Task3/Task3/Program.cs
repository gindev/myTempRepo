﻿using Task3;


Console.OutputEncoding = System.Text.Encoding.UTF8;

Employee employee1 = new Employee();

Employee employee2 = new Employee("Петър Иванов", "Програмист", 2500m);

Console.WriteLine("Служител 1:");
employee1.PrintInfo();

Console.WriteLine();

Console.WriteLine("Служител 2:");
employee2.PrintInfo();
