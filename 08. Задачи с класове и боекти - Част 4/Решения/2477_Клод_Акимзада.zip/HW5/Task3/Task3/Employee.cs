﻿namespace Task3
{
    public class Employee
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public decimal Salary { get; set; }

        public Employee()
        {
            Name = "Няма въведено име";
            Position = "Не е зададена";
            Salary = 0m;
        }

        public Employee(string name, string position, decimal salary)
        {
            Name = name;
            Position = position;
            Salary = salary;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Име: {Name}");
            Console.WriteLine($"Длъжност: {Position}");
            Console.WriteLine($"Заплата: {Salary}");
        }
    }
}
