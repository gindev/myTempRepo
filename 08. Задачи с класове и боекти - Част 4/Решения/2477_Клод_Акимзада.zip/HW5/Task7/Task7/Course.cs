﻿namespace Task7
{
    public class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }
        public List<Student> EnrolledStudents { get; set; }

        public Course(string courseName, int maxStudents)
        {
            CourseName = courseName;
            MaxStudents = maxStudents;
            EnrolledStudents = new List<Student>();
        }

        public bool HasFreeSeats()
        {
            return EnrolledStudents.Count < MaxStudents;
        }

        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                EnrolledStudents.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine("Няма свободни места в курса.");
            }
        }

        public void PrintStudents()
        {
            Console.WriteLine($"\nЗаписани студенти в курс \"{CourseName}\":");
            foreach (var student in EnrolledStudents)
            {
                Console.WriteLine($"- {student.Name}, ФН: {student.FacultyNumber}");
            }
        }
    }
}
