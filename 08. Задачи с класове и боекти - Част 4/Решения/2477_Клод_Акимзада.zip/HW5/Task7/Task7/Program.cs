﻿using Task7;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Course course = new Course("Обектно-ориентирано програмиране", 2);

Student student1 = new Student { Name = "Иван Петров", FacultyNumber = "12345" };
Student student2 = new Student { Name = "Мария Георгиева", FacultyNumber = "12346" };
Student student3 = new Student { Name = "Георги Димитров", FacultyNumber = "12347" };

course.AddStudent(student1);
course.AddStudent(student2);
course.AddStudent(student3);

course.PrintStudents();
