﻿namespace Task4
{
    public class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
        public double AverageGrade { get; set; }
    }
}
