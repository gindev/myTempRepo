﻿using Task4;

Console.OutputEncoding = System.Text.Encoding.UTF8;

StudentGroup group = new StudentGroup("КН-101");

group.AddStudent(new Student { Name = "Иван Петров", FacultyNumber = "12345", AverageGrade = 5.50 });
group.AddStudent(new Student { Name = "Мария Георгиева", FacultyNumber = "12346", AverageGrade = 5.90 });
group.AddStudent(new Student { Name = "Георги Стоянов", FacultyNumber = "12347", AverageGrade = 4.80 });

group.PrintStudents();

Console.WriteLine();

Student bestStudent = group.GetBestStudent();
if (bestStudent != null)
{
    Console.WriteLine("Студент с най-висок успех:");
    Console.WriteLine($"{bestStudent.Name}, ФН: {bestStudent.FacultyNumber}, Успех: {bestStudent.AverageGrade:F2}");
}
