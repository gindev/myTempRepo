﻿namespace Task4
{
    public class StudentGroup
    {
        public string GroupName { get; set; }
        public List<Student> Students { get; set; }

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            Students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            Students.Add(student);
        }

        public void PrintStudents()
        {
            Console.WriteLine($"Група: {GroupName}\n");
            Console.WriteLine("Студенти:");
            for (int i = 0; i < Students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Students[i].Name}, ФН: {Students[i].FacultyNumber}, Успех: {Students[i].AverageGrade:F2}");
            }
        }

        public Student GetBestStudent()
        {
            if (Students.Count == 0)
            {
                return null;
            }

            return Students.OrderByDescending(s => s.AverageGrade).First();
        }
    }
}
