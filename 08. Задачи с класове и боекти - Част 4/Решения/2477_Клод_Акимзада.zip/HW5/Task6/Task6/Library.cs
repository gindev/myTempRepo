﻿namespace Task6
{
    public class Library
    {
        public List<Book> Books { get; set; }

        public Library()
        {
            Books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            Books.Add(book);
            Console.WriteLine("Успешно добавена книга.");
        }

        public void ShowAllBooks()
        {
            if (Books.Count == 0)
            {
                Console.WriteLine("Библиотеката е празна.");
                return;
            }

            foreach (var book in Books)
            {
                Console.WriteLine($"Заглавие: {book.Title} | Автор: {book.Author} | Година: {book.YearPublished}");
            }
        }

        public void FindBookByTitle(string title)
        {
            var foundBooks = Books.Where(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase)).ToList();

            if (foundBooks.Count == 0)
            {
                Console.WriteLine("Не е намерена книга с такова заглавие.");
            }
            else
            {
                foreach (var book in foundBooks)
                {
                    Console.WriteLine($"Намерена: {book.Title} | Автор: {book.Author} | Година: {book.YearPublished}");
                }
            }
        }
    }
}
