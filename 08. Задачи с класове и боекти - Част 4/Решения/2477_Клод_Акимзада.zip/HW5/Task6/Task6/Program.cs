﻿using Task6;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Library library = new Library();
bool isRunning = true;

while (isRunning)
{
    Console.WriteLine("\n1. Добавяне на книга");
    Console.WriteLine("2. Показване на всички книги");
    Console.WriteLine("3. Търсене на книга по заглавие");
    Console.WriteLine("4. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();

    Console.WriteLine();

    switch (choice)
    {
        case "1":
            Book newBook = new Book();

            Console.Write("Въведете заглавие: ");
            newBook.Title = Console.ReadLine();

            Console.Write("Въведете автор: ");
            newBook.Author = Console.ReadLine();

            Console.Write("Въведете година на издаване: ");
            newBook.YearPublished = int.Parse(Console.ReadLine());

            library.AddBook(newBook);
            break;

        case "2":
            library.ShowAllBooks();
            break;

        case "3":
            Console.Write("Въведете заглавие за търсене: ");
            string searchTitle = Console.ReadLine();
            library.FindBookByTitle(searchTitle);
            break;

        case "4":
            isRunning = false;
            break;

        default:
            Console.WriteLine("Невалидна опция. Моля, опитайте отново.");
            break;
    }
}
