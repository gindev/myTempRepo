﻿using Task4;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Rectangle rectangle = new Rectangle();

Console.Write("Въведете ширина на правоъгълник: ");
rectangle.Width = double.Parse(Console.ReadLine());

Console.Write("Въведете височина на правоъгълник: ");
rectangle.Height = double.Parse(Console.ReadLine());

Circle circle = new Circle();

Console.Write("Въведете радиус на окръжност: ");
circle.Radius = double.Parse(Console.ReadLine());

Console.WriteLine();

Console.WriteLine($"Фигура: {rectangle.Name}");
Console.WriteLine($"Лице: {rectangle.CalculateArea():0.##}");
Console.WriteLine($"Периметър: {rectangle.CalculatePerimeter():0.##}");

Console.WriteLine();

Console.WriteLine($"Фигура: {circle.Name}");
Console.WriteLine($"Лице: {circle.CalculateArea():0.##}");
Console.WriteLine($"Периметър: {circle.CalculatePerimeter():0.##}");