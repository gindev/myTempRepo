﻿namespace Task4
{
    public class Circle : Shape
    {
        public double Radius { get; set; }

        public Circle()
        {
            Name = "Окръжност";
        }

        public override double CalculateArea()
        {
            return Math.PI * Radius * Radius;
        }

        public override double CalculatePerimeter()
        {
            return 2 * Math.PI * Radius;
        }
    }
}
