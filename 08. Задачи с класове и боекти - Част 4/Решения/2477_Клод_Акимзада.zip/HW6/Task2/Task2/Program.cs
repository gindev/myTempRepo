﻿using Task2;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Manager manager = new Manager();

Console.Write("Въведете име на мениджър: ");
manager.Name = Console.ReadLine();

Console.Write("Въведете основна заплата: ");
manager.BaseSalary = decimal.Parse(Console.ReadLine());

Console.Write("Въведете бонус: ");
manager.Bonus = decimal.Parse(Console.ReadLine());

Console.WriteLine();

Developer developer = new Developer();

Console.Write("Въведете име на разработчик: ");
developer.Name = Console.ReadLine();

Console.Write("Въведете основна заплата: ");
developer.BaseSalary = decimal.Parse(Console.ReadLine());

Console.Write("Въведете брой извънредни часове: ");
developer.OvertimeHours = int.Parse(Console.ReadLine());

Console.Write("Въведете ставка за час: ");
developer.OvertimeRate = decimal.Parse(Console.ReadLine());

Console.WriteLine();

Console.WriteLine($"Мениджър: {manager.Name}");
Console.WriteLine($"Крайна заплата: {manager.CalculateSalary()}");

Console.WriteLine();

Console.WriteLine($"Разработчик: {developer.Name}");
Console.WriteLine($"Крайна заплата: {developer.CalculateSalary()}");