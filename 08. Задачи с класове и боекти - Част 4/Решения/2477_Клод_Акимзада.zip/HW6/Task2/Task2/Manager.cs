﻿namespace Task2
{
    public class Manager : Employee
    {
        public decimal Bonus { get; set; }

        public override decimal CalculateSalary()
        {
            return BaseSalary + Bonus;
        }
    }
}
