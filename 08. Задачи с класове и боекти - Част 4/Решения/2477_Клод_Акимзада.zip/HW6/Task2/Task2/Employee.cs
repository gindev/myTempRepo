﻿namespace Task2
{
    public class Employee
    {
        public string Name { get; set; }
        public decimal BaseSalary { get; set; }

        public virtual decimal CalculateSalary()
        {
            return BaseSalary;
        }
    }
}
