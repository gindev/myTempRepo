﻿namespace Task2
{
    public class Developer : Employee
    {
        public int OvertimeHours { get; set; }
        public decimal OvertimeRate { get; set; }

        public override decimal CalculateSalary()
        {
            return BaseSalary + (OvertimeHours * OvertimeRate);
        }
    }
}
