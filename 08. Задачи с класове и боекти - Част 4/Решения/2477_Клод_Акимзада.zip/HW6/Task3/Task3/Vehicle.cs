﻿namespace Task3
{
    public class Vehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }

        public virtual void ShowInfo()
        {
            Console.WriteLine($"Превозно средство: {Brand} {Model}");
        }
    }
}
