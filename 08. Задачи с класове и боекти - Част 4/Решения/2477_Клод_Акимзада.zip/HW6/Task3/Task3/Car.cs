﻿namespace Task3
{
    public class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }

        public override void ShowInfo()
        {
            Console.WriteLine($"Автомобил: {Brand} {Model}, Брой врати: {NumberOfDoors}");
        }
    }
}
