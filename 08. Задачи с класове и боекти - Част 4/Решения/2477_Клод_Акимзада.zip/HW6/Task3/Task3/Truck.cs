﻿namespace Task3
{
    public class Truck : Vehicle
    {
        public int LoadCapacity { get; set; }

        public override void ShowInfo()
        {
            Console.WriteLine($"Камион: {Brand} {Model}, Товароносимост: {LoadCapacity} кг");
        }
    }
}
