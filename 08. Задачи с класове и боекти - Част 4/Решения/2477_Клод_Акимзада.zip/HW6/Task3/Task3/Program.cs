﻿using Task3;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

List<Vehicle> vehicles = new List<Vehicle>();

vehicles.Add(new Car
{
    Brand = "Toyota",
    Model = "Corolla",
    NumberOfDoors = 4
});

vehicles.Add(new Motorcycle
{
    Brand = "Kawasaki",
    Model = "Ninja H2R",
    MotorcycleType = "спортен"
});

vehicles.Add(new Truck
{
    Brand = "MAN",
    Model = "TGX",
    LoadCapacity = 18000
});

foreach (var vehicle in vehicles)
{
    vehicle.ShowInfo();
}