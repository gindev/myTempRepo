﻿namespace Task3
{
    public class Motorcycle : Vehicle
    {
        public string MotorcycleType { get; set; }

        public override void ShowInfo()
        {
            Console.WriteLine($"Мотоциклет: {Brand} {Model}, Тип: {MotorcycleType}");
        }
    }
}
