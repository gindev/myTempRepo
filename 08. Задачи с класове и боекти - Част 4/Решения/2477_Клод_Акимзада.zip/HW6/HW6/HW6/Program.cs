﻿using HW6;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

Student student = new Student();

Console.Write("Въведете име на студент: ");
student.FirstName = Console.ReadLine();

Console.Write("Въведете фамилия на студент: ");
student.LastName = Console.ReadLine();

Console.Write("Въведете възраст на студент: ");
student.Age = int.Parse(Console.ReadLine());

Console.Write("Въведете факултетен номер: ");
student.FacultyNumber = Console.ReadLine();

Console.Write("Въведете специалност: ");
student.Specialty = Console.ReadLine();

Console.WriteLine();

Teacher teacher = new Teacher();

Console.Write("Въведете име на преподавател: ");
teacher.FirstName = Console.ReadLine();

Console.Write("Въведете фамилия на преподавател: ");
teacher.LastName = Console.ReadLine();

Console.Write("Въведете възраст на преподавател: ");
teacher.Age = int.Parse(Console.ReadLine());

Console.Write("Въведете дисциплина: ");
teacher.Subject = Console.ReadLine();

Console.Write("Въведете академична длъжност: ");
teacher.AcademicTitle = Console.ReadLine();

Console.WriteLine();

student.PrintInfo();

Console.WriteLine();

teacher.PrintInfo();