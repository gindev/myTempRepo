﻿namespace HW6
{
    public class Teacher : Person
    {
        public string Subject { get; set; }
        public string AcademicTitle { get; set; }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за преподавател:");
            base.PrintInfo();
            Console.WriteLine($"Дисциплина: {Subject}");
            Console.WriteLine($"Академична длъжност: {AcademicTitle}");
        }
    }
}
