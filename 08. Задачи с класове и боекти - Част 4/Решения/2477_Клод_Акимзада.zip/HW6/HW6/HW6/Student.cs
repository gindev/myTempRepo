﻿namespace HW6
{
    public class Student : Person
    {
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за студент:");
            base.PrintInfo();
            Console.WriteLine($"Факултетен номер: {FacultyNumber}");
            Console.WriteLine($"Специалност: {Specialty}");
        }
    }
}
