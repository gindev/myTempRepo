﻿namespace HW6
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"Име: {FirstName}");
            Console.WriteLine($"Фамилия: {LastName}");
            Console.WriteLine($"Възраст: {Age}");
        }
    }
}
