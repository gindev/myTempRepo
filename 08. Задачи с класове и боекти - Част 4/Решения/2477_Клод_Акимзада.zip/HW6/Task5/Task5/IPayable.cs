﻿namespace Task5
{
    public interface IPayable
    {
        decimal GetPaymentAmount();
    }
}
