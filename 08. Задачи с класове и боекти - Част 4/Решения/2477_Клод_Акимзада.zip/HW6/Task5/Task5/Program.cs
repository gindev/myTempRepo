﻿using Task5;

Console.OutputEncoding = System.Text.Encoding.UTF8;

List<IPayable> payables = new List<IPayable>();

payables.Add(new Invoice
{
    InvoiceNumber = "1001",
    Amount = 350.00m
});

payables.Add(new Invoice
{
    InvoiceNumber = "1002",
    Amount = 120.00m
});

payables.Add(new Subscription
{
    ServiceName = "Интернет",
    MonthlyFee = 20.00m,
    Months = 3
});

payables.Add(new Subscription
{
    ServiceName = "Софтуерен лиценз",
    MonthlyFee = 45.00m,
    Months = 2
});

decimal totalAmount = 0;

foreach (var item in payables)
{
    Console.WriteLine(item.ToString());
    totalAmount += item.GetPaymentAmount();
}

Console.WriteLine();
Console.WriteLine($"Обща сума за плащане: {totalAmount:F2} лв.");