﻿namespace Task5
{
    public class Invoice : IPayable
    {
        public string InvoiceNumber { get; set; }
        public decimal Amount { get; set; }

        public decimal GetPaymentAmount()
        {
            return Amount;
        }

        public override string ToString()
        {
            return $"Фактура №{InvoiceNumber}: {Amount:F2} лв.";
        }
    }
}
