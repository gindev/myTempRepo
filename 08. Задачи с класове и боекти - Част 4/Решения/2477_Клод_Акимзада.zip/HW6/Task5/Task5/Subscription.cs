﻿namespace Task5
{
    public class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public decimal MonthlyFee { get; set; }
        public int Months { get; set; }

        public decimal GetPaymentAmount()
        {
            return MonthlyFee * Months;
        }

        public override string ToString()
        {
            return $"Абонамент: {ServiceName}, Сума: {GetPaymentAmount():F2} лв.";
        }
    }
}
