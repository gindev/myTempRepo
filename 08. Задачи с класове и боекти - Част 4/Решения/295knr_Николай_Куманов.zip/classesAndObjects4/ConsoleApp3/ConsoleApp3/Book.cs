﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Book
    {
        private string title;
        private int year;
        private Author author;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public Author Author
        {
            get { return author; }
            set { author = value; }
        }

        public Book(string title, int year, Author author)
        {
            Title = title;
            Year = year;
            Author = author;
        }
    }
}
