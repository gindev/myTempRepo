﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            LibraryService library = new LibraryService();
            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("1. Add a book");
                Console.WriteLine("2. Show all books");
                Console.WriteLine("3. Search by author");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");

                string option = Console.ReadLine();

                if (option == "1")
                {
                    Console.Write("Title: ");
                    string title = Console.ReadLine();

                    Console.Write("Year: ");
                    int year = int.Parse(Console.ReadLine());

                    Console.Write("Author First Name: ");
                    string firstName = Console.ReadLine();

                    Console.Write("Author Last Name: ");
                    string lastName = Console.ReadLine();

                    Author author = new Author(firstName, lastName);
                    Book book = new Book(title, year, author);

                    library.AddBook(book);
                    Console.WriteLine();
                    Console.WriteLine("Book added successfully.");
                    Console.WriteLine();
                }
                else if (option == "2")
                {
                    Console.WriteLine();
                    List<Book> allBooks = library.ShowAllBooks();
                    foreach (Book book in allBooks)
                    {
                        Console.WriteLine($"Title: {book.Title}, Year: {book.Year}, Author: {book.Author.FirstName} {book.Author.LastName}");
                    }
                    Console.WriteLine();
                }
                else if (option == "3")
                {
                    Console.WriteLine();
                    Console.Write("Enter author name: ");
                    string searchName = Console.ReadLine();

                    List<Book> foundBooks = library.FindBooksByAuthor(searchName);

                    if (foundBooks.Count > 0)
                    {
                        foreach (Book book in foundBooks)
                        {
                            Console.WriteLine($"Title: {book.Title}, Year: {book.Year}, Author: {book.Author.FirstName} {book.Author.LastName}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No books found for this author.");
                    }
                    Console.WriteLine();
                }
                else if (option == "4")
                {
                    isRunning = false;
                }
            }
        }
    }
}
