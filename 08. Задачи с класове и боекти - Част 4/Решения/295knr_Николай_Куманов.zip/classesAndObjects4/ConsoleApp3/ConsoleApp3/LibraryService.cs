﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class LibraryService
    {
        private List<Book> books;

        public LibraryService()
        {
            books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public List<Book> ShowAllBooks()
        {
            return books;
        }

        public List<Book> FindBooksByAuthor(string authorName)
        {
            List<Book> result = new List<Book>();
            foreach (Book book in books)
            {
                if (book.Author.FirstName.ToLower() == authorName.ToLower() ||
                    book.Author.LastName.ToLower() == authorName.ToLower())
                {
                    result.Add(book);
                }
            }
            return result;
        }
    }
}
