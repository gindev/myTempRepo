﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Order
    {
        private int orderNumber;
        private Customer customer;
        private List<OrderItem> items;

        public int OrderNumber
        {
            get { return orderNumber; }
            set { orderNumber = value; }
        }

        public Customer Customer
        {
            get { return customer; }
            set { customer = value; }
        }

        public List<OrderItem> Items
        {
            get { return items; }
            set { items = value; }
        }

        public Order(int orderNumber, Customer customer)
        {
            OrderNumber = orderNumber;
            Customer = customer;
            Items = new List<OrderItem>();
        }

        public void AddItem(OrderItem item)
        {
            Items.Add(item);
        }

        public double GetOrderTotal()
        {
            double total = 0;
            foreach (OrderItem item in Items)
            {
                total += item.GetTotalPrice();
            }
            return total;
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"Order No: {OrderNumber}");
            Console.WriteLine($"Customer: {Customer.Name}, Phone: {Customer.Phone}");
            Console.WriteLine();
            Console.WriteLine("Items:");

            int index = 1;
            foreach (OrderItem item in Items)
            {
                Console.WriteLine($"{index}. {item.Product.Name} | {item.Quantity} pcs. | Unit price: {item.Product.Price:F2} | Value: {item.GetTotalPrice():F2}");
                index++;
            }

            Console.WriteLine();
            Console.WriteLine($"Total order value: {GetOrderTotal():F2}");
        }
    }
}
