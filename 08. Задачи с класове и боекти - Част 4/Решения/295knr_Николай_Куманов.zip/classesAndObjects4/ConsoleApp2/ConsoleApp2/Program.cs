﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer("John Doe", "0888123456");

            Product mouse = new Product("Mouse", 25.00);
            Product keyboard = new Product("Keyboard", 60.00);
            Product monitor = new Product("Monitor", 320.00);

            Order order = new Order(5001, customer);

            order.AddItem(new OrderItem(mouse, 2));
            order.AddItem(new OrderItem(keyboard, 1));
            order.AddItem(new OrderItem(monitor, 1));

            order.PrintOrderInfo();
        }
    }
}
