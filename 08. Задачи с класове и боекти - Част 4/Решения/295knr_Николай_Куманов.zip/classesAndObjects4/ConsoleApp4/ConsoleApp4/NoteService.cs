﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class NoteService
    {
        private List<Note> notes;

        public NoteService()
        {
            notes = new List<Note>();
        }

        public void AddNote(Note note)
        {
            notes.Add(note);
        }

        public List<Note> ShowAllNotes()
        {
            return notes;
        }

        public void SaveToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (Note note in notes)
                {
                    writer.WriteLine(note.Title);
                    writer.WriteLine(note.Content);
                    writer.WriteLine(note.CreationDate.ToString("O"));
                }
            }
        }

        public void LoadFromFile(string filePath)
        {
            notes.Clear();
            using (StreamReader reader = new StreamReader(filePath))
            {
                string title;
                while ((title = reader.ReadLine()) != null)
                {
                    string content = reader.ReadLine();
                    string dateString = reader.ReadLine();
                    DateTime date = DateTime.Parse(dateString);

                    Note note = new Note(title, content, date);
                    notes.Add(note);
                }
            }
        }
    }
}
