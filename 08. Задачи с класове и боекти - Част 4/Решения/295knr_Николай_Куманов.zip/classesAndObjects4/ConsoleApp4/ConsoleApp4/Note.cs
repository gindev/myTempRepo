﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Note
    {
        private string title;
        private string content;
        private DateTime creationDate;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        public DateTime CreationDate
        {
            get { return creationDate; }
            set { creationDate = value; }
        }

        public Note(string title, string content, DateTime creationDate)
        {
            Title = title;
            Content = content;
            CreationDate = creationDate;
        }
    }
}
