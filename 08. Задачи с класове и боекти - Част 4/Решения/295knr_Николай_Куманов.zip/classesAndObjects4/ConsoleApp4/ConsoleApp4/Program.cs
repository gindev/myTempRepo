﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NoteService service = new NoteService();
            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("1. Add note");
                Console.WriteLine("2. Show notes");
                Console.WriteLine("3. Save to file");
                Console.WriteLine("4. Load from file");
                Console.WriteLine("5. Exit");
                Console.Write("Choose option: ");

                string option = Console.ReadLine();
                Console.WriteLine();

                if (option == "1")
                {
                    Console.Write("Title: ");
                    string title = Console.ReadLine();

                    Console.Write("Content: ");
                    string content = Console.ReadLine();

                    Note note = new Note(title, content, DateTime.Now);
                    service.AddNote(note);

                    Console.WriteLine("Note added successfully.");
                    Console.WriteLine();
                }
                else if (option == "2")
                {
                    List<Note> allNotes = service.ShowAllNotes();
                    Console.WriteLine("List of notes:");

                    for (int i = 0; i < allNotes.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {allNotes[i].Title} | {allNotes[i].Content}");
                    }

                    Console.WriteLine();
                }
                else if (option == "3")
                {
                    Console.Write("Enter file path: ");
                    string path = Console.ReadLine();

                    service.SaveToFile(path);
                    Console.WriteLine("Data saved to file successfully.");
                    Console.WriteLine();
                }
                else if (option == "4")
                {
                    Console.Write("Enter file path: ");
                    string path = Console.ReadLine();

                    service.LoadFromFile(path);
                    Console.WriteLine("Data loaded from file successfully.");
                    Console.WriteLine();
                }
                else if (option == "5")
                {
                    isRunning = false;
                }
            }
        }
    }
}
