﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Въведете производител: ");
            string manufacturer = Console.ReadLine();

            Console.Write("Въведете модел: ");
            string model = Console.ReadLine();

            Console.Write("Въведете модел на процесора: ");
            string processorModel = Console.ReadLine();

            Console.Write("Въведете брой ядра: ");
            int cores = int.Parse(Console.ReadLine());

            Console.Write("Въведете размер на RAM: ");
            int ramSize = int.Parse(Console.ReadLine());

            Console.Write("Въведете тип RAM: ");
            string ramType = Console.ReadLine();

            Console.Write("Въведете размер на диска: ");
            int diskSize = int.Parse(Console.ReadLine());

            Console.Write("Въведете тип устройство: ");
            string deviceType = Console.ReadLine();

            Processor processor = new Processor(processorModel, cores);
            Memory memory = new Memory(ramSize, ramType);
            Storage storage = new Storage(diskSize, deviceType);

            Computer computer = new Computer(manufacturer, model, processor, memory, storage);

            Console.WriteLine();
            computer.PrintInfo();
        }
    }
}
