﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Processor
    {
        private string model;
        private int cores;

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public int Cores
        {
            get { return cores; }
            set { cores = value; }
        }

        public Processor(string model, int cores)
        {
            Model = model;
            Cores = cores;
        }
    }
}
