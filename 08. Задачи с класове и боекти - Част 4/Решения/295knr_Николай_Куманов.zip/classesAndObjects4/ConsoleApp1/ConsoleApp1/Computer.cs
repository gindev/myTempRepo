﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Computer
    {
        private string manufacturer;
        private string model;
        private Processor processor;
        private Memory memory;
        private Storage storage;

        public string Manufacturer
        {
            get { return manufacturer; }
            set { manufacturer = value; }
        }

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public Processor Processor
        {
            get { return processor; }
            set { processor = value; }
        }

        public Memory Memory
        {
            get { return memory; }
            set { memory = value; }
        }

        public Storage Storage
        {
            get { return storage; }
            set { storage = value; }
        }

        public Computer(string manufacturer, string model, Processor processor, Memory memory, Storage storage)
        {
            Manufacturer = manufacturer;
            Model = model;
            Processor = processor;
            Memory = memory;
            Storage = storage;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Компютър: {Manufacturer} {Model}");
            Console.WriteLine($"Процесор: {Processor.Model}, Ядра: {Processor.Cores}");
            Console.WriteLine($"Памет: {Memory.Size} GB, Тип: {Memory.Type}");
            Console.WriteLine($"Устройство за съхранение: {Storage.Size} GB, Тип: {Storage.Type}");
        }
    }
}
