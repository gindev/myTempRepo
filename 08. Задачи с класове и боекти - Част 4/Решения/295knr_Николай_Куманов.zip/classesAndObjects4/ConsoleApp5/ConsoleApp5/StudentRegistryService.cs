﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class StudentRegistryService
    {
        private List<Student> students;

        public StudentRegistryService()
        {
            students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public List<Student> ShowAllStudents()
        {
            return students;
        }

        public void SaveToJson(string filePath)
        {
            try
            {
                JsonSerializerOptions options = new JsonSerializerOptions { WriteIndented = true };
                using (FileStream stream = File.Create(filePath))
                {
                    JsonSerializer.Serialize(stream, students, options);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving file: {ex.Message}");
            }
        }

        public void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File does not exist.");
                return;
            }

            try
            {
                using (FileStream stream = File.OpenRead(filePath))
                {
                    List<Student> loadedData = JsonSerializer.Deserialize<List<Student>>(stream);

                    if (loadedData != null)
                    {
                        students = loadedData;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading file: {ex.Message}");
            }
        }
    }
}
