﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Student
    {
        private string firstName;
        private string lastName;
        private string facultyNumber;
        private string major;
        private double gpa;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string FacultyNumber
        {
            get { return facultyNumber; }
            set { facultyNumber = value; }
        }

        public string Major
        {
            get { return major; }
            set { major = value; }
        }

        public double Gpa
        {
            get { return gpa; }
            set { gpa = value; }
        }

        public Student()
        {
        }

        public Student(string firstName, string lastName, string facultyNumber, string major, double gpa)
        {
            FirstName = firstName;
            LastName = lastName;
            FacultyNumber = facultyNumber;
            Major = major;
            Gpa = gpa;
        }
    }
}
