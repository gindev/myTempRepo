﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentRegistryService registry = new StudentRegistryService();
            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("1. Add student");
                Console.WriteLine("2. Show all students");
                Console.WriteLine("3. Save to JSON file");
                Console.WriteLine("4. Load from JSON file");
                Console.WriteLine("5. Exit");
                Console.Write("Choose option: ");

                string option = Console.ReadLine();
                Console.WriteLine();

                if (option == "1")
                {
                    Console.Write("First Name: ");
                    string firstName = Console.ReadLine();

                    Console.Write("Last Name: ");
                    string lastName = Console.ReadLine();

                    Console.Write("Faculty Number: ");
                    string facultyNumber = Console.ReadLine();

                    Console.Write("Major: ");
                    string major = Console.ReadLine();

                    Console.Write("GPA: ");
                    double gpa = double.Parse(Console.ReadLine());

                    Student student = new Student(firstName, lastName, facultyNumber, major, gpa);
                    registry.AddStudent(student);

                    Console.WriteLine("Student added successfully.");
                    Console.WriteLine();
                }
                else if (option == "2")
                {
                    List<Student> allStudents = registry.ShowAllStudents();
                    Console.WriteLine("List of students:");

                    for (int i = 0; i < allStudents.Count; i++)
                    {
                        Student s = allStudents[i];
                        Console.WriteLine($"{i + 1}. {s.FirstName} {s.LastName} | FN: {s.FacultyNumber} | Major: {s.Major} | GPA: {s.Gpa:F2}");
                    }

                    Console.WriteLine();
                }
                else if (option == "3")
                {
                    Console.Write("Enter file path: ");
                    string path = Console.ReadLine();

                    registry.SaveToJson(path);
                    Console.WriteLine("Data saved successfully to JSON file.");
                    Console.WriteLine();
                }
                else if (option == "4")
                {
                    Console.Write("Enter file path: ");
                    string path = Console.ReadLine();

                    registry.LoadFromJson(path);
                    Console.WriteLine("Data loaded successfully from JSON file.");
                    Console.WriteLine();
                }
                else if (option == "5")
                {
                    isRunning = false;
                }
            }
        }
    }
}

