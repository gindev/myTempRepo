﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;

namespace NoteApp
{
	
	public class Note
	{
		public string Title { get; set; }
		public string Content { get; set; }
		public DateTime CreatedAt { get; set; }

		public Note(string title, string content)
		{
			Title = title;
			Content = content;
			CreatedAt = DateTime.Now;
		}

		
		public Note(string title, string content, DateTime createdAt)
		{
			Title = title;
			Content = content;
			CreatedAt = createdAt;
		}

		public override string ToString()
		{
			return $"--- {Title} ---\nДата: {CreatedAt:dd.MM.yyyy HH:mm}\nСъдържание: {Content}\n";
		}
	}

	
	public class NoteService
	{
		private List<Note> notes = new List<Note>();

		public void AddNote(Note note)
		{
			notes.Add(note);
			Console.WriteLine("Бележката е добавена успешно.");
		}

		public void ShowAllNotes()
		{
			if (notes.Count == 0)
			{
				Console.WriteLine("Няма налични бележки.");
				return;
			}

			foreach (var note in notes)
			{
				Console.WriteLine(note);
			}
		}

		public void SaveToFile(string filePath)
		{
			try
			{
				using (StreamWriter writer = new StreamWriter(filePath))
				{
					foreach (var note in notes)
					{
						 
						writer.WriteLine($"{note.Title}|{note.Content}|{note.CreatedAt:o}");
					}
				}
				Console.WriteLine("Данните са записани успешно във файл.");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Грешка при запис: {ex.Message}");
			}
		}

		public void LoadFromFile(string filePath)
		{
			if (!File.Exists(filePath))
			{
				Console.WriteLine("Грешка: Файлът не съществува.");
				return;
			}

			try
			{
				notes.Clear(); 
				string[] lines = File.ReadAllLines(filePath);
				foreach (string line in lines)
				{
					string[] parts = line.Split('|');
					if (parts.Length == 3)
					{
						string title = parts[0];
						string content = parts[1];
						DateTime date = DateTime.Parse(parts[2]);
						notes.Add(new Note(title, content, date));
					}
				}
				Console.WriteLine("Данните са заредени успешно от файл.");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Грешка при зареждане: {ex.Message}");
			}
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			
			Console.OutputEncoding = System.Text.Encoding.UTF8;
			Console.InputEncoding = System.Text.Encoding.UTF8;

			NoteService service = new NoteService();
			bool exit = false;

			while (!exit)
			{
				Console.WriteLine("\n--- МЕНЮ ---");
				Console.WriteLine("1. Добавяне на бележка");
				Console.WriteLine("2. Показване на бележките");
				Console.WriteLine("3. Запис във файл");
				Console.WriteLine("4. Зареждане от файл");
				Console.WriteLine("5. Изход");
				Console.Write("Изберете опция: ");

				string choice = Console.ReadLine();

				switch (choice)
				{
					case "1":
						Console.Write("Заглавие: ");
						string title = Console.ReadLine();
						Console.Write("Съдържание: ");
						string content = Console.ReadLine();
						service.AddNote(new Note(title, content));
						break;

					case "2":
						Console.WriteLine("\nСписък с бележки:");
						service.ShowAllNotes();
						break;

					case "3":
						Console.Write("Въведете име на файл (напр. notes.txt): ");
						string saveFile = Console.ReadLine();
						service.SaveToFile(saveFile);
						break;

					case "4":
						Console.Write("Въведете име на файл за зареждане: ");
						string loadFile = Console.ReadLine();
						service.LoadFromFile(loadFile);
						break;

					case "5":
						exit = true;
						Console.WriteLine("Излизане от програмата...");
						break;

					default:
						Console.WriteLine("Невалиден избор. Опитайте отново.");
						break;
				}
			}
		}
	}
}
