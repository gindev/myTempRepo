﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json; 

namespace StudentRegistryApp
{
	
	public class Student
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string FacultyNumber { get; set; }
		public string Specialty { get; set; }
		public double AverageGrade { get; set; }

		public Student(string firstName, string lastName, string facultyNumber, string specialty, double averageGrade)
		{
			FirstName = firstName;
			LastName = lastName;
			FacultyNumber = facultyNumber;
			Specialty = specialty;
			AverageGrade = averageGrade;
		}

		public override string ToString()
		{
			return $"Име: {FirstName} {LastName}, ФН: {FacultyNumber}, Специалност: {Specialty}, Успех: {AverageGrade:F2}";
		}
	}

	
	public class StudentRegistryService
	{
		private List<Student> students = new List<Student>();

		public void AddStudent(Student student)
		{
			students.Add(student);
			Console.WriteLine("Студентът е добавен успешно.");
		}

		public void ShowAllStudents()
		{
			if (students.Count == 0)
			{
				Console.WriteLine("Регистърът е празен.");
				return;
			}

			foreach (var student in students)
			{
				Console.WriteLine(student);
			}
		}

		public void SaveToJson(string filePath)
		{
			try
			{
				var options = new JsonSerializerOptions { WriteIndented = true };
				string jsonString = JsonSerializer.Serialize(students, options);
				File.WriteAllText(filePath, jsonString);
				Console.WriteLine("Данните са записани успешно в JSON файл.");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Грешка при запис: {ex.Message}");
			}
		}

		public void LoadFromJson(string filePath)
		{
			if (!File.Exists(filePath))
			{
				Console.WriteLine("Файлът не съществува.");
				return;
			}

			try
			{
				string jsonString = File.ReadAllText(filePath);
				students = JsonSerializer.Deserialize<List<Student>>(jsonString);
				Console.WriteLine("Данните са заредени успешно от JSON файл.");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Грешка при зареждане: {ex.Message}");
			}
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			
			Console.OutputEncoding = System.Text.Encoding.UTF8;
			Console.InputEncoding = System.Text.Encoding.UTF8;

			StudentRegistryService registry = new StudentRegistryService();
			bool running = true;

			while (running)
			{
				Console.WriteLine("\n--- СТУДЕНТСКИ РЕГИСТЪР ---");
				Console.WriteLine("1. Добавяне на студент");
				Console.WriteLine("2. Показване на всички студенти");
				Console.WriteLine("3. Запис в JSON файл");
				Console.WriteLine("4. Зареждане от JSON файл");
				Console.WriteLine("5. Изход");
				Console.Write("Избор: ");

				string choice = Console.ReadLine();

				switch (choice)
				{
					case "1":
						Console.Write("Име: ");
						string fName = Console.ReadLine();
						Console.Write("Фамилия: ");
						string lName = Console.ReadLine();
						Console.Write("ФН: ");
						string fn = Console.ReadLine();
						Console.Write("Специалност: ");
						string spec = Console.ReadLine();
						Console.Write("Среден успех: ");
						double grade = double.Parse(Console.ReadLine());

						registry.AddStudent(new Student(fName, lName, fn, spec, grade));
						break;

					case "2":
						registry.ShowAllStudents();
						break;

					case "3":
						Console.Write("Име на файл (напр. students.json): ");
						registry.SaveToJson(Console.ReadLine());
						break;

					case "4":
						Console.Write("Име на файл за зареждане: ");
						registry.LoadFromJson(Console.ReadLine());
						break;

					case "5":
						running = false;
						break;

					default:
						Console.WriteLine("Невалидна опция.");
						break;
				}
			}
		}
	}
}