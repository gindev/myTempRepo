﻿using System;
using System.Collections.Generic;

namespace LibraryManagement
{
	
	class Author
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }

		public Author(string firstName, string lastName)
		{
			FirstName = firstName;
			LastName = lastName;
		}

		public string FullName()
		{
			return FirstName + " " + LastName;
		}
	}

	
	class Book
	{
		public string Title { get; set; }
		public int Year { get; set; }
		public Author Author { get; set; }

		public Book(string title, int year, Author author)
		{
			Title = title;
			Year = year;
			Author = author;
		}
	}

	
	class LibraryService
	{
		private List<Book> books = new List<Book>();

		public void AddBook(Book book)
		{
			books.Add(book);
		}

		public void ShowAllBooks()
		{
			if (books.Count == 0)
			{
				Console.WriteLine("Няма добавени книги.");
				return;
			}

			Console.WriteLine("\n===== Списък с книги =====");

			foreach (Book book in books)
			{
				Console.WriteLine(
					$"{book.Title} ({book.Year}) - {book.Author.FullName()}"
				);
			}
		}

		public void FindBooksByAuthor(string authorName)
		{
			bool found = false;

			Console.WriteLine("\n===== Намерени книги =====");

			foreach (Book book in books)
			{
				if (book.Author.FullName().ToLower().Contains(authorName.ToLower()))
				{
					Console.WriteLine(
						$"{book.Title} ({book.Year}) - {book.Author.FullName()}"
					);

					found = true;
				}
			}

			if (!found)
			{
				Console.WriteLine("Няма намерени книги от този автор.");
			}
		}
	}

	
	class Program
	{
		static void Main(string[] args)
		{
			LibraryService library = new LibraryService();

			while (true)
			{
				Console.WriteLine("\n===== Library Management =====");
				Console.WriteLine("1. Добавяне на книга");
				Console.WriteLine("2. Показване на всички книги");
				Console.WriteLine("3. Търсене по автор");
				Console.WriteLine("4. Изход");

				Console.Write("Изберете опция: ");
				string choice = Console.ReadLine();

				switch (choice)
				{
					case "1":

						Console.Write("Заглавие: ");
						string title = Console.ReadLine();

						Console.Write("Година на издаване: ");
						int year = int.Parse(Console.ReadLine());

						Console.Write("Име на автора: ");
						string firstName = Console.ReadLine();

						Console.Write("Фамилия на автора: ");
						string lastName = Console.ReadLine();

						Author author = new Author(firstName, lastName);

						Book book = new Book(title, year, author);

						library.AddBook(book);

						Console.WriteLine("Книгата е добавена успешно.");
						break;

					case "2":

						library.ShowAllBooks();
						break;

					case "3":

						Console.Write("Въведете име на автор: ");
						string authorName = Console.ReadLine();

						library.FindBooksByAuthor(authorName);
						break;

					case "4":

						Console.WriteLine("Изход от програмата...");
						return;

					default:

						Console.WriteLine("Невалиден избор.");
						break;
				}
			}
		}
	}
}
