﻿using System;
using System.Collections.Generic;

class Customer
{
	public string Name { get; set; }
	public string Phone { get; set; }

	public Customer(string name, string phone)
	{
		Name = name;
		Phone = phone;
	}
}

class Product
{
	public string Name { get; set; }
	public decimal Price { get; set; }

	public Product(string name, decimal price)
	{
		Name = name;
		Price = price;
	}
}

class OrderItem
{
	public Product Product { get; set; }
	public int Quantity { get; set; }

	public OrderItem(Product product, int quantity)
	{
		Product = product;
		Quantity = quantity;
	}

	public decimal GetTotalPrice()
	{
		return Product.Price * Quantity;
	}
}

class Order
{
	public int OrderNumber { get; set; }
	public Customer Customer { get; set; }

	public List<OrderItem> Items { get; set; }

	public Order(int orderNumber, Customer customer)
	{
		OrderNumber = orderNumber;
		Customer = customer;
		Items = new List<OrderItem>();
	}

	public void AddItem(OrderItem item)
	{
		Items.Add(item);
	}

	public decimal GetOrderTotal()
	{
		decimal total = 0;

		foreach (OrderItem item in Items)
		{
			total += item.GetTotalPrice();
		}

		return total;
	}

	public void PrintOrderInfo()
	{
		Console.WriteLine($"Номер на поръчка: {OrderNumber}");

		Console.WriteLine("\nКлиент:");
		Console.WriteLine($"Име: {Customer.Name}");
		Console.WriteLine($"Телефон: {Customer.Phone}");

		Console.WriteLine("\nПродукти:");

		foreach (OrderItem item in Items)
		{
			Console.WriteLine(
				$"{item.Product.Name} - {item.Quantity} x {item.Product.Price} лв. = {item.GetTotalPrice()} лв."
			);
		}

		Console.WriteLine($"\nОбща сума: {GetOrderTotal()} лв.");
	}
}

class Program02
{
	static void Main()
	{
		Customer customer = new Customer("Иван Петров", "0888123456");

		Product product1 = new Product("Лаптоп", 2200m);
		Product product2 = new Product("Мишка", 45m);
		Product product3 = new Product("Клавиатура", 120m);

		OrderItem item1 = new OrderItem(product1, 1);
		OrderItem item2 = new OrderItem(product2, 2);
		OrderItem item3 = new OrderItem(product3, 1);

		Order order = new Order(1001, customer);

		order.AddItem(item1);
		order.AddItem(item2);
		order.AddItem(item3);

		order.PrintOrderInfo();
	}
}
