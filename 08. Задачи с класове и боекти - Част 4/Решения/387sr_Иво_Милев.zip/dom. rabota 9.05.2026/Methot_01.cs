﻿using System;

class Processor
{
	public string Model { get; set; }
	public int Cores { get; set; }

	public Processor(string model, int cores)
	{
		Model = model;
		Cores = cores;
	}
}

class Memory
{
	public int SizeGB { get; set; }
	public string Type { get; set; }

	public Memory(int sizeGB, string type)
	{
		SizeGB = sizeGB;
		Type = type;
	}
}

class Storage
{
	public int SizeGB { get; set; }
	public string DeviceType { get; set; }

	public Storage(int sizeGB, string deviceType)
	{
		SizeGB = sizeGB;
		DeviceType = deviceType;
	}
}

class Computer
{
	public string Brand { get; set; }
	public string Model { get; set; }

	public Processor Processor { get; set; }
	public Memory Memory { get; set; }
	public Storage Storage { get; set; }

	public Computer(string brand, string model,
					Processor processor,
					Memory memory,
					Storage storage)
	{
		Brand = brand;
		Model = model;
		Processor = processor;
		Memory = memory;
		Storage = storage;
	}

	public void PrintInfo()
	{
		Console.WriteLine($"Производител: {Brand}");
		Console.WriteLine($"Модел: {Model}");

		Console.WriteLine("\nПроцесор:");
		Console.WriteLine($"  Модел: {Processor.Model}");
		Console.WriteLine($"  Ядра: {Processor.Cores}");

		Console.WriteLine("\nПамет:");
		Console.WriteLine($"  Размер: {Memory.SizeGB} GB");
		Console.WriteLine($"  Тип: {Memory.Type}");

		Console.WriteLine("\nStorage:");
		Console.WriteLine($"  Размер: {Storage.SizeGB} GB");
		Console.WriteLine($"  Тип устройство: {Storage.DeviceType}");
	}
}

class Program
{
	static void Main()
	{
		Processor processor = new Processor("Intel i7-12700K", 12);
		Memory memory = new Memory(16, "DDR4");
		Storage storage = new Storage(512, "SSD");

		Computer computer = new Computer(
			"Dell",
			"XPS 15",
			processor,
			memory,
			storage
		);

		computer.PrintInfo();
	}
}