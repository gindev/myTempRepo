﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            NoteService service = new NoteService();
            string choice = "";

            do
            {
                Console.WriteLine("\nПРИЛОЖЕНИЕ ЗА БЕЛЕЖКИ ");
                Console.WriteLine("1. Добавяне на бележка");
                Console.WriteLine("2. Показване на бележките");
                Console.WriteLine("3. Запис във файл");
                Console.WriteLine("4. Зареждане от файл");
                Console.WriteLine("5. Изход");
                Console.Write("Изберете опция: ");

                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Заглавие: "); string t = Console.ReadLine();
                        Console.Write("Съдържание: "); string c = Console.ReadLine();
                        service.AddNote(new Note(t, c));
                        break;

                    case "2":
                        service.ShowAllNotes();
                        break;

                    case "3":
                        Console.Write("Име на файл (напр. notes.txt): ");
                        string savePath = Console.ReadLine();
                        service.SaveToFile(savePath);
                        break;

                    case "4":
                        Console.Write("Име на файл за четене: ");
                        string loadPath = Console.ReadLine();
                        service.LoadFromFile(loadPath);
                        break;

                    case "5":
                        Console.WriteLine("Приключване на работа...");
                        break;

                    default:
                        Console.WriteLine("Невалидна опция!");
                        break;
                }

            } while (choice != "5");
        }
    }
}
        
    

