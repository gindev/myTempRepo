﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class Note
    {

        private string title;
        private string content;
        private DateTime dateCreated;

        public string Title
        {
            get { return this.title; }
            set { this.title = value; }
        }

        public string Content
        {
            get { return this.content; }
            set { this.content = value; }
        }

        public DateTime DateCreated
        {
            get { return this.dateCreated; }
            set { this.dateCreated = value; }
        }

        public Note(string title, string content)
        {
            this.title = title;
            this.content = content;
            this.dateCreated = DateTime.Now; 
        }
    }
}
    

