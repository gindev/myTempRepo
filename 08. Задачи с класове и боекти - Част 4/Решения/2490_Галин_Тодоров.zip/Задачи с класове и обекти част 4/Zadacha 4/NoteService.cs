﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class NoteService
    {
        private List<Note> notes;

        public NoteService()
        {
            this.notes = new List<Note>();
        }

        public void AddNote(Note note)
        {
            this.notes.Add(note);
            Console.WriteLine("Бележката е добавена успешно.");
        }

        public void ShowAllNotes()
        {
            Console.WriteLine("\n СПИСЪК С БЕЛЕЖКИ ");
            if (notes.Count == 0)
            {
                Console.WriteLine("Няма налични бележки.");
                return;
            }

            for (int i = 0; i < notes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {notes[i].Title} | {notes[i].Content} (Създадена на: {notes[i].DateCreated})");
            }
        }

        public void SaveToFile(string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (var note in notes)
                    {
                        
                        writer.WriteLine($"{note.Title};{note.Content};{note.DateCreated}");
                    }
                }
                Console.WriteLine("Данните са записани успешно във файл.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Грешка при запис: " + ex.Message);
            }
        }

        public void LoadFromFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine("Файлът не съществува.");
                    return;
                }

                notes.Clear(); 
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(';');
                    if (parts.Length >= 2)
                    {
                        Note n = new Note(parts[0], parts[1]);
                        if (parts.Length == 3) n.DateCreated = DateTime.Parse(parts[2]);
                        notes.Add(n);
                    }
                }
                Console.WriteLine("Данните са заредени успешно от файл.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Грешка при зареждане: " + ex.Message);
            }
        }
    }
}
    

