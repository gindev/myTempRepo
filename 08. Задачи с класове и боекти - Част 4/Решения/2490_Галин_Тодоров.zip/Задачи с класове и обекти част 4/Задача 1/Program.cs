﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Processor cpu = new Processor("Intel Core i7-10750H", 6);
            RAM ram = new RAM(16, "DDR4");
            Storage disk = new Storage(1512, "SSD + HDD"); 

            
            PC myLaptop = new PC("HP", "Pavilion Gaming 15", cpu, ram, disk);

            
            myLaptop.PrintInfo();

            
          
            Console.ReadLine();
        }
    }
}
        
    
