﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_1
{
    internal class PC
    {
        private string manufacturer;
        private string model;
        private Processor processor;
        private RAM memory;
        private Storage storage;


        public PC(string manufacturer, string model, Processor processor, RAM memory, Storage storage)
        {
            this.manufacturer = manufacturer;
            this.model = model;
            this.processor = processor;
            this.memory = memory;
            this.storage = storage;
        }

        public void PrintInfo()
        {
           
            Console.WriteLine($"КОМПЮТЪР: {this.manufacturer} {this.model}");
            Console.WriteLine($"ПРОЦЕСОР: {this.processor.Model}, Ядра: {this.processor.Cores}");
            Console.WriteLine($"RAM:      {this.memory.SizeGB} GB, Тип: {this.memory.Type}");
            Console.WriteLine($"ДИСК:     {this.storage.SizeGB} GB, Тип: {this.storage.Type}");
            
        }
    }
}