﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_1
{
    internal class RAM
    {
        private int sizeGB;
        private string type;

        public int SizeGB
        {
            get { return sizeGB; }
            set { sizeGB = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public RAM(int sizeGB, string type)
        {
            this.sizeGB = sizeGB;
            this.type = type;
        }
    }
}
