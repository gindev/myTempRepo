﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentRegistryService registry = new StudentRegistryService();
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n- Меню ");
                Console.WriteLine("1. Добавяне на студент");
                Console.WriteLine("2. Показване на всички студенти");
                Console.WriteLine("3. Запис в JSON файл");
                Console.WriteLine("4. Зареждане от JSON файл");
                Console.WriteLine("5. Изход");
                Console.Write("Избор: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Student s = new Student();
                        Console.Write("Име: "); s.FirstName = Console.ReadLine();
                        Console.Write("Фамилия: "); s.LastName = Console.ReadLine();
                        Console.Write("ФН: "); s.FacultyNumber = Console.ReadLine();
                        Console.Write("Специалност: "); s.Specialty = Console.ReadLine();
                        Console.Write("Среден успех: "); s.AverageGrade = double.Parse(Console.ReadLine());
                        registry.AddStudent(s);
                        break;
                    case "2":
                        registry.ShowAllStudents();
                        break;
                    case "3":
                        Console.Write("Въведете име на файл (напр. students.json): ");
                        registry.SaveToJson(Console.ReadLine());
                        break;
                    case "4":
                        Console.Write("Въведете име на файл за зареждане: ");
                        registry.LoadFromJson(Console.ReadLine());
                        break;
                    case "5":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Невалиден избор.");
                        break;
                }
            }
        }
    }
}
    
