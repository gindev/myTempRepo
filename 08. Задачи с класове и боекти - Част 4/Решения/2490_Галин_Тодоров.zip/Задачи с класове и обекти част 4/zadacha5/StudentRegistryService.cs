﻿
using System.IO;
using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class StudentRegistryService
    {
        private List<Student> students = new List<Student>();

        public void AddStudent(Student student)
        {
            students.Add(student);
            Console.WriteLine("Студентът е добавен успешно.");
        }

        public void ShowAllStudents()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("Списъкът е празен.");
                return;
            }

            Console.WriteLine("\nСписък със студенти:");
            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {students[i]}");
            }
        }

        public void SaveToJson(string filePath)
        {
            try
            {
                string jsonString = JsonSerializer.Serialize(students, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, jsonString);
                Console.WriteLine("Данните са записани успешно в JSON файл.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Грешка при запис: {ex.Message}");
            }
        }

        public void LoadFromJson(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string jsonString = File.ReadAllText(filePath);
                    students = JsonSerializer.Deserialize<List<Student>>(jsonString);
                    Console.WriteLine("Данните са заредени успешно от JSON файл.");
                }
                else
                {
                    Console.WriteLine("Файлът не съществува.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Грешка при зареждане: {ex.Message}");
            }
        }
    }
}

