﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Student
    {
        private string firstName;
        private string lastName;
        private string facultyNumber;
        private string specialty;
        private double averageGrade;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string FacultyNumber
        {
            get { return facultyNumber; }
            set { facultyNumber = value; }
        }

        public string Specialty
        {
            get { return specialty; }
            set { specialty = value; }
        }

        public double AverageGrade
        {
            get { return averageGrade; }
            set { averageGrade = value; }
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} | ФН: {FacultyNumber} | Специалност: {Specialty} | Успех: {AverageGrade:F2}";
        }
    }
}

