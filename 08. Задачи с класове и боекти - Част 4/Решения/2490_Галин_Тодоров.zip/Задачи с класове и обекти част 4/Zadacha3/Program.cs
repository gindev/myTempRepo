﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LibraryService service = new LibraryService();
            string choice = "";

            
            do
            {
                Console.WriteLine("\nКаталог Книги:");
                Console.WriteLine("1. Добави книга");
                Console.WriteLine("2. Всички книги");
                Console.WriteLine("3. Търси по автор");
                Console.WriteLine("4. Изход");
                Console.Write("Избор: ");

                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Заглавие: "); string t = Console.ReadLine();
                        Console.Write("Година: "); int y = int.Parse(Console.ReadLine());
                        Console.Write("Име на автор: "); string fn = Console.ReadLine();
                        Console.Write("Фамилия: "); string ln = Console.ReadLine();

                        service.AddBook(new Book(t, y, new Author(fn, ln)));
                        Console.WriteLine("Успешно добавяне!");
                        break;

                    case "2":
                        service.ShowAllBooks();
                        break;

                    case "3":
                        Console.Write("Въведи име: ");
                        service.FindBooksByAuthor(Console.ReadLine());
                        break;

                    case "4":
                        
                        break;

                    default:
                        Console.WriteLine("Невалиден избор!");
                        break;
                }

            } while (choice != "4");
        }
    }
}
        
    

