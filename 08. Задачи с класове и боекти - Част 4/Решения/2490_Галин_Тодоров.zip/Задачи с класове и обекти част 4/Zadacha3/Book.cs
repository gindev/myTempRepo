﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha3
{
    internal class Book
    {
        private string title;
        private int year;
        private Author author;

        public string Title
        {
            get { return this.title; }
            set { this.title = value; }
        }

        public int Year
        {
            get { return this.year; }
            set { this.year = value; }
        }

        public Author Author
        {
            get { return this.author; }
            set { this.author = value; }
        }

        public Book(string title, int year, Author author)
        {
            this.title = title;
            this.year = year;
            this.author = author;
        }
    }
}
    

