﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha3
{
    internal class LibraryService
    {
        private List<Book> _collection;

        public LibraryService()
        {
            this._collection = new List<Book>();
        }

        public void AddBook(Book b)
        {
            this._collection.Add(b);
        }

        public void ShowAllBooks()
        {
            Console.WriteLine("\nСписък с книги ");
            if (_collection.Count == 0)
            {
                Console.WriteLine("Няма добавени книги.");
                return;
            }

            foreach (var b in _collection)
            {
                
                Console.WriteLine($"-> {b.Author.LastName.ToUpper()}, {b.Author.FirstName[0]}. | \"{b.Title}\" | Релиз: {b.Year}");
            }
        }

        public void FindBooksByAuthor(string name)
        {
            Console.WriteLine($"\nРезултати за: [{name}]");
            bool match = false;
            foreach (var b in _collection)
            {
                if (b.Author.FirstName.ToLower().Contains(name.ToLower()) ||
                    b.Author.LastName.ToLower().Contains(name.ToLower()))
                {
                    Console.WriteLine($"* {b.Title} (публикувана през {b.Year} г.)");
                    match = true;
                }
            }
            if (!match) Console.WriteLine("Няма открити заглавия за този автор.");
        }
    }
}
    
