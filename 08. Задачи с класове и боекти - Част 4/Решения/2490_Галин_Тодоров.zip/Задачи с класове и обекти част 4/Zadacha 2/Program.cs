﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer myClient = new Customer("Galin Todorov", "-");

            
            Product p1 = new Product("Мишка", 250);
            Product p2 = new Product("Клавиатура", 400);
            Product p3 = new Product("Монитор",550);

            
            Order myOrder = new Order("PS001", myClient);

            myOrder.AddItem(new OrderItem(p1, 2));
            myOrder.AddItem(new OrderItem(p2, 1));
            myOrder.AddItem(new OrderItem(p3, 1));

            
            myOrder.PrintOrderInfo();

            Console.ReadLine();
        }
    }
}
        
    
