﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class OrderItem
    {
        private Product product;
        private int quantity;

        public Product Product
        {
            get { return this.product; }
            set { this.product = value; }
        }

        public int Quantity
        {
            get { return this.quantity; }
            set { this.quantity = value; }
        }

        public OrderItem(Product product, int quantity)
        {
            this.product = product;
            this.quantity = quantity;
        }

        public double GetTotalPrice()
        {
            return this.product.Price * this.quantity;
        }
    }
}

