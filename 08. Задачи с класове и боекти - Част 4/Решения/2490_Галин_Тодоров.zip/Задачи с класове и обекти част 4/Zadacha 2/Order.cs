﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Order
    {

        private string orderNumber;
        private Customer customer;
        private List<OrderItem> items;

        public string OrderNumber
        {
            get { return this.orderNumber; }
            set { this.orderNumber = value; }
        }

        public Customer Customer
        {
            get { return this.customer; }
            set { this.customer = value; }
        }

        public Order(string orderNumber, Customer customer)
        {
            this.orderNumber = orderNumber;
            this.customer = customer;
            this.items = new List<OrderItem>();
        }

        public void AddItem(OrderItem item)
        {
            this.items.Add(item);
        }

        public double GetOrderTotal()
        {
            double total = 0;
            foreach (OrderItem item in this.items)
            {
                total += item.GetTotalPrice();
            }
            return total;
        }

        public void PrintOrderInfo()
        {
            Console.WriteLine($"Поръчка #{this.orderNumber}");
            Console.WriteLine($"Клиент: {this.customer.Name}, Телефон: {this.customer.Phone}");
            Console.WriteLine("\nПозиции:");

            int count = 1;
            foreach (OrderItem item in this.items)
            {
                Console.WriteLine($"{count}. {item.Product.Name}  {item.Quantity} бр.  Ед. цена: {item.Product.Price:F2}  Стойност: {item.GetTotalPrice():F2}");
                count++;
            }

            Console.WriteLine($"\nОбща стойност на поръчката: {this.GetOrderTotal():F2} лв.");
        }
    }
}

