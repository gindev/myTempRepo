﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Customer
    {
        private string name;
        private string phone;

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public string Phone
        {
            get { return this.phone; }
            set { this.phone = value; }
        }

        public Customer(string name, string phone)
        {
            this.name = name;
            this.phone = phone;
        }
    }
}

