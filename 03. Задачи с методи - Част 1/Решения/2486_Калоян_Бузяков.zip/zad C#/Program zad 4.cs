﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {
                Console.Write("Въведи температура (пример: 32C или 100F): ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Невалиден вход!");
                    continue;
                }

                char unit = char.ToUpper(input[input.Length - 1]);
                string numberPart = input.Substring(0, input.Length - 1);

                if (!double.TryParse(numberPart, out double value))
                {
                    Console.WriteLine("Трябва да има число отпред!");
                    continue;
                }

                if (unit == 'C')
                {
                    double fahrenheit = value * 9 / 5 + 32;
                    Console.WriteLine($"{value}C = {fahrenheit:F2}F");
                    break;
                }
                else if (unit == 'F')
                {
                    double celsius = (value - 32) * 5 / 9;
                    Console.WriteLine($"{value}F = {celsius:F2}C");
                    break;
                }
                else
                {
                    Console.WriteLine("Трябва да завършва с C или F!");
                }
            }

        }
    }
}
