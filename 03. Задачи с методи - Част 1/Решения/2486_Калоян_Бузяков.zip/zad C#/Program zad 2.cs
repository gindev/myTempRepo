﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string input = Console.ReadLine();
            string[] parts = input.Split(',');

            int[] numbers = new int[parts.Length];

            for (int i = 0; i < parts.Length; i++)
            {
                numbers[i] = int.Parse(parts[i]);
            }

            int target = int.Parse(Console.ReadLine());

            int count = CountOccurrences(numbers, target);

            Console.WriteLine(target + " се среща " + count + " пъти");
        }

        static int CountOccurrences(int[] arr, int num)
        {
            int count = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == num)
                {
                    count++;
                }
            }

            return count;

        }
    }
}
