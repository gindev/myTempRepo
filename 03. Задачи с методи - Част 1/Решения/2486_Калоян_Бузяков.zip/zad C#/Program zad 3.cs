﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());

            OburnatoChislo(number);
        }

        static void OburnatoChislo(int num)
        {
            while (num > 0)
            {
                int chisla = num % 10;
                Console.Write(chisla);
                num = num / 10;
            }
        }
    }
}
