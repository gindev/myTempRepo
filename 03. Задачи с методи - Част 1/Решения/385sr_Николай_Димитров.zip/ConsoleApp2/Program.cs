﻿// 1. Създайте програма, която приема от конзолата стринг, подава го на метод,
// който приема стринг и отпечатва в конзолата "Здравей, <name>!" (например "Здравей, Петър!").
//{
//    string name = Console.ReadLine();
//    SayHello(name);
//}

//static void SayHello(string name)
//{
//    Console.WriteLine($"Здравей, {name}!");
//}

// 2. Създайте програма която приема от конзолата два реда. Първия ред съдържа числа,
// разделени със запетая и ги попълва в масив. От втория ред приема число. Напишете метод,
// който намира колко пъти числото от втория ред се среща в масива от първия, след което отпечатайте
// на конзолата въпросното число и колко пъти се съдържа то в масива

//int[] num = Console.ReadLine().Split(',').Select(int.Parse).ToArray();
//int targetnum = int.Parse(Console.ReadLine());

//int count = CountSys(num, targetnum);

//Console.WriteLine($"{targetnum} - {count} пъти");

//static int CountSys(int[] array, int number)
//{
//    int counter = 0;

//    foreach (int i in array)
//    {
//        if (i == number)
//        {
//            counter++;
//        }
//    }
//    return counter;
//}

// 3. Създайте програма, която приема от конзолата число. Напишете метод,
// който отпечатва цифрите на числото в обратен ред. Например 256, трябва да бъде отпечатано като 652.
//Console.WriteLine("Въведете число:");
//int number = int.Parse(Console.ReadLine());

//int reversed = ReversedNumber(number);
//Console.WriteLine($"Обратното число е: {reversed}");

//static int ReversedNumber(int number)
//{
//    int reversed = 0;
//    while (number != 0)
//    {
//        int digit = number % 10;
//        reversed = reversed * 10 + digit;
//        number = number / 10;
//    }
//    return reversed;
//}

// 4. Създайте програма, която приема от конзолата число и буква слети. Числото представлява стойността на температура,
// а буквата определя скалата по която е измерена (в Целзий или Фаренхайт). Напишете метод, който приема два параметъра,
// стойността на температурата и скалата, по която е измерена и конвертира температурата от едната скала към другата.
// След това отпечатайте резултата на конзолата до втория знак след десетичния знак. Формулата за преобразуване е както следва: 

//Към Целзий: (0°F - 32) *5 / 9 = 0C°
//Към Фаренхайт (0°C * 9/5) + 32 = 32°F


//string input = Console.ReadLine();
//string numberPart = input.Substring(0, input.Length - 1);
//char scale = input[input.Length - 1];
//double temperature = double.Parse(numberPart);
//double result = ConvertTemperature(temperature, scale);

//Console.WriteLine($"{result:F2}");
//static double ConvertTemperature(double temp, char scale)
//{
//    if (scale == 'F')
//    {
//        return (temp - 32) * 5 / 9;
//    }

//    else if (scale == 'C')
//    {
//        return (temp * 9 / 5) + 32;
//    }
//    return 0;
//}

// 5. Напишете програма, която намира редицата на Фибоначи до дадено число чрез метод. Числото се подава на конзолата, а редицата
// започва от числата 0 и 1. Формулата за редица на Фибоначи е: F(n) = F(n-1) + F(n-2)​ 

//Console.Write("Въведете число: ");
//int n = int.Parse(Console.ReadLine());

//PrintFibonacci(n);


//static void PrintFibonacci(int limit)
//{
//    int a = 0, b = 1;

//    Console.Write(a + " " + b + " ");

//    while (true)
//    {
//        int next = a + b;
//        if (next > limit)
//            break;

//        Console.Write(next + " ");
//        a = b;
//        b = next;
//    }
//}

// 6. Напишете програма, която изчислява факториела на дадено число, използвайки рекурсивен метод.
// Формулата за изчисление е следната: n! = n * (n - 1)!

//Console.Write("Въведете число: ");
//int n = int.Parse(Console.ReadLine());
//long result = Factorial(n);
//Console.WriteLine($"Факториелът на {n} е {result}");

//static long Factorial(int n)
//{
//    if (n == 0 || n == 1)
//        return 1;

//    return n * Factorial(n - 1);
//}