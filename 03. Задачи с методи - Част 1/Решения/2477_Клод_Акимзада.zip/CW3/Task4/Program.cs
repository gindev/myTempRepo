﻿// Създайте програма, която приема от конзолата число и буква слети.
// Числото представлява стойността на температура, а буквата определя скалата по която е измерена (в Целзий или Фаренхайт).
// Напишете метод, който приема два параметъра, стойността на температурата и скалата, по която е измерена и конвертира температурата от едната скала към другата.
// След това отпечатайте резултата на конзолата до втория знак след десетичния знак.
// Формулата за преобразуване е както следва: 
// Към Целзий: (0°F - 32) *5 / 9 = 0C°
// Към Фаренхайт (0°C * 9/5) + 32 = 32°F


string input = Console.ReadLine();

if (string.IsNullOrEmpty(input))
{
    Console.WriteLine("Input invalid!");
    return;
}

char op  = input[input.Length - 1];
var numberInput = input.Substring(0, input.Length - 1);

if (!double.TryParse(numberInput, out double temperature))
{
    Console.WriteLine("Invalid temperature value!");
    return;
}

Console.WriteLine(ConvertTemperature(temperature, op));

static double ConvertTemperature(double temp, char scale)
{
    if (scale == 'C' || scale == 'c')
    {
        return Math.Round((double)((temp * 9 / 5) + 32), 2);
    }
    else if (scale == 'F' || scale == 'f')
    {
        return Math.Round((double)((temp - 32) * 5 / 9), 2);
    }
    else
    {
        throw new ArgumentException("Invalid scale! Use 'C' for Celsius or 'F' for Fahrenheit.");
    }
}
