﻿// Създайте програма, която приема от конзолата стринг, подава го на метод, който приема стринг и отпечатва в конзолата "Здравей, <name>!" (например "Здравей, Петър!").

string input = Console.ReadLine();

Greet(input);



static void Greet(string name)
{
    if (string.IsNullOrWhiteSpace(name))
    {
        Console.WriteLine("Please enter a valid name");
        return;
    }
    Console.WriteLine($"Hello, {name}!");
}