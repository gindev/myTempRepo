﻿// Напишете програма, която изчислява факториела на дадено число, използвайки рекурсивен метод.
// Формулата за изчисление е следната: n! = n * (n - 1)!

Console.WriteLine("Enter a positive integer to calculate its factorial");
string? input = Console.ReadLine();

if (!int.TryParse(input, out int n) || n < 0)
{
    Console.WriteLine("Input must be a valid positive integer.");
    return;
}

long result = CalculateFactorial(n);
Console.WriteLine($"{n}! = {result}");

long CalculateFactorial(int current)
{
    if (current <= 1)
    {
        return 1;
    }

    return current * CalculateFactorial(current - 1);
}