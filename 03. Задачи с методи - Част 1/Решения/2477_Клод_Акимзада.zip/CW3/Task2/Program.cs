﻿// Създайте програма която приема от конзолата два реда. Първия ред съдържа числа, разделени със запетая и ги попълва в масив. От втория ред приема число. Напишете метод, който намира колко пъти числото от втория ред се среща в масива от първия, след което отпечатайте на конзолата въпросното число и колко пъти се съдържа то в масива.

Console.WriteLine("Enter numbers separated by a comma (1, 2, 3, 2, 4):");
string? input1 = Console.ReadLine();

Console.WriteLine("Enter the number you're searching for");
string? input2 = Console.ReadLine();

if (string.IsNullOrWhiteSpace(input1))
{
    Console.WriteLine("Input1 cannot be null or whitespace");
    return;
}

if (string.IsNullOrWhiteSpace(input2))
{
    Console.WriteLine("Input2 cannot be null or whitespace");
    return;
}


int[] numbers = input1.Split(',')
                      .Select(s => s.Trim())
                      .Where(s => int.TryParse(s, out _))
                      .Select(int.Parse)
                      .ToArray();

bool isValidNumber = int.TryParse(input2, out int targetNumber);

if (!isValidNumber)
{
    Console.WriteLine("Input2 must be a valid integer");
    return;
}


int occurrences = CountOccurrences(numbers, targetNumber);
Console.WriteLine($"The number {targetNumber} occurs {occurrences} times in the array");


int CountOccurrences(int[] numbers, int targetNumber)
{
    return numbers.Count(n => n == targetNumber);
}