﻿// Създайте програма, която приема от конзолата число. Напишете метод, който отпечатва цифрите на числото в обратен ред. Например 256, трябва да бъде отпечатано като 652.


Console.WriteLine("Enter a number to reverse:");
string? input = Console.ReadLine();

if (string.IsNullOrWhiteSpace(input))
{
    Console.WriteLine("Input cannot be null or whitespace!");
    return;
}

bool isValidNumber = int.TryParse(input, out int _);

if (!isValidNumber)
{
    Console.WriteLine("Input is not a valid number!");
    return;
}

PrintReversedDigits(input);


void PrintReversedDigits(string numberString)
{
    string reversed = string.Join("", numberString.Reverse());

    Console.WriteLine(reversed);
}
