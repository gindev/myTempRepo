﻿// Напишете програма, която намира редицата на Фибоначи до дадено число чрез метод.
// Числото се подава на конзолата, а редицата започва от числата 0 и 1.
// Формулата за редица на Фибоначи е: F(n) = F(n - 1) + F(n - 2)

Console.WriteLine("Enter a maximum number for the Fibonacci sequence:");
string? input = Console.ReadLine();

if (!int.TryParse(input, out int n))
{
    Console.WriteLine("Input must be a valid integer.");
    return;
}


PrintFibonacci(n);


//void PrintFibonacci(int max)
//{
//    if (max < 0)
//    {
//        Console.WriteLine("Number must be a positive value");
//        return;
//    }

//    int a = 0;
//    int b = 1;

//    if (max >= 0) Console.Write($"{a} ");
//    if (max >= 1) Console.Write($"{b} ");

//    while (true)
//    {
//        int next = a + b;

//        if (next > max)
//        {
//            break;
//        }

//        Console.Write($"{next} ");

//        a = b;
//        b = next;
//    }

//    Console.WriteLine();
//}


// same method recursive

static void PrintFibonacci(int remaining, int a = 0, int b = 1)
{
    if (remaining < 0)
    {
        Console.WriteLine("Number must be a positive value");
        return;
    }

    Console.Write($"{a} ");

    if (remaining == 0) return;

    PrintFibonacci(remaining - 1, b, a + b);
}