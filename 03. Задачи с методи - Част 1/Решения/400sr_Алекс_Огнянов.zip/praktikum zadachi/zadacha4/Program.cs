﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {

        static string Convert(double num, string symbol) 
        {
            //(0°F - 32) *5 / 9 = 0C°
            double newnum = 0.0;
            if (symbol.Equals("F"))
            {
                newnum = (num - 32) * 5 / 9;
                symbol = "C";
            }
            else if (symbol.Equals("C"))
            {
                newnum = (num * 5 / 9) + 32;
                symbol = "F";
            }
            else return "invalid symbol";

            string newTemp = $"{Math.Round(newnum, 2)}{symbol}";

            return newTemp;
        }
        static void Main(string[] args)
        {
            string temperature = Console.ReadLine();

            double number = 0.0;
            string symbol = temperature[temperature.Length - 1].ToString();


            for (int i = 0; i <temperature.Length-1 ; i++)
            {
               int digit = temperature[i] - '0';

                number = number * 10 + digit;
            }

            Console.WriteLine($"New temp is {Convert(number,symbol)}");

        }
    }
}
