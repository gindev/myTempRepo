﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static List<int> Fibonacci(int end)
        {
            List<int> numbers = new List<int>();
            numbers.Add(0);
            numbers.Add(1);
            int i = 2;
            while (true)
            {
                int next = numbers[i - 1] + numbers[i - 2];
                if (next > end) break;
                numbers.Add(next);

                i++;
            }

            return numbers;
        }

        static void Main(string[] args)
        {
            int end = int.Parse(Console.ReadLine());
            List<int> numbers = Fibonacci(end);
            foreach (int num in numbers)
            {
                Console.Write($"{num}, ");
            }
        }
    }
}
