﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Program
    {
        static string Greeting(string name)
        {
          string greeting =$"Здравейте,{name}!";
          return greeting;
        }
        static void Main(string[] args)
        
        {
            string name= Console.ReadLine();
            Console.WriteLine(Greeting(name));

        }
    }
}
