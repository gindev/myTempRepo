﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Program
    {
        static int Factoriel(int num)
        {

            if (num == 0 || num == 1)
            {
                return 1;
            }

            return num*Factoriel(num - 1);
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine(Factoriel(n));
        }
    }
}
