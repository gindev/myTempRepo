﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Program
    {
        static int ReverseNumber(int num)
        {
            int newnum = 0;
            while (num > 0)
            {
                newnum = newnum * 10 + num % 10;
                num /= 10;
            }
            return newnum;
        }
        static void Main(string[] args)
        {
            int chislo;
            chislo = int.Parse(Console.ReadLine());
            chislo = ReverseNumber(chislo);
            Console.WriteLine($"Reverse number:{chislo}");


        }
    }
}
