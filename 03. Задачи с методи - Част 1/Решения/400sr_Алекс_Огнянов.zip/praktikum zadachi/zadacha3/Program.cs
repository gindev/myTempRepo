﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Program
    {
        static int Finder(int[] array, int num)
        {
            int counter=0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i]==num)
                {
                    counter++;
                }
                
            }
            return counter;
        }

        static void Main(string[] args)
        {
            int[] nums = Console.ReadLine().Split(',').Select(x => int.Parse(x)).ToArray();
            int wantedNumber = int.Parse(Console.ReadLine());
            int counter = Finder(nums, wantedNumber);
            Console.WriteLine($"the wanted number {wantedNumber} is found {counter} times");

        }
    }
}
