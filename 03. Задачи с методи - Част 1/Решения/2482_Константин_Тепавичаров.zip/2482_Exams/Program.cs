﻿namespace _2482_Exams
{
    internal class Program
    {
        static void Main(string[] args)
        {
           //Task1();
           //Task2();
           //Task3();
           //Task4();
           //Task5();
           //Task6();
        }
        static void Task1()
        {
            string name = Console.ReadLine();
            Console.WriteLine($"Здравей, {name}");
        }
        static void Task2()
        {
            Console.WriteLine("Въведете масив отделен със запетаи:");
            int[] numbers = Console.ReadLine().Split(',').Select(int.Parse).ToArray();
            Console.WriteLine("Въведете числото, което ще броим в масива:");
            int target = int.Parse(Console.ReadLine());
            int count = 0;
            foreach(int number in numbers)
            {
                if (number == target)
                {
                    count++;
                }
            }
            Console.WriteLine($"Числото {target} се среща {count} пъти.");
        }
        static void Task3()
        {
            Console.WriteLine("Въведи число:");
            int number = int.Parse(Console.ReadLine());
            while(number > 0)
            {
                Console.Write(number % 10);
                number /= 10;
            }

        }
        static void Task4()
        {
            Console.WriteLine("Въведи температура:");
            string input = Console.ReadLine();
            double value = double.Parse(input.Substring(0, input.Length - 1));
            char scale = input[input.Length - 1];
            double result;
            if (scale == 'F' || scale == 'f')
            {
                result = (value - 32) * 5 / 9;
            }
            else
            {
                result = (value * 9 / 5) + 32;
            }
            Console.WriteLine($"{result:F2}");
        }
        static void Task5()
        {
            Console.WriteLine("Въведи число:");
            int n = int.Parse(Console.ReadLine());
            int a = 0, b = 1;
            Console.Write(a + " " + b + " ");
            while (true)
            {
                int next = a + b;
                if (next > n)
                {
                    break;
                }
                Console.Write(next + " ");
                a = b;
                b = next;
            }
        }
        static void Task6()
        {
            Console.WriteLine("Въведи число:");
            int n = int.Parse(Console.ReadLine());
            long result = Factorial(n);
            Console.WriteLine(result);
        }
        static long Factorial(int n)
        {
            if(n == 0 || n == 1)
            {
                return 1;
            }
            return n * Factorial(n - 1);
        }
    }
}
