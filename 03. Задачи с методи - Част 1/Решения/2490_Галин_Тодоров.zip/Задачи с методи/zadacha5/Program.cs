﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Напишете програма, която намира редицата на Фибоначи до дадено число чрез метод. Числото се подава на конзолата, а редицата започва от числата 0 и 1. Формулата за редица на Фибоначи е: F(n) = F(n-1) + F(n-2)


            int n = int.Parse(Console.ReadLine());

            Console.WriteLine($"Редицата на Фибоначи до {n}:");
            PrintFibonacci(n);
        }

        static void PrintFibonacci(int max)
        {
            int a = 0;
            int b = 1;

            while (a <= max)
            {
                Console.Write(a + " ");

              
                int next = a + b;
                a = b;
                b = next;
            }
            Console.WriteLine();
        }
    }
}
   

