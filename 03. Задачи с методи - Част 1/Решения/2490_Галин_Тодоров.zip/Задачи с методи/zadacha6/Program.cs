﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Напишете програма, която изчислява факториела на дадено число, използвайки рекурсивен метод. Формулата за изчисление е следната: n! = n * (n - 1)!

            int n = 5;
            long result = Factorial(n);

            Console.WriteLine($"Факториелът на {n} е {result}");
        }

        static long Factorial(int n)
        {
          
            if (n <= 1)
                return 1;

           
            return n * Factorial(n - 1);
        }
    }
}