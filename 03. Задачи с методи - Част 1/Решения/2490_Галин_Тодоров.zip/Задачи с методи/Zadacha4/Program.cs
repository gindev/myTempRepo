﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Създайте програма, която приема от конзолата число и буква слети. Числото представлява стойността на температура, а буквата определя скалата по която е измерена (в Целзий или Фаренхайт). Напишете метод, който приема два параметъра, стойността на температурата и скалата, по която е измерена и конвертира температурата от едната скала към другата. След това отпечатайте резултата на конзолата до втория знак след десетичния знак. Формулата за преобразуване е както следва: 

            // Създайте програма, която приема от конзолата число и буква слети.Числото представлява стойността на температура, а буквата определя скалата по която е измерена(в Целзий или Фаренхайт).Напишете метод, който приема два параметъра, стойността на температурата и скалата, по която е измерена и конвертира температурата от едната скала към другата.След това отпечатайте резултата на конзолата до втория знак след десетичния знак.Формулата за преобразуване е както следва:

            //Към Целзий: (0°F - 32) *5 / 9 = 0C°

            //Към Фаренхайт(0°C * 9 / 5) +32 = 32°F

            string input = Console.ReadLine();

            char Tempscale = input[input.Length - 1];                   
            double temperature = double.Parse(input.Substring(0, input.Length - 1));  

            double converted = ConvertTemperature(temperature, Tempscale);  
            char targetScale = (Tempscale == 'C' || Tempscale == 'c') ? 'F' : 'C';

            Console.WriteLine($"{converted:F2}{targetScale}");
        }

        static double ConvertTemperature(double temp, char scale)
        {
            if (scale == 'C' || scale == 'c')
                return temp * 9 / 5 + 32;   
            else
                return (temp - 32) * 5 / 9;  
        }
    }
}