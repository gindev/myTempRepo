﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha1
{
    internal class Program


    {

        /*
        //Създайте програма, която приема от конзолата стринг, подава го на метод, който приема стринг и отпечатва в конзолата "Здравей, <name>!" (например "Здравей, Петър!").
        
        */
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            PrintName(name);
        }

        static void PrintName(string name)
        {
            Console.WriteLine("Здравей, " + name + "!");
        }
    }

}