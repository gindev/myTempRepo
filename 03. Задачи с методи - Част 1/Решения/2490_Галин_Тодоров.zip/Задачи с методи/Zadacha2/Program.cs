﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)


        {


            /*
             * 
             * Създайте програма която приема от конзолата два реда. 
             * Първия ред съдържа числа, разделени със запетая и ги попълва в масив. 
             * От втория ред приема число. Напишете метод, който намира колко пъти числото от втория ред се среща в масива от първия, след което отпечатайте на конзолата въпросното число и колко пъти се съдържа то в масива.
             * Създайте програма която приема от конзолата два реда. 
             * Първия ред съдържа числа, разделени със запетая и ги попълва в масив. 
             * От втория ред приема число. Напишете метод, който намира колко пъти числото от втория ред се среща в масива от първия, след което отпечатайте на конзолата въпросното число и колко пъти се съдържа то в масива.

            */
            int[] N= Array.ConvertAll(Console.ReadLine().Split(','), int.Parse);

            int NumSecondRow = int.Parse(Console.ReadLine());

            int count = CountNumber(N, NumSecondRow);

            Console.WriteLine(NumSecondRow + " se sreshta  " + count + " puti v masiva.");
        }

        static int CountNumber(int[] array, int N)
        {
            int count = 0;
            foreach (int n in array)
                if (n == N) count++;
            return count;
        }
    }
}