﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Създайте програма, която приема от конзолата число. Напишете метод, който отпечатва цифрите на числото в обратен ред. Например 256, трябва да бъде отпечатано като 652.

            int N = int.Parse(Console.ReadLine());

            ObratenRed(N);
        }

        static void ObratenRed(int num)
        {
            while (num > 0)
            {
                int digit = num % 10;  
                Console.Write(digit);   
                num = num / 10;         
            }

            Console.WriteLine(); 
        }
    }
}
