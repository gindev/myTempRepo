﻿using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.Marshalling;

namespace _23._03._2026
{
	internal class Program
	{
		/////////////////////////////////////////////////// 1
		//static void Main(string[] args)
		//{
		//	string name = Console.ReadLine();
		//	SayHello(name);
		//}
		//static void SayHello(string name)
		//{
		//	Console.WriteLine($"Здравей,{name}!");
		//}

		//////////////////////////////////////////////// 2
		//static void Main()
		//{

		//	int[] numbers = Console.ReadLine()
		//		.Split(',')
		//		.Select(int.Parse)
		//		.ToArray();

		//		int target = int.Parse(Console.ReadLine());

		//	   int count = CountOccurrences(numbers, target);

		//	   Console.WriteLine($"{target} - {count} пъти");
		//}
		//static int CountOccurrences(int[] array, int number)
		//{
		//	int counter = 0;

		//	foreach (int item in array)
		//	{
		//		if (item == number)
		//		{
		//			counter++;
		//		}
		//	}

		//	return counter;
		//}

		///////////////////////////////////////////// 3

		//static void Main()
		//{
		//	Console.Write("Въведи число: ");
		//	int number = int.Parse(Console.ReadLine());
		//	PrintReversedNumber(number);


		//}
		//static void PrintReversedNumber(int number)
		//{
		//	while (number != 0)
		//	{
		//		int digit = number % 10;
		//		Console.Write(digit);
		//		number /= 10;
		//	}
		//}

		///////////////////////////////////////////// 4
		//static void Main()
		//{
		//	Console.Write("Въведи темлературата: ");
		//	string input = Console.ReadLine();
		//	char scale = char.ToUpper(input[input.Length - 1]);
		//	double temperature = double.Parse(input.Substring(0, input.Length - 1));
		//	double result = ConvertTemperature(temperature, scale);
		//	Console.WriteLine($"{result:F2}");
		//}
		//static double 
		//ConvertTemperature(double temperature, char scale)
		//{
		//if (scale == 'F')
		//{
		//		return (temperature - 32) * 5 / 9;
		//}
		//else if (scale == 'C')
		//{
		//return (temperature * 9 / 5) + 32;
		//}
		//else
		//{
		//		Console.WriteLine("Невалидна Скала!");
		//		return 0;
		//}
		//}

		/////////////////////////////////////////////// 5
		//static void Main()
		//{
		//	Console.Write("Въведете брой елементи: ");
		//	int n = int.Parse(Console.ReadLine());
		//	PrintFibonacci(n);
		//}
		//static void PrintFibonacci(int n)
		//{
		//	int a = 0, b = 1;
		//	for (int i = 0; i < n; i++)
		//	{
		//		Console.Write(a + " ");
		//		int next = a + b;
		//		a = b;
		//		b = next;
		//	}
		//	Console.WriteLine();
		//}

		//////////////////////////////////////////// 6
		//static void Main()
		//{
		//	Console.Write("Въведи число: ");
		//	int n = int.Parse(Console.ReadLine());
		//	long result = Factorial(n);
		//	Console.WriteLine($"{n}! = {result}");
		//}
		//static long Factorial(int n)
		//{
  //       if ( n == 0 || n == 1)
		// {
		//		return 1;
		// }
		// return n * Factorial(n - 1);
		//}
	}
}
	
	

