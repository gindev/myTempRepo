﻿////////////////////////////////////////////////       1

//using System;
//class Program1
//{
//    static void Main()
//    {
//        Console.WriteLine("Въведете име:");
//        string name = Console.ReadLine();
//        Greet(name);

//        static void Greet(string msg)
//        {
//            Console.WriteLine($"Здравей, {msg} !");
//        }
//    }
//}

////////////////////////////////////////////////       2


//using System;

//class Program2
//{
//    static void Main()
//    {
//        using System.Diagnostics.Metrics;

//        List<int> numbers = Console.ReadLine().Split(',').Select(int.Parse).ToList();

//        int findNumber = int.Parse(Console.ReadLine());

//        int count = GetCount(numbers, findNumber);

//        if (count > 0)
//        {
//            Console.WriteLine($"Числото {findNumber} е намерено {count} пъти в списъка.");
//        }
//        else
//        {
//            Console.WriteLine($"Числото {findNumber} не е намерено в списъка.");
//        }

//        static int GetCount(List<int> numbers, int search)
//        {
//            int counter = 0;
//            foreach (int number in numbers)
//            {
//                if (number == search)
//                {
//                    counter++;
//                }
//            }
//            return counter;
//        }                          //  9,8,5,6,6,4,8,9,3,3
//    }
//}

////////////////////////////////////////////////       3

//using System;

//class Program3
//{
//    static void Main()
//    {
//        Console.WriteLine("Въведете номер: ");
//        string input = Console.ReadLine();

//        string reversed = ReverseString(input);

//        Console.WriteLine($"Обърнатият текст е: {reversed}");

//        static string ReverseString(string input)
//        {
//            string reversed = "";

//            for (int i = input.Length - 1; i >= 0; i--)
//            {
//                reversed += input[i];
//            }
//            return reversed;
//        }
//    }
//}

////////////////////////////////////////////////       4

//using System;

//class Program4
//{
//    static void Main()
//    {
//        Console.WriteLine("Enter temperature:");

//        string input = Console.ReadLine();

//        if (string.IsNullOrEmpty(input))
//        {
//            Console.WriteLine("Invalid input.");
//            return;
//        }

//        int letterIndex = input.Length - 1;

//        string numberPart = input.Substring(0, letterIndex);
//        char scale = char.ToUpper(input[letterIndex]);

//        double value;

//        if (!double.TryParse(numberPart, out value))
//        {
//            Console.WriteLine("Invalid number.");
//            return;
//        }

//        double result = ConvertTemperature(value, scale);

//        if (scale == 'C')
//        {
//            Console.WriteLine(value.ToString("F2") + "C = " + result.ToString("F2") + "F");
//        }
//        else if (scale == 'F')
//        {
//            Console.WriteLine(value.ToString("F2") + "F = " + result.ToString("F2") + "C");
//        }
//        else
//        {
//            Console.WriteLine("Unknown scale.");
//        }
//    }

//    static double ConvertTemperature(double value, char scale)
//    {
//        if (scale == 'C')
//        {
//            return (value * 9.0 / 5.0) + 32.0;
//        }
//        else
//        {
//            return (value - 32.0) * 5.0 / 9.0;
//        }
//    }
//}

////////////////////////////////////////////////       5

//using System;

//class Program5
//{
//    static void Main()
//    {
//        Console.Write("Enter number: ");
//        int n = int.Parse(Console.ReadLine());

//        PrintFibonacci(n);
//    }

//    static void PrintFibonacci(int n)
//    {
//        int a = 0;
//        int b = 1;

//        Console.Write(a + " ");

//        if (n >= 1)
//        {
//            Console.Write(b + " ");
//        }

//        while (true)
//        {
//            int next = a + b;

//            if (next > n)
//            {
//                break;
//            }

//            Console.Write(next + " ");

//            a = b;
//            b = next;
//        }
//    }
//}

////////////////////////////////////////////////       6

//using System;

//class Program6
//{
//    static void Main()
//    {
//        Console.Write("Enter number: ");
//        int n = int.Parse(Console.ReadLine());

//        long result = Factorial(n);

//        Console.WriteLine("Factorial = " + result);
//    }

//    static long Factorial(int n)
//    {
//        if (n == 0 || n == 1)
//        {
//            return 1;
//        }

//        return n * Factorial(n - 1);
//    }
//}
