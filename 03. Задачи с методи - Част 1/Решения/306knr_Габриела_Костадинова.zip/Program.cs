﻿
using System.Text;

namespace c_23._03
{
    internal class Program
    {
        //static void Main(string[] args)
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;
        //    string name = Console.ReadLine();

        //    PrintGreeting(name);

        //}

        //private static void PrintGreeting(string? name)
        //{
        //    Console.WriteLine($"Zdravei,{name}!");
        //}





        // Zadacha n2




        //static void Main()

        //{
        //Console.OutputEncoding = Encoding.UTF8;
        //Console.InputEncoding = Encoding.UTF8;

        //Console.WriteLine("Въведете числа, разделени със запетая:");
        //    string input = Console.ReadLine();


        //    string[] stringElements = input.Split(',');


        //    int[] numbers = new int[stringElements.Length];


        //    for (int i = 0; i < stringElements.Length; i++)
        //    {
        //        numbers[i] = int.Parse(stringElements[i].Trim());
        //    }


        //    Console.WriteLine("Въведете число за търсене:");
        //    int target = int.Parse(Console.ReadLine());


        //    int count = CountOccurrences(numbers, target);
        //    Console.WriteLine($"Числото {target} се среща {count} пъти в масива.");
        //}


        //static int CountOccurrences(int[] array, int searchItem)
        //{
        //    int count = 0;
        //    foreach (int num in array)
        //    {
        //        if (num == searchItem)
        //        {
        //            count++;
        //        }
        //    }
        //    return count;
        //}


        //Задача 3


        //static void Main()
        //{

        //     Console.OutputEncoding = Encoding.UTF8;
        //     Console.InputEncoding = Encoding.UTF8;

        //     Console.Write("Въведете число с поне две цифри: ");
        //     int number = int.Parse(Console.ReadLine());


        //     PrintReversedDigits(number);
        //}


        // static void PrintReversedDigits(int num)
        // {

        //     if (num < 0)
        //     {
        //         Console.Write("-");
        //         num = Math.Abs(num);
        //     }


        //     if (num == 0)
        //     {
        //         Console.WriteLine(0);
        //         return;
        //     }

        //     while (num > 0)
        //     {

        //         int lastDigit = num % 10;
        //         Console.Write(lastDigit);


        //         num = num / 10;
        //     }
        //     Console.WriteLine(); 

        //  Задача 4


        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;

        //    Console.WriteLine("Въведете температура и скала (напр. 100F или 36.6C):");
        //    string input = Console.ReadLine().Trim();

        //    char scale = input[input.Length - 1];
        //    string valuePart = input.Substring(0, input.Length - 1);

        //    if (double.TryParse(valuePart, out double temperature))
        //    {

        //        ConvertTemperature(temperature, scale);
        //    }
        //    else
        //    {
        //        Console.WriteLine("Невалиден формат на числото!");
        //    }
        //}


        //static void ConvertTemperature(double temp, char scale)
        //{
        //    double result;
        //    char targetScale;


        //    scale = char.ToUpper(scale);

        //    if (scale == 'C')
        //    {

        //        result = (temp * 9.0 / 5.0) + 32;
        //        targetScale = 'F';
        //        Console.WriteLine($"{result:F2}{targetScale}");
        //    }
        //    else if (scale == 'F')
        //    {

        //        result = (temp - 32) * 5.0 / 9.0;
        //        targetScale = 'C';
        //        Console.WriteLine($"{result:F2}{targetScale}");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Непозната скала! Използвайте C или F.");
        //    }
        // }




        // zadacha 5


        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;

        //    Console.Write("Въведете до кое число да се генерира редицата: ");
        //    if (int.TryParse(Console.ReadLine(), out int limit))
        //    {

        //        PrintFibonacci(limit);
        //    }
        //    else
        //    {
        //        Console.WriteLine("Моля, въведете валидно цяло число.");
        //    }
        //}


        //static void PrintFibonacci(int limit)
        //{
        //    int a = 0; 
        //    int b = 1; 

        //    Console.Write("Редица на Фибоначи: ");


        //    if (limit >= 0)
        //    {
        //        Console.Write(a);
        //    }


        //    while (b <= limit)
        //    {
        //        Console.Write(", " + b);


        //        int next = a + b;

        //        a = b;

        //        b = next;
        //    }

        //    Console.WriteLine(); 



        // zadacha 6

        //    static void Main()

        //    {
        //        int number = int.Parse(Console.ReadLine());

        //        long result = CalculateFactorial(number);

        //        Console.WriteLine(result);
        //    }

        //    static long CalculateFactorial(int n)
        //    {
        //        if (n <= 1)
        //        {
        //            return 1;
        //        }

        //        return n * CalculateFactorial(n - 1);
        //    }
        //}



    }



}



















    



































    






















































    

