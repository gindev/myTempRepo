﻿using System.Numerics;
namespace Zadachi3

{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\nChoose task (1-6) or 0 to exit:");
                string input = Console.ReadLine();

                try
                {
                    int choice = int.Parse(input);

                    if (choice == 0)
                    {
                        Console.WriteLine("Goodbye!");
                        break;
                    }

                    switch (choice)
                    {
                        case 1: Task1(); break;
                        case 2: Task2(); break;
                        case 3: Task3(); break;
                        case 4: Task4(); break;
                        case 5: Task5(); break;
                        case 6: Task6(); break;
                        default:
                            Console.WriteLine("Invalid choice!");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error: Please enter a valid number!");
                }
            }
        }

        // Task 1
        static void Task1()
        {
            try
            {
                Console.Write("Enter name: ");
                string name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name))
                    throw new Exception("Name cannot be empty!");

                Console.WriteLine($"Hello, {name}!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        // Task 2
        static void Task2()
        {
            try
            {
                Console.Write("Enter numbers (comma separated): ");
                int[] numbers = Console.ReadLine()
                    .Split(',')
                    .Select(x => int.Parse(x.Trim()))
                    .ToArray();

                Console.Write("Enter number to search: ");
                int target = int.Parse(Console.ReadLine());

                int count = numbers.Count(x => x == target);

                Console.WriteLine($"{target} appears {count} times.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Use format like 1, 2, 3");
            }
        }

        // Task 3
        static void Task3()
        {
            try
            {
                Console.Write("Enter number: ");
                int number = int.Parse(Console.ReadLine());

                if (number < 0)
                    throw new Exception("Number must be positive!");

                if (number == 0)
                {
                    Console.WriteLine(0);
                    return;
                }

                while (number > 0)
                {
                    Console.Write(number % 10);
                    number /= 10;
                }

                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        // Task 4
        static void Task4()
        {
            try
            {
                Console.Write("Enter temperature (e.g. 32F or 0C): ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input) || input.Length < 2)
                    throw new Exception("Invalid input!");

                double value = double.Parse(input.Substring(0, input.Length - 1));
                char scale = char.ToUpper(input[input.Length - 1]);

                double result;

                if (scale == 'F')
                    result = (value - 32) * 5 / 9;
                else if (scale == 'C')
                    result = (value * 9 / 5) + 32;
                else
                    throw new Exception("Invalid scale! Use C or F.");

                Console.WriteLine($"Converted: {result:F2}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        // Task 5
        static void Task5()
        {
            try
            {
                Console.Write("Enter limit: ");
                int n = int.Parse(Console.ReadLine());

                if (n < 0)
                    throw new Exception("Number must be >= 0!");

                BigInteger a = 0, b = 1;

                Console.Write(a + " " + b + " ");

                while (true)
                {
                    BigInteger next = a + b;

                    if (next > n)
                        break;

                    Console.Write(next + " ");

                    a = b;
                    b = next;
                }

                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        // Task 6
        static void Task6()
        {
            try
            {
                Console.Write("Enter number: ");
                int n = int.Parse(Console.ReadLine());

                if (n < 0)
                    throw new Exception("Factorial not defined for negative numbers!");

                Console.WriteLine($"Result: {Factorial(n)}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static BigInteger Factorial(int n)
        {
            if (n == 0 || n == 1)
                return 1;

            return n * Factorial(n - 1);
        }
    }
}