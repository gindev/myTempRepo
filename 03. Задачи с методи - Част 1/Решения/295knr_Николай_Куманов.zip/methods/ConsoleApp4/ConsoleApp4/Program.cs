﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            if (input.Contains("f"))
            {
                ConvertTemp(double.Parse(input.Split('f')[0]), "f");
            }
            else if (input.Contains("c"))
            {
                ConvertTemp(double.Parse(input.Split('c')[0]), "c");
            }

        }

        public static void ConvertTemp(double temp, string scale)
        {
            if (scale == "f")
            {
                double res = (temp - 32) * 5 / 9;
                Console.WriteLine(res.ToString("F2"));
            }
            else if (scale == "c")
            {
                double res = (temp * 9 / 5) + 32;
                Console.WriteLine(res.ToString("F2"));

            }
        }
    }
}
