﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());

            Console.WriteLine(Fac(n));


        }

        public static int Fac(int n)
        {
            if (n == 1)
            {
                return 1;
            }
            return n * Fac(n - 1);
        }
    }
}
