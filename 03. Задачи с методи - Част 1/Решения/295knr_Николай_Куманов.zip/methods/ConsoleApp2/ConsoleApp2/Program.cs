﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbersList = Console.ReadLine().Split(',').Select(int.Parse).ToList();
            int number = int.Parse(Console.ReadLine());

            int n = NumberOfTimes(number,numbersList);

            Console.WriteLine($"{number} is found {n} times in the array");

        }

        public static int NumberOfTimes(int num, List<int> numList)
        {
            int n = 0;

            for (int i = 0; i < numList.Count; i++)
            {
                if (num == numList[i])
                {
                    n++;
                }
            }
            return n;
        }
    }
}
