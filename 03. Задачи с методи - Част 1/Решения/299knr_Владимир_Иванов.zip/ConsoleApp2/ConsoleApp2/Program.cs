﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Zadacha 1
            Console.Write("Въведете име: ");
            string name = Console.ReadLine();
            Greeting(name);

            //Zadacha 2
            int[] n = Console.ReadLine().Split(',').Select(int.Parse).ToArray();
            int n2 = int.Parse(Console.ReadLine());

            int countOccurrences = occurences(n, n2);

            Console.WriteLine($"{n2} се среща {countOccurrences} пъти.");

            //Zadacha 3
            Console.Write("Напишете число: ");
            int number = int.Parse(Console.ReadLine());
            Reversed(number);

            //Zadacha 4
            
            Console.Write("Въведи температура (напр. 25C или 77F): ");
            string input = Console.ReadLine().ToUpper();

            
            char scale = input[input.Length - 1];
            double value = double.Parse(input.Substring(0, input.Length - 1));

            ConvertTemperature(value, scale);

            //Zadacha 5
            Console.Write("Въведи лимит: ");
            int limit = int.Parse(Console.ReadLine());

            Fibonacci(limit);

            //Zadacha 6
            Console.Write("Въведи число за факториел: ");
            int n3 = int.Parse(Console.ReadLine());

            long result = Factorial(n3);
            Console.WriteLine($"{n3}! = {result}");
        }

        static void Greeting(string name)
        {
            Console.WriteLine($"Здравей, {name}!");
        }

        static int occurences(int[] n,int n2)
        {
            int count = 0;
            foreach (var item in n)
            {
                if (item == n2)
                {
                    count++;
                }
            }
            return count;
        } 

        static void Reversed(int number) 
        {
            if (number == 0)
            {
                Console.WriteLine(0);
                return;
            }
            while (number > 0) {
                int lastDigit = number % 10;
                Console.Write(lastDigit);
                number = number / 10;
            }
            Console.WriteLine();
        }

        static void ConvertTemperature(double temp, char scale)
        {
            if (scale == 'C')
            {
                double fahrenheit = (temp * 9 / 5) + 32;
                Console.WriteLine($"{fahrenheit:F2}F");
            }
            else if (scale == 'F')
            {
                double celsius = (temp - 32) * 5 / 9;
                Console.WriteLine($"{celsius:F2}C");
            }
            else
            {
                Console.WriteLine("Невалидна скала!");
            }
        }

        static void Fibonacci(int limit)
        {
            int a = 0;
            int b = 1;

            while (a <= limit)
            {
                Console.WriteLine(a + " ");
                int next = a + b;
                a = b;
                b = next;
            }
        }

        static long Factorial(int n)
        {

            int result = 1;

            for (int i = 1; i <= n; i++)
            {
                result = result * i;
            }

            return result;
        }
    }
}