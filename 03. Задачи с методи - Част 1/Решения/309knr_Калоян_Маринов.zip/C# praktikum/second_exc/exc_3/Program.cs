﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string num = Console.ReadLine();
            PrintNums(num);
        }


        static void PrintNums(string num)
        {
            for(int i = num.Length - 1; i >= 0; i--)
            {
                Console.Write(num[i]);
            }
        }
    }
}