﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Insert the number: ");
        int n = int.Parse(Console.ReadLine());

        long result = Factorial(n);

        Console.WriteLine($"The Factoriel is: {result}");
    }

    static long Factorial(int n)
    {
        if (n == 0 || n == 1)
        {
            return 1;
        }

        return n * Factorial(n - 1);
    }
}