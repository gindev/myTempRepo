﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string temp = Console.ReadLine();
            string type = temp.Substring(temp.Length - 1);
            double nums = double.Parse(temp.Substring(0, temp.Length - 1));


            double newTemp1 = ConvertTemp(nums, type);
            Console.WriteLine($"The temp is {newTemp1}");
        }

        static double ConvertTemp(double nums, string type)
        {
            double newTemp;
            if(type.ToLower() == "f")
            {
                newTemp = (nums - 32) * 5 / 9;
            }
            else
            {
                newTemp = (nums * 9 / 5) + 32;
            }

            return newTemp;
        }
    }
}