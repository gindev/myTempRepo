﻿using System.Diagnostics.Metrics;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int num = int.Parse(Console.ReadLine());
            CheckNums(numbers, num);
        }

        static void CheckNums(int[] numbers, int num)
        {
            int counter = 0;
            foreach (int n in numbers)
            {
                if (n == num)
                {
                    counter += 1;
                }
            }
            Console.WriteLine($"The num {num} has been seen {counter} times");
        }
    }
}