﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number you would like to search");
            int n = int.Parse(Console.ReadLine());
            PrintFibonacci(n);
        }

        static void PrintFibonacci(int n)
        {
            int a = 0;
            int b = 1;

            Console.Write($"{a}, {b}");

            int next = a + b;

            while (next <= n)
            {
                Console.Write($", {next}");

                a = b;
                b = next;
                next = a + b;
            }
        }
    }
}