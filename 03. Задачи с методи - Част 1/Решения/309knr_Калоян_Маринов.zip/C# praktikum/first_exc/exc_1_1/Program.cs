﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert the number");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i <= n; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}