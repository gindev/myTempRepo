﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert the number");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i <= n; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine($"The number {i} is even");
                }
                else
                {
                    Console.WriteLine($"The number {i} is odd");
                }
            }
        }
    }
}