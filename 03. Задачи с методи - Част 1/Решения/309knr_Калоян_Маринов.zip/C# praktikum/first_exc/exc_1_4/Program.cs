﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();

            Console.WriteLine("Insert numbers ('stop' for end of the program)");

            string input = Console.ReadLine();

            while (input != "stop")
            {
                numbers.Add(int.Parse(input));
                input = Console.ReadLine();
            }

            for (int i = numbers.Count - 1; i >= 0; i--)
            {
                Console.WriteLine(numbers[i]);
            }

        }
    }
}