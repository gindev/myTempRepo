﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string>();

            Console.WriteLine("Insert numbers ('stop' for end of the program)");

            string input = Console.ReadLine();

            while (input != "stop")
            {
                names.Add(input);
                input = Console.ReadLine();
            }

            names.Sort();

            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
        }
    }
}