﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> data = new Dictionary<string, int>();

            string input = Console.ReadLine();
            string[] pairs = input.Split(", ");

            foreach (var pair in pairs)
            {
                string[] parts = pair.Split(' ');
                string name = parts[0];
                int number = int.Parse(parts[1]);

                data[name] = number;
            }

            int searchNumber = int.Parse(Console.ReadLine());

            bool found = false;

            foreach (var item in data)
            {
                if (item.Value == searchNumber)
                {
                    Console.WriteLine(item.Key);
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine("The apartment is not existing");
            }
        }
    }
}