﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Student
    {
        string name;
        string fn;
        double averageGrade;

        public Student(string name, string fn, double averageGrade)
        {
            this.name = name;
            this.fn = fn;
            this.averageGrade = averageGrade;
        }
        public Student()
        {
            this.name = "";
            this.fn = "";
            this.averageGrade = 0.00;
        }

        public double AverageGrade { get => averageGrade; set => averageGrade = value; }

        public void PrintStudent() 
        {
            Console.Write(name + ", ");
            Console.Write("ФН: " + fn + ", ");
            Console.Write("Успех: " + averageGrade + " ");
            Console.WriteLine();
        }
    }
}
