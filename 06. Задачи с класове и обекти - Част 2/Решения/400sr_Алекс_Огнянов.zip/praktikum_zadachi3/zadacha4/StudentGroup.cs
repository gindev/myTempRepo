﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class StudentGroup
    {
        string groupName;
        List<Student> students;

        public StudentGroup(string groupName)
        {
            this.groupName = groupName;
            this.students = new List<Student>();
        }

        public void AddStudent(Student student) 
        {
            students.Add(student);
        }

        public void PrintStudents() 
        {
            for(int i = 0; i <= students.Count - 1; i++) 
            {
                Console.Write(i+1 + ". ");
                students[i].PrintStudent();
            }
        }
        public Student GetBestStudent() 
        {
            Student bestStudent = new Student();
            foreach (Student student in students) 
            {
                if (student.AverageGrade > bestStudent.AverageGrade) 
                {
                    bestStudent = student;
                }
            }
            return bestStudent;
        }
    }
}
