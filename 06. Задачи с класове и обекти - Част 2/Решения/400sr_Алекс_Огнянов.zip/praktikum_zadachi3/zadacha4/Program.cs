﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentGroup g1 = new StudentGroup("ИС");
            Student s1 = new Student("Алекс Огнянов","400ср", 4.91);
            Student s2 = new Student("Ади Хаджиев", "401ср", 5.41);
            Student s3 = new Student("Борислав Шатев", "402ср", 5.45);

            g1.AddStudent(s1);
            g1.AddStudent(s2);
            g1.AddStudent(s3);

            Console.WriteLine("Суденти:");
            g1.PrintStudents();

            Console.WriteLine();
            Console.WriteLine("Студент с най-висок успех:");
            g1.GetBestStudent().PrintStudent();
        }
    }
}
