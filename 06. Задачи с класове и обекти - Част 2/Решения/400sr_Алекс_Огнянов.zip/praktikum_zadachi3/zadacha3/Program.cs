﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee();
            Employee e2 = new Employee("Алекс Огнянов", "Мениджър", 20000.01);
            Console.WriteLine("Служител 1: ");
            e1.PrintInfo();
            Console.WriteLine();
            Console.WriteLine("Служител 2: ");
            e2.PrintInfo();
        
        }
    }
}
