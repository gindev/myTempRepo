﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Employee
    {
        string name;
        string jobTitle;
        double salary;

        public Employee(string name, string jobTitle, double salary)
        {
            this.name = name;
            this.jobTitle = jobTitle;
            this.salary = salary;
        }
        public Employee()
        {
            this.name = "Няма зададено име!";
            this.jobTitle = "Не е зададено!";
            this.salary = 0;
        }
        public void PrintInfo() 
        {
            Console.WriteLine($"Име: {this.name}");
            Console.WriteLine($"Длъжност: {this.jobTitle}");
            Console.WriteLine($"Заплата: {this.salary}");

        }
    }
}
