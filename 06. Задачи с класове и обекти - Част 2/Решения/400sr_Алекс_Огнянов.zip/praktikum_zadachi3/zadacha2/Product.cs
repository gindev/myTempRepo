﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Product
    {
        string name;
        double price;
        int quantity;

        public string Name { get => name; set => name = value; }
    public double Price 
        {
            get { return this.price; }
            set 
            {
                if (value < 0) this.price = 0;
                else this.price = value;
            }
        }
        public int Quantity
        {
            get { return this.quantity; }
            set
            {
                if (value < 0) this.quantity = 0;
                else this.quantity = value;
            }
        }
        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукта: {Name}");
            Console.WriteLine($"Цена: {Price}");
            Console.WriteLine($"Количество: {Quantity}");
        }
    }
}
