﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product p1 = new Product();
            Console.Write("Въведи име на продукта: ");
            p1.Name = Console.ReadLine();
            Console.Write("Въведи цена: ");
            p1.Price = double.Parse(Console.ReadLine());
            Console.Write("Въведи количество: ");
            p1.Quantity = int.Parse(Console.ReadLine());
            Console.WriteLine();
            p1.PrintInfo();
        }
    }
}
