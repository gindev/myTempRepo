﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Library
    {
        List<Book> books;

        public Library()
        {
            this.books = new List<Book>();
        }

        public void AddBook(Book book) 
        {
            books.Add(book);
        }

        public void ShowAllBooks() 
        {
            foreach (Book book in books) 
            {
                book.PrintBook();
            }
        }
        public void FindByTitle(string title) 
        {
            foreach (Book book in books) 
            {
                if (book.Title.ToLower() == title.ToLower()) 
                {
                    Console.WriteLine("Книгата е намерена!");
                    book.PrintBook();
                }
                else Console.WriteLine("Книгата не е намерена!");
            }
        }

    }
}
