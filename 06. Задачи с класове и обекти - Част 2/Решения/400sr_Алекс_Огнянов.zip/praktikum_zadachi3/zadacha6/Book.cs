﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Book
    {
        string title;
        string author;
        int realseYear;

        public Book(string title, string author, int realseYear)
        {
            this.Title = title;
            this.author = author;
            this.realseYear = realseYear;
        }

        public string Title { get => title; set => title = value; }

        public void PrintBook() 
        {
            Console.WriteLine(Title + " | "+ author +" | "+ realseYear);
        }
    }
}
