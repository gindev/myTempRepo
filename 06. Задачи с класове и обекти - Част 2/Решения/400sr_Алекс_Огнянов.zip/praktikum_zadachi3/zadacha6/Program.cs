﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            int option = 0;
            while (option != 4) 
            {
                Console.WriteLine();
                Console.WriteLine("1. Добавяне на книга");
                Console.WriteLine("2. Показване на всички книги");
                Console.WriteLine("3. Търсене на книга по заглавие");
                Console.WriteLine("4. Изход");
                Console.Write("Изберете опция: ");
                option = int.Parse(Console.ReadLine());
                Console.WriteLine();

                switch (option)
                {
                    case 1:
                        Console.Write("Заглавие: ");
                        string title = Console.ReadLine();

                        Console.Write("Автор: ");
                        string author = Console.ReadLine();

                        Console.Write("Година: ");
                        int year = int.Parse(Console.ReadLine());

                        Book book = new Book(title, author, year);
                        library.AddBook(book);
                        break;

                    case 2:
                        library.ShowAllBooks();
                        break;

                    case 3:
                        Console.Write("Въведи заглавие: ");
                        string searchTitle = Console.ReadLine();
                        library.FindByTitle(searchTitle);
                        break;

                    case 4:
                        Console.WriteLine("Изход...");
                        break;

                    default:
                        Console.WriteLine("Невалиден избор!");
                        break;
                }
            }
        }
    }
}
