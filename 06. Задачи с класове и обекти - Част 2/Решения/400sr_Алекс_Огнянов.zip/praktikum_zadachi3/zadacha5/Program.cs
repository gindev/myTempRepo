﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount b1 = new BankAccount("BG11AAAA1234", "Алекс Огнянов", 2400.01);
            Console.Write("Сметка "+ BankAccount.NumOfAccounts + ": ");
            b1.PrintInfo();
            BankAccount b2 = new BankAccount("BG22BGAA1334", "Ади Хаджиев", 2500.01);
            Console.Write("Сметка " + BankAccount.NumOfAccounts + ": ");
            b2.PrintInfo();
            BankAccount b3 = new BankAccount("BG33ERMA1287", "Бовислав Шатев", 2500.02);
            Console.Write("Сметка " + BankAccount.NumOfAccounts + ": ");
            b3.PrintInfo();
            Console.WriteLine();
            Console.Write("Общ брой сметки: " + BankAccount.NumOfAccounts);

        }
    }
}
