﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace zadacha5
{
    internal class BankAccount
    {
        string iban;
        string ownerName;
        double balance;
        
        static int numOfAcc;
        public static int NumOfAccounts
        {
            get { return numOfAcc; }
        }
        public BankAccount(string iban, string ownerName, double balance)
        {
            this.iban = iban;
            this.ownerName = ownerName;
            this.balance = balance;
            numOfAcc++;
        }
        public void PrintInfo() 
        {
            Console.Write(iban + " | ");
            Console.Write(ownerName + " | ");
            Console.Write(balance + " ");
            Console.WriteLine();
        }
    }
}
