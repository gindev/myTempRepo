﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Алекс";
            p1.Surname = "Огнянов";
            p1.Age = 20;

            Console.WriteLine($"Име: {p1.Name}");
            Console.WriteLine($"Фамилия: {p1.Surname}");
            Console.WriteLine($"Години: {p1.Age}");
        }
    }
}
