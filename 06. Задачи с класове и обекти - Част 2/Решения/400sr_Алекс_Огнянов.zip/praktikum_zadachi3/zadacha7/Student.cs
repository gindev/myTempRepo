﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Student
    {
        string name;
        string fn;

        public Student(string name, string fn)
        {
            this.Name = name;
            this.fn = fn;
        }

        public string Name { get => name; set => name = value; }

        public void PrintStudent() 
        {
            Console.WriteLine(Name + " | " + fn );
        }
    }
}
