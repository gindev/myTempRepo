﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Алекс Огнянов", "400ср");
            Student s2 = new Student("Ади Хаджиев", "401ср");
            Student s3 = new Student("Борислав Шатев", "402ср");

            Course c1 = new Course("Информационна Сигурност", 2);
            c1.AddStudent(s1);
            c1.AddStudent(s2);
            c1.AddStudent(s3);
        }
    }
}
