﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Course
    {
        string coursnName;
        int maxNumOfStudents;
        List<Student> students;
        static int numOfStudents;
        public static int NumOfStudents
        {
            get { return numOfStudents; }
        }


        public Course(string coursnName, int maxNumOfStudents)
        {
            this.coursnName = coursnName;
            this.maxNumOfStudents = maxNumOfStudents;
            this.students = new List<Student>();

        }

        public void AddStudent(Student student) 
        {
            if (HasFreeSeats()) 
            {
                students.Add(student);
                numOfStudents++;
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else Console.WriteLine("Няма свободни места в курса.");
        }
        public void PrintStudents() 
        {
            foreach (Student student in students) 
            {
                student.PrintStudent();
            }
        }
        public bool HasFreeSeats() 
        {
            if (numOfStudents+1 > maxNumOfStudents) 
            {
                return false;
            }
            else return true;
        }
    }
}
