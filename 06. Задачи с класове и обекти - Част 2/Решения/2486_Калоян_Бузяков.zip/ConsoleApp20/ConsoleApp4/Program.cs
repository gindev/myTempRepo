﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount s1 = new BankAccount("BG11AAAA1234", "Иван Иванов", 500.00);
            BankAccount s2 = new BankAccount("BG22BBB5678", "Мария Петрова", 820.00);
            BankAccount s3 = new BankAccount("BG33CCC9999", "Георги Димитров", 1200.00);

            s1.PrintInfo();
            s2.PrintInfo();
            s3.PrintInfo();

            Console.WriteLine("Общ брой създадени сметки: " + BankAccount.GetObshtBroi());

        }
    }
}
