﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class BankAccount
    {
        private static int obshtBroi = 0;

        public string Nomer { get; set; }
        public string ImeTitulqr { get; set; }
        public double Nalichnost { get; set; }

        public BankAccount(string nomer, string ime, double nalichnost)
        {
            Nomer = nomer;
            ImeTitulqr = ime;
            Nalichnost = nalichnost;
            obshtBroi++;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Сметка: " + Nomer+ " | " + ImeTitulqr + " | " + Nalichnost);
        }

        public static int GetObshtBroi()
        {
            return obshtBroi;
        }
    }

}
