﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Employee
    {
        public string Ime { get; set; }
        public string Dlajnost { get; set; }
        public double Zaplata { get; set; }


        public Employee()
        {
            Ime = "Няма въведено име";
            Dlajnost = "Не е зададена";
            Zaplata = 0;
        }

        public Employee(string ime, string dlajnost, double zaplata)
        {
            Ime = ime;
            Dlajnost = dlajnost;
            Zaplata = zaplata;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Име: " + Ime);
            Console.WriteLine("Длъжност: " + Dlajnost);
            Console.WriteLine("Заплата: " + Zaplata);
        }
    }

}
