﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee();
            Console.WriteLine("Служител 1:");
            e1.PrintInfo();

            Console.WriteLine();

            Employee e2 = new Employee("Петър Иванов", "Програмист", 2500);
            Console.WriteLine("Служител 2:");
            e2.PrintInfo();

        }
    }
}
