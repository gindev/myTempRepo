﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Course kurs = new Course("C# основи", 2);

            kurs.AddStudent(new Student("Иван Петров", 2486));
            kurs.AddStudent(new Student("Мария Георгиева", 6483));
            kurs.AddStudent(new Student("Петър Стоянов", 3593));

            Console.WriteLine();
            kurs.PrintStudents();

            Console.WriteLine();
            if (kurs.HasFreeSeats()) Console.WriteLine("Има свободни места.");
            else Console.WriteLine("Няма свободни места.");

        }
    }
}
