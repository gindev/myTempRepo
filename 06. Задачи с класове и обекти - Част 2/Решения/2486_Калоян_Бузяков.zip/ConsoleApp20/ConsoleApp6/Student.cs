﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Student
    {
        public string Ime { get; set; }
        public int FakultetenNomer { get; set; }

        public Student(string ime, int fn)
        {
            Ime = ime;
            FakultetenNomer = fn;
        }
    }

}
