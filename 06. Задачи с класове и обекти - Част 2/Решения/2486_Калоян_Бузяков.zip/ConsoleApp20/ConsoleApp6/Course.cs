﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Course
    {
        public string ImeNaKurs { get; set; }
        public int MaxStudenti { get; set; }
        private List<Student> zapisani = new List<Student>();

        public Course(string ime, int max)
        {
            ImeNaKurs = ime;
            MaxStudenti = max;
        }

        public void AddStudent(Student s)
        {
            if (!HasFreeSeats())
            {
                Console.WriteLine("Няма свободни места в курса!");
                return;
            }
            zapisani.Add(s);
            Console.WriteLine("Студент " + s.Ime + " е записан успешно.");
        }

        public void PrintStudents()
        {
            Console.WriteLine("Записани в курс " + ImeNaKurs + ":");
            foreach (Student s in zapisani)
                Console.WriteLine("  – " + s.Ime + " (ФН: " + s.FakultetenNomer + ")");
        }

        public bool HasFreeSeats()
        {
            return zapisani.Count < MaxStudenti;
        }
    }

}
