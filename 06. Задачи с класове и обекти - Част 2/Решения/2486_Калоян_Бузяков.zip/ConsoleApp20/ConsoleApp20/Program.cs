﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Person p = new Person();
            p.Ime = "Мария";
            p.Familiq = "Георгиева";
            p.Vazrast = 21;

            Console.WriteLine("Име: " + p.Ime);
            Console.WriteLine("Фамилия: " + p.Familiq);
            Console.WriteLine("Възраст: " + p.Vazrast);

        }
    }
}
