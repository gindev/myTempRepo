﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    public class Person
    {

        private string ime;
        private string familiq;
        private int vazrast;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public string Familiq
        {
            get { return familiq; }
            set { familiq = value; }
        }

        public int Vazrast
        {
            get { return vazrast; }
            set { vazrast = value; }
        }

    }

}
