﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Product
    {
        private string ime;
        private double cena;
        private int kolichestvo;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public double Cena
        {
            get { return cena; }
            set
            {
                if (value < 0)
                    Console.WriteLine("Грешка: Цената не може да е отрицателна!");
                else
                    cena = value;
            }
        }

        public int Kolichestvo
        {
            get { return kolichestvo; }
            set
            {
                if (value < 0)
                    Console.WriteLine("Грешка: Количеството не може да е отрицателно!");
                else
                    kolichestvo = value;
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine("Име на продукт: " + Ime);
            Console.WriteLine("Цена: " + Cena);
            Console.WriteLine("Количество: " + Kolichestvo);
        }
    }

}
