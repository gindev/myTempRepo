﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product pr = new Product();
            pr.Ime = "Лаптоп";
            pr.Cena = 1450.00;
            pr.Kolichestvo = 3;
            pr.PrintInfo();

            Console.WriteLine();
            pr.Cena = -50;
            pr.Kolichestvo = -2;

        }
    }
}
