﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Student
    {
        public string Ime { get; set; }
        public int FakultetenNomer { get; set; }
        public double SredenUspeh { get; set; }

        public Student(string ime, int fn, double uspeh)
        {
            Ime = ime;
            FakultetenNomer = fn;
            SredenUspeh = uspeh;
        }
    }

}
