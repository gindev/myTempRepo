﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            StudentGroup gr = new StudentGroup("КН-101");

            gr.AddStudent(new Student("Иван Петров", 12345, 5.50));
            gr.AddStudent(new Student("Мария Георгиева", 12346, 5.90));
            gr.AddStudent(new Student("Георги Стоянов", 12347, 4.80));

            gr.PrintStudents();

            Console.WriteLine();
            Student best = gr.GetBestStudent();
            Console.WriteLine("Студент с най-висок успех:");
            Console.WriteLine(best.Ime + ", ФН: " + best.FakultetenNomer + ", Успех: " + best.SredenUspeh);

        }
    }
}
