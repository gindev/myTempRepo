﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class StudentGroup
    {
        public string ImeNaGrupa { get; set; }
        private List<Student> studenti = new List<Student>();

        public StudentGroup(string ime)
        {
            ImeNaGrupa = ime;
        }

        public void AddStudent(Student s)
        {
            studenti.Add(s);
        }

        public void PrintStudents()
        {
            Console.WriteLine("Група: " + ImeNaGrupa);
            Console.WriteLine("Студенти:");
            for (int i = 0; i < studenti.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + studenti[i].Ime + ", ФН: " + studenti[i].FakultetenNomer+ ", Успех: " + studenti[i].SredenUspeh);
            }
        }

        public Student GetBestStudent()
        {

            Student best = studenti[0];
            foreach (Student s in studenti)
            {
                if (s.SredenUspeh > best.SredenUspeh)
                    best = s;
            }
            return best;

        }
    }

}
