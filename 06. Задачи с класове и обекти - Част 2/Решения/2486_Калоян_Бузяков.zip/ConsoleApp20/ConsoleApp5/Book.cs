﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Book
    {
        public string Zaglavie { get; set; }
        public string Avtor { get; set; }
        public int GodinaNaIzdavane { get; set; }

        public Book(string zaglavie, string avtor, int godina)
        {
            Zaglavie = zaglavie;
            Avtor = avtor;
            GodinaNaIzdavane = godina;
        }
    }

}
