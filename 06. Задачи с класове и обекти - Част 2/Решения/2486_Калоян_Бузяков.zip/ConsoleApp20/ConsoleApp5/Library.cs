﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Library
    {
        private List<Book> knigi = new List<Book>();

        public void AddBook(Book b)
        {
            knigi.Add(b);
            Console.WriteLine("Книгата е добавена: " + b.Zaglavie);
        }

        public void ShowAllBooks()
        {
            if (knigi.Count == 0)
            {
                Console.WriteLine("Няма книги в библиотеката.");
                return;
            }
            for (int i = 0; i < knigi.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + knigi[i].Zaglavie + " – " + knigi[i].Avtor + " (" + knigi[i].GodinaNaIzdavane + ")");
            }
        }

        public void FindBookByTitle(string title)
        {
            bool nameren = false;
            foreach (Book b in knigi)
            {
                if (b.Zaglavie.ToLower().Contains(title.ToLower()))
                {
                    Console.WriteLine("Намерена: " + b.Zaglavie + " – " + b.Avtor);
                    nameren = true;
                }
            }
            if (!nameren)
                Console.WriteLine("Не е намерена книга с това заглавие.");
        }
    }

}
