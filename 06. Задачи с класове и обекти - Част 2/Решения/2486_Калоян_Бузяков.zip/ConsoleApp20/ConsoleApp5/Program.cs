﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Library lib = new Library();
            bool running = true;

            while (running)
            {
                Console.WriteLine("1. Добавяне на книга");
                Console.WriteLine("2. Показване на всички книги");
                Console.WriteLine("3. Търсене на книга по заглавие");
                Console.WriteLine("4. Изход");
                Console.Write("Изберете опция: ");

                string izbor = Console.ReadLine();

                switch (izbor)
                {
                    case "1":
                        Console.Write("Заглавие: ");
                        string zag = Console.ReadLine();
                        Console.Write("Автор: ");
                        string avt = Console.ReadLine();
                        Console.Write("Година: ");
                        int god = int.Parse(Console.ReadLine());
                        lib.AddBook(new Book(zag, avt, god));
                        break;
                    case "2":
                        lib.ShowAllBooks();
                        break;
                    case "3":
                        Console.Write("Въведи заглавие: ");
                        string t = Console.ReadLine();
                        lib.FindBookByTitle(t);
                        break;
                    case "4":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Невалидна опция.");
                        break;
                }
            }

        }

    }
}
