﻿using System;
using System.Collections.Generic;
using System.Text;

namespace dom.rabota_25._04
{
	internal class _04_methot
	{
	}
}
