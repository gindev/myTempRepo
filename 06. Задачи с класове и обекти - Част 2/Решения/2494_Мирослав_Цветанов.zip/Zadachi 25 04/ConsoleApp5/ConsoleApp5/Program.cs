﻿using System;

namespace BankAccountExample
{
    class BankAccount
    {
        public string AccountNumber { get; set; }
        public string HolderName { get; set; }
        public double Balance { get; set; }

        private static int accountCount = 0;

        public BankAccount(string accountNumber, string holderName, double balance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = balance;
            accountCount++;
        }

        public void PrintInfo()
        {
            Console.WriteLine(AccountNumber + " | " + HolderName);
            Console.WriteLine(Balance.ToString("F2"));
        }

        public static int GetAccountCount()
        {
            return accountCount;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BankAccount acc1 = new BankAccount("BG11AAAA1234", "Ivan Ivanov", 500);
            BankAccount acc2 = new BankAccount("BG22BBBB5678", "Maria Petrova", 820);
            BankAccount acc3 = new BankAccount("8633CCCC9999", "Georgi Dimitrov", 1200);

            Console.WriteLine("Smetka 1:");
            acc1.PrintInfo();

            Console.WriteLine();

            Console.WriteLine("Smetka 2:");
            acc2.PrintInfo();

            Console.WriteLine();

            Console.WriteLine("Smetka 3:");
            acc3.PrintInfo();

            Console.WriteLine();
            Console.WriteLine("Obsht broi sazdadeni smetki: " + BankAccount.GetAccountCount());
        }
    }
}