﻿using System;
using System.Collections.Generic;

namespace CourseExample
{
    class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }

        public Student(string name, string facultyNumber)
        {
            Name = name;
            FacultyNumber = facultyNumber;
        }
    }

    class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }
        private List<Student> students;

        public Course(string courseName, int maxStudents)
        {
            CourseName = courseName;
            MaxStudents = maxStudents;
            students = new List<Student>();
        }

        public bool HasFreeSeats()
        {
            return students.Count < MaxStudents;
        }

        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                students.Add(student);
                Console.WriteLine("Student " + student.Name + " e zapisan uspeshno.");
            }
            else
            {
                Console.WriteLine("Nqma svobodni mesta v kursa.");
            }
        }

        public void PrintStudents()
        {
            Console.WriteLine("Kurs: " + CourseName);
            Console.WriteLine("Zapisani studenti:");

            foreach (var s in students)
            {
                Console.WriteLine(s.Name + " | FN: " + s.FacultyNumber);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Course course = new Course("Programirane", 2);

            course.AddStudent(new Student("Ivan Petrov", "12345"));
            course.AddStudent(new Student("Maria Georgieva", "12346"));
            course.AddStudent(new Student("Georgi Ivanov", "12347"));

            Console.WriteLine();
            course.PrintStudents();
        }
    }
}