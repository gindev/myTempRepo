﻿using System;

namespace EmployeeExample
{
    class Employee
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public double Salary { get; set; }

        public Employee()
        {
            Name = "Nqma vuvedeno ime";
            Position = "Ne e zadadena";
            Salary = 0;
        }

        public Employee(string name, string position, double salary)
        {
            Name = name;
            Position = position;
            Salary = salary;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Ime: " + Name);
            Console.WriteLine("Dluzhnost: " + Position);
            Console.WriteLine("Zaplata: " + Salary);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Employee emp2 = new Employee("Petar Ivanov", "Programist", 2500);

            Console.WriteLine("Sluzhitel 1:");
            emp1.PrintInfo();

            Console.WriteLine();

            Console.WriteLine("Sluzhitel 2:");
            emp2.PrintInfo();
        }
    }
}