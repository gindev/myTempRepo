﻿using System;

namespace Pich
{
    class Person
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            person.Name = "Miroslav";
            person.LastName = "Tsvetanov";
            person.Age = 19;

            Console.WriteLine("Ime: " + person.Name);
            Console.WriteLine("Familia: " + person.LastName);
            Console.WriteLine("Vazrast: " + person.Age);
        }
    }
}