﻿using System;
using System.Collections.Generic;

namespace LibraryExample
{
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }

        public Book(string title, string author, int year)
        {
            Title = title;
            Author = author;
            Year = year;
        }
    }

    class Library
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Nqma knigi.");
                return;
            }

            foreach (var b in books)
            {
                Console.WriteLine(b.Title + " | " + b.Author + " | " + b.Year);
            }
        }

        public Book FindBookByTitle(string title)
        {
            foreach (var b in books)
            {
                if (b.Title.ToLower() == title.ToLower())
                {
                    return b;
                }
            }
            return null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            int choice;

            do
            {
                Console.WriteLine("1. Dobavyane kniga");
                Console.WriteLine("2. Pokazvane na vsichki knigi");
                Console.WriteLine("3. Tarsene na kniga po zaglavie");
                Console.WriteLine("4. Izhod");
                Console.Write("Izberete opciq: ");

                choice = int.Parse(Console.ReadLine());

                Console.WriteLine();

                if (choice == 1)
                {
                    Console.Write("Zaglavie: ");
                    string title = Console.ReadLine();

                    Console.Write("Avtor: ");
                    string author = Console.ReadLine();

                    Console.Write("Godina: ");
                    int year = int.Parse(Console.ReadLine());

                    library.AddBook(new Book(title, author, year));
                }
                else if (choice == 2)
                {
                    library.ShowAllBooks();
                }
                else if (choice == 3)
                {
                    Console.Write("Vuvedi zaglavie: ");
                    string search = Console.ReadLine();

                    Book found = library.FindBookByTitle(search);

                    if (found != null)
                        Console.WriteLine(found.Title + " | " + found.Author + " | " + found.Year);
                    else
                        Console.WriteLine("Knigata ne e namerena.");
                }

                Console.WriteLine();

            } while (choice != 4);
        }
    }
}