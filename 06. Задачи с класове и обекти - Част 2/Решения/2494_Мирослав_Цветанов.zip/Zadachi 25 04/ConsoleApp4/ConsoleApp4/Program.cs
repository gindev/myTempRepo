﻿using System;
using System.Collections.Generic;

namespace StudentGroupExample
{
    class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
        public double AverageGrade { get; set; }

        public Student(string name, string facultyNumber, double averageGrade)
        {
            Name = name;
            FacultyNumber = facultyNumber;
            AverageGrade = averageGrade;
        }
    }

    class StudentGroup
    {
        public string GroupName { get; set; }
        private List<Student> students;

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void PrintStudents()
        {
            Console.WriteLine("Grupa: " + GroupName);
            Console.WriteLine("Studenti:");

            int index = 1;
            foreach (var s in students)
            {
                Console.WriteLine(index + ". " + s.Name + ", FN: " + s.FacultyNumber + ", Uspeh: " + s.AverageGrade.ToString("F2"));
                index++;
            }
        }

        public Student GetBestStudent()
        {
            Student best = null;

            foreach (var s in students)
            {
                if (best == null || s.AverageGrade > best.AverageGrade)
                {
                    best = s;
                }
            }

            return best;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            StudentGroup group = new StudentGroup("KN-101");

            group.AddStudent(new Student("Ivan Petrov", "12345", 5.50));
            group.AddStudent(new Student("Maria Georgieva", "12346", 5.90));
            group.AddStudent(new Student("Georgi Stoyanov", "12347", 4.80));

            group.PrintStudents();

            Console.WriteLine();
            Console.WriteLine("Student s nai-visok uspeh:");

            Student best = group.GetBestStudent();
            Console.WriteLine(best.Name + ", FN: " + best.FacultyNumber + ", Uspeh: " + best.AverageGrade.ToString("F2"));
        }
    }
}