﻿using System;

namespace ProductExample
{
    class Product
    {
        private double price;
        private int quantity;

        public string Name { get; set; }

        public double Price
        {
            get { return price; }
            set
            {
                if (value >= 0)
                    price = value;
                else
                {
                    Console.WriteLine("Invalid price!");
                    price = 0;
                }
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value >= 0)
                    quantity = value;
                else
                {
                    Console.WriteLine("Invalid quantity!");
                    quantity = 0;
                }
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine("Ime na produkt: " + Name);
            Console.WriteLine("Cena: " + Price.ToString("F2"));
            Console.WriteLine("Kolichestvo: " + Quantity);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Product product1 = new Product();
            product1.Name = "Laptop";
            product1.Price = 1450;
            product1.Quantity = 3;

            product1.PrintInfo();

            Console.WriteLine();

            Product product2 = new Product();
            product2.Name = "Telefon";
            product2.Price = -500;
            product2.Quantity = -2;

            product2.PrintInfo();
        }
    }
}