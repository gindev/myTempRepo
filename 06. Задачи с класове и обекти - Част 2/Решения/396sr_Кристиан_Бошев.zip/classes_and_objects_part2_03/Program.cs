﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();

            Employee emp2 = new Employee("Петър Иванов", "Програмист", 2500);

            Console.WriteLine("Служител 1:");
            emp1.PrintInfo();

            Console.WriteLine("\nСлужител 2:");
            emp2.PrintInfo();
        }
    }
}
