﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            int choice;

            do
            {
                Console.WriteLine("\n--- МЕНЮ ---");
                Console.WriteLine("1. Добавяне на книга");
                Console.WriteLine("2. Показване на всички книги");
                Console.WriteLine("3. Търсене на книга по заглавие");
                Console.WriteLine("4. Изход");

                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Book book = new Book();

                        Console.Write("Заглавие: ");
                        book.Title = Console.ReadLine();

                        Console.Write("Автор: ");
                        book.Author = Console.ReadLine();

                        Console.Write("Година: ");
                        book.Year = int.Parse(Console.ReadLine());

                        library.AddBook(book);
                        Console.WriteLine("Книгата е добавена!");
                        break;

                    case 2:
                        library.ShowAllBooks();
                        break;

                    case 3:
                        Console.Write("Въведете заглавие за търсене: ");
                        string title = Console.ReadLine();

                        Book found = library.FindBookByTitle(title);

                        if (found != null)
                        {
                            Console.WriteLine("Намерена книга:");
                            found.PrintInfo();
                        }
                        else
                        {
                            Console.WriteLine("Книгата не е намерена.");
                        }
                        break;

                    case 4:
                        Console.WriteLine("Изход...");
                        break;

                    default:
                        Console.WriteLine("Невалиден избор!");
                        break;
                }

            } while (choice != 4);
        }
    }
}
