﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_06
{
    internal class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine($"{Title} | {Author} | {Year}");
        }
    }
}
