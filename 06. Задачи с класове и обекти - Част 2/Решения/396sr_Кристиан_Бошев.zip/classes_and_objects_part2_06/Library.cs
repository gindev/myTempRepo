﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_06
{
    internal class Library
    {
        private List<Book> books = new List<Book>();
        public void AddBook(Book book)
        {
            books.Add(book);
        }
        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Няма добавени книги.");
                return;
            }

            Console.WriteLine("Списък с книги:");
            foreach (Book book in books)
            {
                book.PrintInfo();
            }
        }
        public Book FindBookByTitle(string title)
        {
            foreach (Book book in books)
            {
                if (book.Title.ToLower() == title.ToLower())
                {
                    return book;
                }
            }
            return null;
        }
    }
}
