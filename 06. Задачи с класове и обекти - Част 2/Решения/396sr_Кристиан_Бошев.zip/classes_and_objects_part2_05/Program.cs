﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount acc1 = new BankAccount("BG11AAAA1234", "Иван Иванов", 500.00m);
            BankAccount acc2 = new BankAccount("BG22BBBB5678", "Мария Петрова", 820.00m);
            BankAccount acc3 = new BankAccount("BG33CCCC9999", "Георги Димитров", 1200.00m);

            Console.WriteLine("Сметка 1:");
            acc1.PrintInfo();

            Console.WriteLine("Сметка 2:");
            acc2.PrintInfo();

            Console.WriteLine("Сметка 3:");
            acc3.PrintInfo();

            Console.WriteLine($"Общ брой създадени сметки: {BankAccount.GetAccountCount()}");
        }
    }
}
