﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_05
{
    internal class BankAccount
    {
        public string AccountNumber { get; set; }
        public string HolderName { get; set; }
        public decimal Balance { get; set; }

        private static int accountCount = 0;

        public BankAccount(string accountNumber, string holderName, decimal balance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = balance;

            accountCount++;
        }
        public void PrintInfo()
        {
            Console.WriteLine($"{AccountNumber} | {HolderName} | {Balance:F2}\n");
        }
        public static int GetAccountCount()
        {
            return accountCount;
        }
    }
}
