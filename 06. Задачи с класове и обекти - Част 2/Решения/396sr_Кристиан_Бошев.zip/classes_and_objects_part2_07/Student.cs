﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_07
{
    internal class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
    }
}
