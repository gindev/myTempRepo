﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_07
{
    internal class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }

        private List<Student> students = new List<Student>();

        public bool HasFreeSeats()
        {
            return students.Count < MaxStudents;
        }
        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                students.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine("Няма свободни места в курса.");
            }
        }
        public void PrintStudents()
        {
            Console.WriteLine($"\nКурс: {CourseName}");
            Console.WriteLine("Записани студенти:");

            if (students.Count == 0)
            {
                Console.WriteLine("Няма записани студенти.");
                return;
            }

            int index = 1;
            foreach (Student student in students)
            {
                Console.WriteLine($"{index}. {student.Name}, ФН: {student.FacultyNumber}");
                index++;
            }
        }
    }
}
