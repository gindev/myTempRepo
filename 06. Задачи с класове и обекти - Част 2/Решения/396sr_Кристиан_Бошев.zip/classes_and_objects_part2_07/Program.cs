﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Course course = new Course
            {
                CourseName = "Увод в програмирането",
                MaxStudents = 2
            };

            course.AddStudent(new Student { Name = "Иван Петров", FacultyNumber = "123" });
            course.AddStudent(new Student { Name = "Мария Георгиева", FacultyNumber = "456" });
            course.AddStudent(new Student { Name = "Георги Стоянов", FacultyNumber = "789" });

            course.PrintStudents();
        }
    }
}