﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_02
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Product p1 = new Product();

            Console.Write("Въведете име на продукт: ");
            p1.Name = Console.ReadLine();

            Console.Write("Въведете цена: ");
            p1.Price = decimal.Parse(Console.ReadLine());

            Console.Write("Въведете количество: ");
            p1.Quantity = int.Parse(Console.ReadLine());

            Console.WriteLine();
            p1.PrintInfo();
        }
    }
}
