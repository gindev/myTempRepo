﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_02
{
    internal class Product
    {
        private string name;
        private decimal price;
        private int quantity;


        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public decimal Price
        {
            get { return price; }
            set
            {
                if (value >= 0)
                {
                    price = value;
                }
                else
                {
                    Console.WriteLine("Цената не може да е отрицателна!");
                    price = 0;
                }
            }
        }
        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value >= 0)
                {
                    quantity = value;
                }
                else
                {
                    Console.WriteLine("Количеството не може да е отрицателно!");
                    quantity = 0;
                }
            }
        }
        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукт: {Name}");
            Console.WriteLine($"Цена: {Price:F2}");
            Console.WriteLine($"Количество: {Quantity}");
        }
    }
}