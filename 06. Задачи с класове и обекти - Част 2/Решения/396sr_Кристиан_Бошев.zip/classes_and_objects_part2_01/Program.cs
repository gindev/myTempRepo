﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Steve";
            p1.Surname = "Craft";
            p1.Age = "18";

            Console.WriteLine("Person ID:");
            Console.WriteLine($"Name: {p1.Name}");
            Console.WriteLine($"Surname: {p1.Surname}");
            Console.WriteLine($"Age: {p1.Age}");

            Person p2 = new Person();
            p2.Name = "Jane";
            p2.Surname = "Doe";
            p2.Age = "23";

            Console.WriteLine("\nPerson ID:");
            Console.WriteLine($"Name: {p2.Name}");
            Console.WriteLine($"Surname: {p2.Surname}");
            Console.WriteLine($"Age: {p2.Age}");
        }
    }
}
