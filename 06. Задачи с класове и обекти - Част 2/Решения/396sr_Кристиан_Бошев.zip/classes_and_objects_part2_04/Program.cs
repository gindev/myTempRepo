﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentGroup group = new StudentGroup("КН-101\n");

            group.AddStudent(new Student { Name = "Иван Петров", FacultyNumber = "12345", AverageGrade = 5.50 });
            group.AddStudent(new Student { Name = "Мария Георгиева", FacultyNumber = "12346", AverageGrade = 5.90 });
            group.AddStudent(new Student { Name = "Георги Стоянов", FacultyNumber = "12347", AverageGrade = 4.80 });

            group.PrintStudents();

            Student best = group.GetBestStudent();

            Console.WriteLine("\nСтудент с най-висок успех:");
            Console.WriteLine($"{best.Name}, ФН: {best.FacultyNumber}, Успех: {best.AverageGrade:F2}");
        }
    }
}
