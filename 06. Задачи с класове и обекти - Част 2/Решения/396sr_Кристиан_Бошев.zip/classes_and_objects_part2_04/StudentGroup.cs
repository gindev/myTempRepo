﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_04
{
    internal class StudentGroup
    {
        public string GroupName { get; set; }
        public List<Student> Students { get; set; }

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            Students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            Students.Add(student);
        }

        public void PrintStudents()
        {
            Console.WriteLine($"Група: {GroupName}");
            Console.WriteLine("Студенти:");

            for (int i = 0; i < Students.Count; i++)
            {
                Students[i].PrintInfo(i + 1);
            }
        }

        public Student GetBestStudent()
        {
            Student best = Students[0];

            foreach (Student student in Students)
            {
                if (student.AverageGrade > best.AverageGrade)
                {
                    best = student;
                }
            }

            return best;
        }
    }
}
