﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part2_04
{
    internal class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
        public double AverageGrade { get; set; }

        public void PrintInfo(int index)
        {
            Console.WriteLine($"{index}. {Name}, ФН: {FacultyNumber}, Успех: {AverageGrade:F2}");
        }
    }
}
