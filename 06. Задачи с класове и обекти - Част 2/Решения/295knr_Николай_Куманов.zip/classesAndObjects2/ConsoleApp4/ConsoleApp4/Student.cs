﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Student
    {
        string name;
        string facultyNumber;
        double averageGrade;

        public Student(string name, string facultyNumber, double averageGrade)
        {
            this.name = name;
            this.facultyNumber = facultyNumber;
            this.averageGrade = averageGrade;
        }
        public override string ToString()
        {
            return $"{Name}, faculty number: {FacultyNumber}, grade: {AverageGrade:F2}";
        }

        public string Name { get => name; set => name = value; }
        public string FacultyNumber { get => facultyNumber; set => facultyNumber = value; }
        public double AverageGrade { get => averageGrade; set => averageGrade = value; }
    }
}
