﻿using System;
using System.Collections.Generic;

namespace ConsoleApp4
{
    internal class StudentGroup
    {
        string groupName;
        List<Student> studentList;

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            studentList = new List<Student>();
        }
        public void AddStudent(Student student)
        {
            studentList.Add(student);
        }
        public void PrintStudents()
        {
            Console.WriteLine($"Group: {GroupName}");
            Console.WriteLine("Students:");
            for (int i = 0; i < studentList.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {studentList[i]}");
            }
        }

        public Student GetBestStudent()
        {
            if (studentList.Count == 0) return null;

            Student bestStudent = studentList[0];
            foreach (Student student in studentList)
            {
                if (student.AverageGrade > bestStudent.AverageGrade)
                {
                    bestStudent = student;
                }
            }
            return bestStudent;
        }

        public string GroupName { get => groupName; set => groupName = value; }
    }
}
