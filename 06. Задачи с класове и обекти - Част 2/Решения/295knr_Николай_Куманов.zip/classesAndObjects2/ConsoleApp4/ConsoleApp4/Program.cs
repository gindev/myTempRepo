﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentGroup group = new StudentGroup("KN-101");

            group.AddStudent(new Student("Ivan Petrov", "12345", 5.50));
            group.AddStudent(new Student("Mariq Georgieva", "12346", 5.90));
            group.AddStudent(new Student("Georgi Stoqnov", "12347", 4.80));

            group.PrintStudents();

            Console.WriteLine("Student with highest grade:");
            Student best = group.GetBestStudent();
            if (best != null)
            {
                Console.WriteLine(best);
            }

        }
    }
}
