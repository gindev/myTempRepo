﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Library
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine("Book added.");
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Library is empty.");
                return;
            }

            Console.WriteLine("List of all books:");
            foreach (var book in books)
            {
                Console.WriteLine(book);
            }
        }

        public void FindBookByTitle(string title)
        {
            Book foundBook = books.Find(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));

            if (foundBook != null)
            {
                Console.WriteLine($"Book found: {foundBook}");
            }
            else
            {
                Console.WriteLine("Book with this name was not found.");
            }
        }
    }
}
