﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library myLibrary = new Library();
            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("--- Menu ---");
                Console.WriteLine("1. Add book");
                Console.WriteLine("2. Show all books");
                Console.WriteLine("3. Search book by title");
                Console.WriteLine("4. Exit");
                Console.Write("Choose option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Input title: ");
                        string title = Console.ReadLine();
                        Console.Write("Input author: ");
                        string author = Console.ReadLine();
                        Console.Write("Input year: ");
                        if (int.TryParse(Console.ReadLine(), out int year))
                        {
                            myLibrary.AddBook(new Book(title, author, year));
                        }
                        else
                        {
                            Console.WriteLine("Invalid year.");
                        }
                        break;

                    case "2":
                        myLibrary.ShowAllBooks();
                        break;

                    case "3":
                        Console.Write("Input title for search: ");
                        string searchTitle = Console.ReadLine();
                        myLibrary.FindBookByTitle(searchTitle);
                        break;

                    case "4":
                        isRunning = false;
                        Console.WriteLine("Exitting...");
                        break;

                    default:
                        Console.WriteLine("Invalid command. Try again.");
                        break;
                }
            }

        }
    }
}
