﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product validProduct = new Product();
            validProduct.Name = "Лаптоп";
            validProduct.Price = 1450.00;
            validProduct.Quantity = 3;

            validProduct.PrintInfo();


            Product invalidProduct = new Product();
            invalidProduct.Name = "Смартфон";
            invalidProduct.Price = -500.00;
            invalidProduct.Quantity = -5;

            invalidProduct.PrintInfo();
        }
    }
}
