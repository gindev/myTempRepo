﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Product
    {
        double price;
        int quantity;

        public string Name { get; set; }

        public double Price
        {
            get => price;
            set
            {
                if (value >= 0)
                {
                    price = value;
                }
                else
                {
                    Console.WriteLine("Грешка: Цената не може да бъде отрицателна! Зададена стойност: 0.");
                    price = 0;
                }
            }
        }

        public int Quantity
        {
            get => quantity;
            set
            {
                if (value >= 0)
                {
                    quantity = value;
                }
                else
                {
                    Console.WriteLine("Грешка: Количеството не може да бъде отрицателно! Зададена стойност: 0.");
                    quantity = 0;
                }
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукт: {Name}");
            Console.WriteLine($"Цена: {Price:F2}");
            Console.WriteLine($"Количество: {Quantity}");
        }
    }
}
