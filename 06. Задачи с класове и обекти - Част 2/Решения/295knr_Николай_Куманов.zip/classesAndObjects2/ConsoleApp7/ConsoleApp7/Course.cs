﻿using System;
using System.Collections.Generic;

namespace ConsoleApp7
{
    internal class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }
        private List<Student> students;

        public Course(string courseName, int maxStudents)
        {
            CourseName = courseName;
            MaxStudents = maxStudents;
            students = new List<Student>();
        }
            
        public bool HasFreeSeats()
        {
            return students.Count < MaxStudents;
        }

        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                students.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine("Няма свободни места в курса.");
            }
        }

        public void PrintStudents()
        {
            Console.WriteLine($"\nЗаписани студенти в курс {CourseName}:");
            foreach (var student in students)
            {
                Console.WriteLine($"- {student.Name}, ФН: {student.FacultyNumber}");
            }
        }
    }
}
