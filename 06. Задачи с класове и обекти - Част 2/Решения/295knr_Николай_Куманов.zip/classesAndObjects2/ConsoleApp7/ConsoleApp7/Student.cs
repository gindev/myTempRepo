﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }

        public Student(string name, string facultyNumber)
        {
            Name = name;
            FacultyNumber = facultyNumber;
        }
    }
}
