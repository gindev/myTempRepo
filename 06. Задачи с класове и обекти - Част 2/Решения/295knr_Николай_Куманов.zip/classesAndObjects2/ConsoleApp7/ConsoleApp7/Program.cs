﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Course csharpCourse = new Course("C# OOP", 2);

            csharpCourse.AddStudent(new Student("Иван Петров", "121221001"));
            csharpCourse.AddStudent(new Student("Мария Георгиева", "121221002"));

            csharpCourse.AddStudent(new Student("Георги Стоянов", "121221003"));

            csharpCourse.PrintStudents();
        }
    }
}
