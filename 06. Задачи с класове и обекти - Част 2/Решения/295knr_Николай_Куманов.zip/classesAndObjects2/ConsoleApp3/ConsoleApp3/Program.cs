﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Служител 1:");
            Employee employee1 = new Employee();
            employee1.PrintInfo();

            Console.WriteLine("Служител 2:");
            Employee employee2 = new Employee("Иван Петров", "Мениджър", 2500.50);
            employee2.PrintInfo();
        }
    }
}
