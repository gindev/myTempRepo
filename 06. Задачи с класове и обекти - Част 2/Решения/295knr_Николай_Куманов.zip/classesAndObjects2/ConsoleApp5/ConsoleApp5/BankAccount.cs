﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class BankAccount
    {
        private static int totalAccounts = 0;

        public string AccountNumber { get; set; }
        public string OwnerName { get; set; }
        public double Balance { get; set; }

        public BankAccount(string accountNumber, string ownerName, double balance)
        {
            AccountNumber = accountNumber;
            OwnerName = ownerName;
            Balance = balance;
            totalAccounts++;
        }

        public void PrintInfo(int index)
        {
            Console.WriteLine($"Сметка {index}: {AccountNumber} | {OwnerName} | {Balance:F2}");
        }

        public static int GetTotalAccounts()
        {
            return totalAccounts;
        }
    }
}
