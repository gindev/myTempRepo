﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount acc1 = new BankAccount("BG11AAAA1234", "Иван Иванов", 500.00);
            BankAccount acc2 = new BankAccount("BG22BBBB5678", "Мария Петрова", 820.00);
            BankAccount acc3 = new BankAccount("BG33CCCC9999", "Георги Димитров", 1200.00);

            acc1.PrintInfo(1);
            acc2.PrintInfo(2);
            acc3.PrintInfo(3);

            Console.WriteLine($"\nОбщ брой създадени сметки: {BankAccount.GetTotalAccounts()}");
        }
    }
}
