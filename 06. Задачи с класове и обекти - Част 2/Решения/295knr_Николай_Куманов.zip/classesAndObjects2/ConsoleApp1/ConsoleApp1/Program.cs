﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Person person = new Person();
            person.FirstName = "Мария";
            person.LastName = "Георгиева";
            person.Age = 21;

            person.DisplayInfo();

        }
    }
}
