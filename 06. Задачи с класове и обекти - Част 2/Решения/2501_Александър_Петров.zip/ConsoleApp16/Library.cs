﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{
    internal class Library
    {
        private List<Book> books;

        public Library()
        {
            books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Library is empty.");
            }
            else
            {
                foreach (var book in books)
                {
                    Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, Year: {book.Year}");
                }
            }
        }

        public void FindBookByTitle(string title)
        {
            var foundBooks = books.FindAll(b => b.Title.IndexOf(title, StringComparison.OrdinalIgnoreCase) >= 0);
            if (foundBooks.Count == 0)
            {
                Console.WriteLine("Book not found.");
            }
            else
            {
                foreach (var book in foundBooks)
                {
                    Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, Year: {book.Year}");
                }
            }
        }
    }
}
