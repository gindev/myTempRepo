﻿namespace ConsoleApp16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Add book");
                Console.WriteLine("2. See all books");
                Console.WriteLine("3. Search for a book by title");
                Console.WriteLine("4. Exit");
                Console.Write("Choose option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter title: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter author: ");
                        string author = Console.ReadLine();
                        Console.Write("Enter year of publication: ");
                        if (int.TryParse(Console.ReadLine(), out int year))
                        {
                            Book newBook = new Book(title, author, year);
                            library.AddBook(newBook);
                            Console.WriteLine("Book added successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Year must be a number.");
                        }
                        break;
                    case "2":
                        library.ShowAllBooks();
                        break;
                    case "3":
                        Console.Write("Enter a search title: ");
                        string searchTitle = Console.ReadLine();
                        library.FindBookByTitle(searchTitle);
                        break;
                    case "4":
                        Console.WriteLine("Exit out of program. Bye!");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
    }
}
