﻿namespace ConsoleApp13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee();

            Employee employee2 = new Employee("Aleksandar Petrov", "Programist", 1500);

            Console.WriteLine("Information for the first employee:");
            employee1.PrintInfo();

            Console.WriteLine("Information for the second employee:");
            employee2.PrintInfo();
        }
    }
    
}

