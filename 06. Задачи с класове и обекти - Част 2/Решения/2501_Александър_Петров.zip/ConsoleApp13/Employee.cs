﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp13
{
    internal class Employee
    {
        public string Ime { get; set; }
        public string Dlujnost { get; set; }
        public decimal Zaplata { get; set; }

        public Employee()
        {
            Ime = "Ne e zadadeno";
            Dlujnost = "Ne e zadadena";
            Zaplata = 0;
        }

        public Employee(string ime, string dlujnost, decimal zaplata)
        {
            Ime = ime;
            Dlujnost = dlujnost;
            Zaplata = zaplata;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Ime: {Ime}");
            Console.WriteLine($"Dlujnost: {Dlujnost}");
            Console.WriteLine($"Zaplata: {Zaplata}.");
            Console.WriteLine();
        }
    }
}
