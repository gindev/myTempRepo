﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    internal class Student
    {
        public string Name { get; set; }
        public string FacultyNumber { get; set; }
        public double AverageGrade { get; set; }

        public Student(string name, string facultyNumber, double averageGrade)
        {
            Name = name;
            FacultyNumber = facultyNumber;
            AverageGrade = averageGrade;
        }
    }
}
