﻿namespace ConsoleApp14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentGroup group = new StudentGroup("IT2");

            group.AddStudent(new Student("Aleksandar Petrov", "2501", 6.00));
            group.AddStudent(new Student("Kaloqn Buzqkov", "2587", 3.40));
            group.AddStudent(new Student("Galin Todorov", "2467", 2.00));

            group.PrintStudents();

            Student topStudent = group.GetBestStudent();
            if (topStudent != null)
            {
                Console.WriteLine($"\nTop Student: {topStudent.Name}, Faculty Number: {topStudent.FacultyNumber}, Average Grade: {topStudent.AverageGrade}");
            }
            else
            {
                Console.WriteLine("The group is empty.");
            }
        }
    }
}

