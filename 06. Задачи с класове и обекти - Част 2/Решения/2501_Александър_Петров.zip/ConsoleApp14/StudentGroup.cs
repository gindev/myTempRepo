﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    internal class StudentGroup
    {
        public string GroupName { get; set; }
        private List<Student> students;

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void PrintStudents()
        {
            Console.WriteLine($"Group {GroupName}:");
            foreach (var student in students)
            {
                Console.WriteLine($"Name: {student.Name}, Faculty Number: {student.FacultyNumber}, Average Grade: {student.AverageGrade}");
            }
        }

        public Student GetBestStudent()
        {
            if (students.Count == 0)
                return null;

            Student bestStudent = students[0];
            foreach (var student in students)
            {
                if (student.AverageGrade > bestStudent.AverageGrade)
                {
                    bestStudent = student;
                }
            }
            return bestStudent;
        }
    }
}
