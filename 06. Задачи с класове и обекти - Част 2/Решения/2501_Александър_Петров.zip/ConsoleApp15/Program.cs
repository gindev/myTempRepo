﻿namespace ConsoleApp15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account1 = new BankAccount("BG80BNBG96611020345678", "Aleksandar Petrov", 2500.50m);
            BankAccount account2 = new BankAccount("BG93BNBG96611020345679", "Kaloqn Buzqkov", 1500.75m);
            BankAccount account3 = new BankAccount("BG55BNBG96611020345680", "Galin Todorov", 500.00m);

            account1.PrintInfo();
            account2.PrintInfo();
            account3.PrintInfo();

            BankAccount.PrintTotalAccounts();
        }
    }
}
