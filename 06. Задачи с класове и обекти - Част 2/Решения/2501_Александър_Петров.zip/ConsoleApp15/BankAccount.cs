﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    internal class BankAccount
    {
        public string AccountNumber { get; set; }
        public string AccountHolder { get; set; }
        public decimal Balance { get; set; }

        private static int totalAccounts = 0;

        public BankAccount(string accountNumber, string accountHolder, decimal initialBalance)
        {
            this.AccountNumber = accountNumber;
            this.AccountHolder = accountHolder;
            this.Balance = initialBalance;

            totalAccounts++;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Account Holder: {AccountHolder}");
            Console.WriteLine($"Balance: {Balance}");
            Console.WriteLine("---------------------------");
        }

        public static void PrintTotalAccounts()
        {
            Console.WriteLine($"Total Accounts: {totalAccounts}");
        }
    }
}
