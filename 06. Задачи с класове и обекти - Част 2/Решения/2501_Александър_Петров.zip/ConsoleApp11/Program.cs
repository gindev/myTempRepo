﻿namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.FirstName = "Aleksandar";
            person.LastName = "Petrov";
            person.Age = 20;

            Console.WriteLine($"FirstName: {person.FirstName}");
            Console.WriteLine($"LastName: {person.LastName}");
            Console.WriteLine($"Age: {person.Age}");
        }
    }
}
