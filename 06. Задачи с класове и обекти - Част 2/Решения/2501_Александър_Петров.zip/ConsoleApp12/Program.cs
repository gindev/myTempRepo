﻿namespace ConsoleApp12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product prod1 = new Product("Pencil", 1.5m, 10);
            prod1.PrintInfo();

            Console.WriteLine();

            Product prod2 = new Product("Notebook", -5, -3);
            prod2.PrintInfo();

            Console.WriteLine();

            prod2.Price = -10; 
            prod2.Quantity = -2; 
            prod2.PrintInfo();
        }
    }
}
