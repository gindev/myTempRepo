﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    internal class Product
    {
        public string Name { get; set; }

        private decimal price;
        public decimal Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Cena ne moje da bude otricatelna. Zadadeno e stoinost po podrazbirane 0.");
                    price = 0;
                }
                else
                {
                    price = value;
                }
            }
        }

        private int quantity;
        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Kolichestvo ne moje da bude otricatelna. Zadadeno e stoinost po podrazbirane 0.");
                    quantity = 0;
                }
                else
                {
                    quantity = value;
                }
            }
        }

        public Product()
        {
            Name = "Nevedom product";
            Price = 0;
            Quantity = 0;
        }

        public Product(string name, decimal price, int quantity)
        {
            Name = name;

            if (price < 0)
            {
                Console.WriteLine("Vavedena e nevalidna cena. Zadadeno e 0.");
                this.price = 0;
            }
            else
            {
                this.price = price;
            }

            if (quantity < 0)
            {
                Console.WriteLine("Vavedeno e nevalidno kolichestvo. Zadadeno e 0.");
                this.quantity = 0;
            }
            else
            {
                this.quantity = quantity;
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine($"ProductName: {Name}");
            Console.WriteLine($"Price: {Price}");
            Console.WriteLine($"Quantity: {Quantity}");
        }
    }

}

