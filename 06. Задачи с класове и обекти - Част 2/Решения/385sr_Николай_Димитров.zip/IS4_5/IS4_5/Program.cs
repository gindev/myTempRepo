﻿namespace IS4_5
{
    class BankAccount
    {
        public string AccountNumber { get; set; }
        public string HolderName { get; set; }
        public decimal Balance { get; set; }

        public static int AccountsCount = 0;

        public BankAccount(string accountNumber, string holderName, decimal balance)
        {
            AccountNumber = accountNumber;
            HolderName = holderName;
            Balance = balance;

            AccountsCount++;
        }

        public void PrintInfo()
        {
            Console.WriteLine(AccountNumber + " | " + HolderName + " | " + Balance);
        }

        public static void PrintAccountsCount()
        {
            Console.WriteLine("Общ брой създадени сметки: " + AccountsCount);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BankAccount acc1 = new BankAccount("BG11AAAA1234", "Иван Иванов", 500);
            BankAccount acc2 = new BankAccount("BG22BBBB5678", "Мария Петрова", 820);
            BankAccount acc3 = new BankAccount("BG33CCCC9999", "Георги Димитров", 1200);

            Console.WriteLine("Сметка 1:");
            acc1.PrintInfo();

            Console.WriteLine("Сметка 2:");
            acc2.PrintInfo();

            Console.WriteLine("Сметка 3:");
            acc3.PrintInfo();

            Console.WriteLine();

            BankAccount.PrintAccountsCount();
        }
    }
}
