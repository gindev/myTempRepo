﻿namespace IS4_3
{
    class Employee
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public decimal Salary { get; set; }

        public Employee()
        {
            Name = "Няма въведено име";
            Position = "Не е зададена";
            Salary = 0;
        }

        public Employee(string name, string position, decimal salary)
        {
            Name = name;
            Position = position;
            Salary = salary;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Име: " + Name);
            Console.WriteLine("Длъжност: " + Position);
            Console.WriteLine("Заплата: " + Salary);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Employee emp2 = new Employee("Петър Иванов", "Програмист", 2500);

            Console.WriteLine("Служител 1:");
            emp1.PrintInfo();

            Console.WriteLine();

            Console.WriteLine("Служител 2:");
            emp2.PrintInfo();
        }
    }
}
