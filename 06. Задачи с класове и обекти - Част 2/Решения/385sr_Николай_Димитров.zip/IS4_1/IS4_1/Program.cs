﻿namespace IS4_1
{
    class Person
    {
        private string firstName;
        private string lastName;
        private int age;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            person.FirstName = "Мария";
            person.LastName = "Георгиева";
            person.Age = 21;

            Console.WriteLine($"Име: {person.FirstName}");
            Console.WriteLine($"Фамилия: {person.LastName}");
            Console.WriteLine($"Възраст: {person.Age}");
        }
    }
}
