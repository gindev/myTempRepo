﻿namespace IS4_4
{
    class Student
    {
        public string Name { get; set; }
        public int FacultyNumber { get; set; }
        public double Grade { get; set; }
    }

    class StudentGroup
    {
        public string GroupName { get; set; }
        public List<Student> Students { get; set; }

        public StudentGroup(string groupName)
        {
            GroupName = groupName;
            Students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            Students.Add(student);
        }

        public void PrintStudents()
        {
            foreach (var s in Students)
            {
                Console.WriteLine($"Име: {s.Name}, ФН: {s.FacultyNumber}, Успех: {s.Grade}");
            }
        }

        public Student GetBestStudent()
        {
            Student best = Students[0];

            foreach (var s in Students)
            {
                if (s.Grade > best.Grade)
                    best = s;
            }

            return best;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            StudentGroup group = new StudentGroup("Група 1");

            group.AddStudent(new Student { Name = "Иван", FacultyNumber = 123, Grade = 5.50 });
            group.AddStudent(new Student { Name = "Мария", FacultyNumber = 124, Grade = 6.00 });
            group.AddStudent(new Student { Name = "Петър", FacultyNumber = 125, Grade = 5.20 });

            Console.WriteLine("Всички студенти:");
            group.PrintStudents();

            Console.WriteLine();

            Student best = group.GetBestStudent();
            Console.WriteLine("Най-добър студент:");
            Console.WriteLine($"Име: {best.Name}, Успех: {best.Grade}");
        }
    }
}
