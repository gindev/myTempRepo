﻿namespace IS4_6
{
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
    }

    class Library
    {
        public List<Book> Books { get; set; }

        public Library()
        {
            Books = new List<Book>();
        }

        public void AddBook(Book book)
        {
            Books.Add(book);
        }

        public void ShowAllBooks()
        {
            if (Books.Count == 0)
            {
                Console.WriteLine("Няма добавени книги.");
                return;
            }

            foreach (Book book in Books)
            {
                Console.WriteLine("Заглавие: " + book.Title);
                Console.WriteLine("Автор: " + book.Author);
                Console.WriteLine("Година: " + book.Year);
                Console.WriteLine();
            }
        }

        public Book FindBookByTitle(string title)
        {
            foreach (Book book in Books)
            {
                if (book.Title.ToLower() == title.ToLower())
                {
                    return book;
                }
            }

            return null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            int choice;

            do
            {
                Console.WriteLine("1. Добави книга");
                Console.WriteLine("2. Покажи всички книги");
                Console.WriteLine("3. Търси книга по заглавие");
                Console.WriteLine("4. Изход");
                Console.Write("Избор: ");

                choice = int.Parse(Console.ReadLine());
                Console.WriteLine();

                if (choice == 1)
                {
                    Book book = new Book();

                    Console.Write("Въведете заглавие: ");
                    book.Title = Console.ReadLine();

                    Console.Write("Въведете автор: ");
                    book.Author = Console.ReadLine();

                    Console.Write("Въведете година: ");
                    book.Year = int.Parse(Console.ReadLine());

                    library.AddBook(book);

                    Console.WriteLine("Книгата е добавена.");
                }
                else if (choice == 2)
                {
                    library.ShowAllBooks();
                }
                else if (choice == 3)
                {
                    Console.Write("Въведете заглавие за търсене: ");
                    string title = Console.ReadLine();

                    Book foundBook = library.FindBookByTitle(title);

                    if (foundBook != null)
                    {
                        Console.WriteLine("Намерена книга:");
                        Console.WriteLine("Заглавие: " + foundBook.Title);
                        Console.WriteLine("Автор: " + foundBook.Author);
                        Console.WriteLine("Година: " + foundBook.Year);
                    }
                    else
                    {
                        Console.WriteLine("Книгата не е намерена.");
                    }
                }
                else if (choice == 4)
                {
                    Console.WriteLine("Изход от програмата.");
                }
                else
                {
                    Console.WriteLine("Невалиден избор.");
                }

                Console.WriteLine();

            } while (choice != 4);
        }
    }
}
