﻿namespace IS4_7
{
    class Student
    {
        public string Name { get; set; }
        public int FacultyNumber { get; set; }
    }

    class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }
        public List<Student> Students { get; set; }

        public Course(string courseName, int maxStudents)
        {
            CourseName = courseName;
            MaxStudents = maxStudents;
            Students = new List<Student>();
        }

        public bool HasFreeSeats()
        {
            return Students.Count < MaxStudents;
        }

        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                Students.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine("Няма свободни места в курса.");
            }
        }

        public void PrintStudents()
        {
            Console.WriteLine("\nЗаписани студенти:");
            foreach (var s in Students)
            {
                Console.WriteLine($"Име: {s.Name}, ФН: {s.FacultyNumber}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Course course = new Course("Програмиране", 2);

            course.AddStudent(new Student { Name = "Иван Петров", FacultyNumber = 123 });
            course.AddStudent(new Student { Name = "Мария Георгиева", FacultyNumber = 124 });

            course.AddStudent(new Student { Name = "Петър Иванов", FacultyNumber = 125 });

            course.PrintStudents();
        }
    }
}
