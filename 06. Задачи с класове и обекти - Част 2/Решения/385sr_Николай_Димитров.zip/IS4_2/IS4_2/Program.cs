﻿namespace IS4_2
{
    class Product
    {
        private string name;
        private decimal price;
        private int quantity;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public decimal Price
        {
            get { return price; }
            set
            {
                if (value >= 0)
                    price = value;
                else
                {
                    Console.WriteLine("Цената не може да е отрицателна!");
                    price = 0;
                }
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value >= 0)
                    quantity = value;
                else
                {
                    Console.WriteLine("Количеството не може да е отрицателно!");
                    quantity = 0;
                }
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine("Име на продукт: " + Name);
            Console.WriteLine("Цена: " + Price);
            Console.WriteLine("Количество: " + Quantity);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Product product = new Product();

            product.Name = "Лаптоп";
            product.Price = 1450;
            product.Quantity = 3;

            
            product.Price = -50;
            product.Quantity = -2;

            Console.WriteLine();
            product.PrintInfo();
        }
    }
}
