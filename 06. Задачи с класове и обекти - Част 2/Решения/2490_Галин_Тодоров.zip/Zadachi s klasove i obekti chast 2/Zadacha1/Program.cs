﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Person person = new Person();

            
            person.FirstName = "Galin";
            person.LastName = "Todorov";
            person.Age = 21;

            
            Console.WriteLine("Име: " + person.FirstName);
            Console.WriteLine("Фамилия: " + person.LastName);
            Console.WriteLine("Възраст: " + person.Age);

            Console.ReadLine();
        }
    }
}
       
    

