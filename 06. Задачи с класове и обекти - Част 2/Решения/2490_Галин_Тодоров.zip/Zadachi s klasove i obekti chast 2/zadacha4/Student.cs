﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Student
    {
        public string Name;
        public string FN;
        public double Grade;

        public Student(string name, string fn, double grade)
        {
            this.Name = name;
            this.FN = fn;
            this.Grade = grade;
        }
    }

}

