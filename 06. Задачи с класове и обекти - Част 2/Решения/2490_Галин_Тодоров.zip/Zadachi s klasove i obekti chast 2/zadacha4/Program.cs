﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Въведете име на групата : ");
            string gName = Console.ReadLine();
            StudentGroup group = new StudentGroup(gName);

            
            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine($"\nСтудент #{i}:");

                Console.Write("Име: ");
                string name = Console.ReadLine();

                Console.Write("Фак. номер: ");
                string fn = Console.ReadLine();

                Console.Write("Оценка: ");
                double grade = double.Parse(Console.ReadLine());
 
                group.AddStudent(new Student(name, fn, grade));
            }

           
            group.PrintStudents();
            group.GetBestStudent();

           
            Console.ReadKey();


        }
    }
}
