﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class StudentGroup
    {

        public string GroupName;
        private List<Student> students;

        public StudentGroup(string name)
        {
            GroupName = name;
            students = new List<Student>();
        }

        public void AddStudent(Student s)
        {
            students.Add(s);
        }

        public void PrintStudents()
        {
            Console.WriteLine($"Група: {GroupName}");
            Console.WriteLine("\nСтуденти:");

            int count = 1;
            foreach (Student s in students)
            {
                Console.WriteLine($"{count}. {s.Name}, ФН: {s.FN}, Успех: {s.Grade:F2}");
                count++;
            }
        }

        public void GetBestStudent()
        {
            if (students.Count == 0) return;

            
            Student topStudent = students[0];

            for (int i = 1; i < students.Count; i++)
            {
                if (students[i].Grade > topStudent.Grade)
                {
                    topStudent = students[i];
                }
            }

            Console.WriteLine("\nСтудент с най-висок успех:");
            Console.WriteLine($"{topStudent.Name}, ФН: {topStudent.FN}, Успех: {topStudent.Grade:F2}");
        }
    }
}

