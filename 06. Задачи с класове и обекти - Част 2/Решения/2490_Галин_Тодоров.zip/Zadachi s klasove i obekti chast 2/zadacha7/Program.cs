﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Course myCourse = new Course("Програмиране на C#", 2);

          
            myCourse.AddStudent(new Student("Иван Петров", "12345"));
            myCourse.AddStudent(new Student("Мария Георгиева", "12346"));

        
            myCourse.AddStudent(new Student("Георги Стоянов", "12347"));

          
            myCourse.PrintStudents();

           
            if (!myCourse.HasFreeSeats())
            {
                Console.WriteLine("\n Няма свободни места в курса.");
            }

            Console.ReadKey();
        }
    }
}
        
    

