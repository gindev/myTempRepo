﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Course
    {
        public string CourseName { get; set; }
        public int MaxCapacity { get; set; }
        private List<Student> students = new List<Student>();

        public Course(string name, int capacity)
        {
            CourseName = name;
            MaxCapacity = capacity;
        }

        public bool HasFreeSeats()
        {
            return students.Count < MaxCapacity;
        }

        
        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                students.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine($" Няма свободни места в курса за {student.Name}.");
            }
        }

        
        public void PrintStudents()
        {
            Console.WriteLine($"\n Списък на курса: {CourseName} ---");
            if (students.Count == 0) Console.WriteLine("Няма записани студенти.");

            foreach (var s in students)
            {
                Console.WriteLine($"- {s.Name} (ФН: {s.FN})");
            }
        }
    }
}

