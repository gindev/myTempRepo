﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha7
{
    internal class Student
    {
        public string Name { get; set; }
        public string FN { get; set; }

        public Student(string name, string fn)
        {
            Name = name;
            FN = fn;
        }
    }

}

