﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class BankAccount
    {
        private static int totalAccounts = 0;

    
        public string IBAN { get; set; }
        public string Owner { get; set; }
        public double Balance { get; set; }

        public BankAccount(string iban, string owner, double balance)
        {
            IBAN = iban;
            Owner = owner;
            Balance = balance;

            
            totalAccounts++;
        }

        public static int GetTotalAccounts()
        {
            return totalAccounts;
        }

        public void PrintInfo(int index)
        {
            Console.WriteLine($"Сметка {index}: {IBAN} | {Owner} | {Balance:F2}");
        }
    }
}

