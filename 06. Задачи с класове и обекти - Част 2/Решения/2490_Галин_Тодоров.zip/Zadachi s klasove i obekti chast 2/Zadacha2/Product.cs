﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Product
    {
        private string name;
        private double price;
        private int quantity;

     
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Price
        {
            get { return price; }
            set
            {
                
                if (value >= 0)
                    price = value;
                else
                    Console.WriteLine("Невалидна стойност! Положително число.");
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                
                if (value >= 0)
                    quantity = value;
                else
                    Console.WriteLine("Невалидна стойност! Положително число.");
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукт: {Name}");
            Console.WriteLine($"Цена: {Price:F2}");
            Console.WriteLine($"Количество: {Quantity}");
        }
    }
}
