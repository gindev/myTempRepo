﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Product product = new Product();

            
        
            product.Name = Console.ReadLine();

           
            while (true)
            {
              
                double p = double.Parse(Console.ReadLine());
                if (p >= 0)
                {
                    product.Price = p;
                    break;
                }
                Console.WriteLine("Цената не може да бъде отрицателна, въведете друга");
            }

            
            while (true)
            {
               
                int q = int.Parse(Console.ReadLine());
                if (q >= 0)
                {
                    product.Quantity = q;
                    break; 
                }
                Console.WriteLine(" Количеството не може да бъде отрицателно. Опитайте пак.");
            }

            
            product.PrintInfo();

            
            Console.ReadKey();
        }
    }
}

   
    

