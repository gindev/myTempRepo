﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Library myLibrary = new Library();
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n МЕНЮ ");
                Console.WriteLine("Добавяне на книга");
                Console.WriteLine(" Показване на всички книги");
                Console.WriteLine(" Търсене на книга по заглавие");
                Console.WriteLine(" Изход");
                Console.Write("Изберете опция: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Заглавие: ");
                        string t = Console.ReadLine();
                        Console.Write("Автор: ");
                        string a = Console.ReadLine();
                        Console.Write("Година: ");
                        int y = int.Parse(Console.ReadLine());
                        myLibrary.AddBook(new Book(t, a, y));
                        break;

                    case "2":
                        myLibrary.ShowAllBooks();
                        break;

                    case "3":
                        
                        string searchTitle = Console.ReadLine();
                        myLibrary.FindBookByTitle(searchTitle);
                        break;

                    case "4":
                        running = false;
                       
                        break;

                    default:
                        Console.WriteLine("Невалидна опция, опитайте пак.");
                        break;
                }
            }
        }
    }
}
        
    

