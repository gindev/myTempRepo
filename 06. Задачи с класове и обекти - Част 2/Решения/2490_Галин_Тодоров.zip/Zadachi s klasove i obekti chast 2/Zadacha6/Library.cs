﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha6
{
    internal class Library
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine("Книгата е добавена успешно!");
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Библиотеката е празна.");
                return;
            }

            Console.WriteLine("\n--- Списък с всички книги ---");
            foreach (var book in books)
            {
                book.PrintBook();
            }
        }

        public void FindBookByTitle(string title)
        {
            bool found = false;
            foreach (var book in books)
            {
               
                if (book.Title.Equals(title, StringComparison.OrdinalIgnoreCase))
                {
                    Console.Write("Намерена: ");
                    book.PrintBook();
                    found = true;
                }
            }

            if (!found) Console.WriteLine("Книга с такова заглавие не e намерена.");
        }
    }

}

