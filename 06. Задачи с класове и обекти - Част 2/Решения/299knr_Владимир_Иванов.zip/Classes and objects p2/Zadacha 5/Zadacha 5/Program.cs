﻿using Zadacha_5;

BankAccount acc1 = new BankAccount("BG11", "Иван Иванов", 500.00m);
BankAccount acc2 = new BankAccount("BG22", "Мария Петрова", 820.00m);
BankAccount acc3 = new BankAccount("BG33", "Георги Димитров", 1200.00m);

Console.Write("Сметка 1: "); acc1.PrintInfo();
Console.Write("Сметка 2: "); acc2.PrintInfo();
Console.Write("Сметка 3: "); acc3.PrintInfo();

Console.WriteLine();
BankAccount.PrintTotalAccounts();