﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal class BankAccount
    {
        public string AccountNumber { get; set; }
        public string Owner { get; set; }
        public decimal Balance { get; set; }
        public static int TotalAccounts { get; private set; } = 0;

        public BankAccount(string accountNumber, string owner, decimal balance)
        {
            AccountNumber = accountNumber;
            Owner = owner;
            Balance = balance;
            TotalAccounts++;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"{AccountNumber} | {Owner} | {Balance:F2}");
        }

        // Статичен метод
        public static void PrintTotalAccounts()
        {
            Console.WriteLine($"Общ брой създадени сметки: {TotalAccounts}");
        }
    }
}
