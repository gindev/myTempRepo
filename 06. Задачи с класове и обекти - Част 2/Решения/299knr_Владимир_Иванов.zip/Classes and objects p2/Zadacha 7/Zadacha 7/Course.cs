﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_7
{
    internal class Course
    {
        public string CourseName { get; set; }
        public int MaxStudents { get; set; }
        private List<Student> EnrolledStudents;

        public Course(string name, int maxStudents)
        {
            CourseName = name;
            MaxStudents = maxStudents;
            EnrolledStudents = new List<Student>();
        }
        public bool HasFreeSeats()
        {
            return EnrolledStudents.Count < MaxStudents;
        }


        public void AddStudent(Student student)
        {
            if (HasFreeSeats())
            {
                EnrolledStudents.Add(student);
                Console.WriteLine($"Студент {student.Name} е записан успешно.");
            }
            else
            {
                Console.WriteLine("Няма свободни места в курса.");
            }
        }

        public void PrintStudents()
        {
            Console.WriteLine($"\nСписък на студентите в курс '{CourseName}':");
            foreach (var student in EnrolledStudents)
            {
                Console.WriteLine($"- {student.Name} (ФН: {student.FN})");
            }
        }
    }
}
