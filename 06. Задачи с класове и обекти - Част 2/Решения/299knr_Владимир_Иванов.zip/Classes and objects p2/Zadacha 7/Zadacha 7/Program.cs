﻿using Zadacha_7;

Course course = new Course("Обектно-ориентирано програмиране", 2);


course.AddStudent(new Student { Name = "Иван Петров", FN = "12345" });
course.AddStudent(new Student { Name = "Мария Георгиева", FN = "12346" });
course.AddStudent(new Student { Name = "Георги Стоянов", FN = "12347" }); 

course.PrintStudents();