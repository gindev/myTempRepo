﻿using Zadacha_3;

Employee emp1 = new Employee();

Employee emp2 = new Employee("Петър Иванов", "Програмист", 2500m);

Console.WriteLine("Служител 1:");
emp1.PrintInfo();

Console.WriteLine("\nСлужител 2:");
emp2.PrintInfo();