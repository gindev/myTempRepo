﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class Student
    {
        public string Name { get; set; }
        public string FN { get; set; }
        public double Grade { get; set; }
    }
}
