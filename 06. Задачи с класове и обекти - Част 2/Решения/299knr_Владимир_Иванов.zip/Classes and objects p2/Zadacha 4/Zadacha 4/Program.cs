﻿using Zadacha_4;

StudentGroup group = new StudentGroup("КН-101");

group.AddStudent(new Student { Name = "Иван Петров", FN = "12345", Grade = 5.50 });
group.AddStudent(new Student { Name = "Мария Георгиева", FN = "12346", Grade = 5.90 });
group.AddStudent(new Student { Name = "Георги Стоянов", FN = "12347", Grade = 4.80 });

group.PrintStudents();

Student best = group.GetBestStudent();
if (best != null)
{
    Console.WriteLine("\nСтудент с най-висок успех:");
    Console.WriteLine($"{best.Name}, ФН: {best.FN}, Успех: {best.Grade:F2}");
}