﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    internal class StudentGroup
    {
        public string GroupName { get; set; }
        public List<Student> Students { get; set; }

        public StudentGroup(string name)
        {
            GroupName = name;
            Students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            Students.Add(student);
        }

        public void PrintStudents()
        {
            Console.WriteLine($"Група: {GroupName}");
            Console.WriteLine("Студенти:");
            for (int i = 0; i < Students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Students[i].Name}, ФН: {Students[i].FN}, Успех: {Students[i].Grade:F2}");
            }
        }

        public Student GetBestStudent()
        {
            if (Students.Count == 0) return null;

            Student best = Students[0];
            foreach (var student in Students)
            {
                if (student.Grade > best.Grade)
                {
                    best = student;
                }
            }
            return best;
        }
    }
}
