﻿using Zadacha_1;

Person person = new Person();

person.FirstName = "Мария";
person.LastName = "Георгиева";
person.Age = 21;
Console.WriteLine($"Име: {person.FirstName}");
Console.WriteLine($"Фамилия: {person.LastName}");
Console.WriteLine($"Възраст: {person.Age}");