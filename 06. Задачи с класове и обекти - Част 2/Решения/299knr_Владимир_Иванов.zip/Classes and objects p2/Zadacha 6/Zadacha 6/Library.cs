﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_6
{
    internal class Library
    {
        private List<Book> books = new List<Book>();
        public void AddBook(Book book)
        {
            books.Add(book);
            Console.WriteLine("Книгата е добавена успешно!");
        }

        public void ShowAllBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Няма налични книги в библиотеката.");
                return;
            }

            Console.WriteLine("Всички книги:");
            foreach (var book in books)
            {
                Console.WriteLine($"- \"{book.Title}\" ({book.Year}) от {book.Author}");
            }
        }

        public void FindBookByTitle(string title)
        {
            bool found = false;
            foreach (var book in books)
            {
                
                if (book.Title.Equals(title, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Намерена: \"{book.Title}\" ({book.Year}) от {book.Author}");
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Не е намерена книга с такова заглавие.");
            }
        }
    }
}
