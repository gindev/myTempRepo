﻿using Zadacha_6;

Library library = new Library();

while (true)
{
    Console.WriteLine("\n1. Добавяне на книга");
    Console.WriteLine("2. Показване на всички книги");
    Console.WriteLine("3. Търсене на книга по заглавие");
    Console.WriteLine("4. Изход");
    Console.Write("Изберете опция: ");

    string choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            Console.Write("Заглавие: ");
            string title = Console.ReadLine();
            Console.Write("Автор: ");
            string author = Console.ReadLine();
            Console.Write("Година: ");
            int year = int.Parse(Console.ReadLine());

            library.AddBook(new Book { Title = title, Author = author, Year = year });
            break;
        case "2":
            library.ShowAllBooks();
            break;
        case "3":
            Console.Write("Въведете заглавие за търсене: ");
            string searchTitle = Console.ReadLine();
            library.FindBookByTitle(searchTitle);
            break;
        case "4":
            return; // Изход от програмата
        default:
            Console.WriteLine("Невалидна опция. Моля, опитайте отново.");
            break;
    }
}