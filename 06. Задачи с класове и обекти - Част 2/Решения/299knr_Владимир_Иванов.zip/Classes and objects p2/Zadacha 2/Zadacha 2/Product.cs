﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Product
    {
        private decimal price;
        private int quantity;

        public string Name { get; set; }

        public decimal Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Грешка: Цената не може да бъде отрицателна. Зададена е стойност 0.");
                    price = 0;
                }
                else { price = value; }
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Грешка: Количеството не може да бъде отрицателно. Зададена е стойност 0.");
                    quantity = 0;
                }
                else { quantity = value; }
            }
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Име на продукт: {Name}");
            Console.WriteLine($"Цена: {Price:F2}");
            Console.WriteLine($"Количество: {Quantity}");
        }
    }
}