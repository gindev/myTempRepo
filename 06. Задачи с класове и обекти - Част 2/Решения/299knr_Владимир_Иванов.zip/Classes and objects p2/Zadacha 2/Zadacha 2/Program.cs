﻿using Zadacha_2;

Product p = new Product();
p.Name = "Лаптоп";
p.Price = 1450.00m;
p.Quantity = 3;


p.PrintInfo();

Console.WriteLine();


Product invalidProduct = new Product();
invalidProduct.Name = "Мишка";
invalidProduct.Price = -50.00m;
invalidProduct.Quantity = -2;  
invalidProduct.PrintInfo();