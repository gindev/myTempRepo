﻿namespace Задачи_от_1_до_4_част2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задача 1
            int[] numbs = new int[10];
            Random random1 = new Random();

            for (int i = 0; i < numbs.Length; i++)
            {
                numbs[i] = random1.Next(1, 101);
            }

            Console.WriteLine("Числата в масива:");
            for (int i = 0; i < numbs.Length; i++)
            {
                Console.WriteLine(numbs[i]);
            }

            //Задача 2
            int[,] matrix = new int[5, 5];
            Random random2 = new Random();

            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 5; col++)
                {
                    matrix[row, col] = random2.Next(1, 101);
                }
            }

            Console.WriteLine("Квадратна матрица от 5x5:");
            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 5; col++)
                {
                    Console.Write(matrix[row, col].ToString().PadLeft(4));
                }
                Console.WriteLine();
            }

            //Задача 3
            List<string> names = new List<string>();

            Console.Write("Въведи имена (по едно на ред, за да спре остави празен ред): ");

            while (true)
            {
                string input1 = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input1))
                    break;

                names.Add(input1);
            }

            names.Sort();

            Console.WriteLine("\nИмената в азбучен ред:");
            foreach (string name in names)
            {
                Console.WriteLine(name);
            }

            //Задача 4
            Console.Write("Въведете двойки от фамилни имена и номера на апартаменти (разделени с интервал, двойките - със запетая) за да спре оставате празен ред: ");
            string input2 = Console.ReadLine();

            string[] pairs = input2.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            Dictionary<string, string> familyApartments = new Dictionary<string, string>();

            foreach (var pair in pairs)
            {

                string[] parts = pair.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 2)
                {
                    string familyName = parts[0];
                    string apartmentNumb = parts[1];
                    familyApartments[familyName] = apartmentNumb;
                }
            }

            Console.WriteLine("Въведете число за проверка:");
            string checkNumber = Console.ReadLine().Trim();

            bool found = false;
            foreach (var kvp in familyApartments)
            {
                if (kvp.Value == checkNumber)
                {
                    Console.WriteLine($"Числото {checkNumber} отговаря на фамилия: {kvp.Key}");
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine($"Числото {checkNumber} не отговаря на нито една фамилия.");
            }
        }
    }
}
