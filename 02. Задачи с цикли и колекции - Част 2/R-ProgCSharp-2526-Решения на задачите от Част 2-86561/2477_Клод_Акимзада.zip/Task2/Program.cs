﻿// Създайте програма, която създава квадратна матрица с размер 5 на 5 и я попълва с произволни числа в диапазона от 1 до 100, след което отпечатайте попълнените в нея числа така, че да се визуализира като квадратна матрица.

int[,] matrix = new int[5, 5];
Random random = new Random();

for (int i = 0; i < matrix.GetLength(0); i++)
{
    for (int j = 0; j < matrix.GetLength(1); j++)
    {
        matrix[i, j] = random.Next(1, 101);
    }
}

for (int i = 0; i < matrix.GetLength(0); i++)
{
    //Console.WriteLine(string.Join("\t", matrix[i, 0], matrix[i, 1], matrix[i, 2], matrix[i, 3], matrix[i, 4]));
    for (int j = 0; j < matrix.GetLength(1); j++)
    {
        Console.Write(matrix[i, j] + "\t");
    }
    Console.WriteLine();
}