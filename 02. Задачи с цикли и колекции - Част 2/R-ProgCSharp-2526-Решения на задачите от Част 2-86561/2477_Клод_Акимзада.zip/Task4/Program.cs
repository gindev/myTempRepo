﻿// Създайте програма, на която от конзолата на един ред се въвеждат неограничен брой двойки от фамилни имена и номера на апартаменти отделени с празно място между тях.
// Съхранявайте ги в подходяща за това колекция. Двойките са отделени една от друга със запетая.
// На конзолата, като втори ред се въвежда и число, което следва да се провери дали отговаря на някое от подадените фамилни имена.
// В случай, че отговаря, отпечатайте фамилното име, а ако не отговаря - отпчатайте подходящо съобщение.
// Smith 101, Johnson 102, Williams 103

Dictionary<int, string> apartmentOwners = new Dictionary<int, string>();


Console.WriteLine($"INSTRUCTIONS:\n\nEnter pairs of last names and apartment numbers.\nThere should be an interval between name and apartment number.\nPairs of name-number should each be seperated by a coma.\n\nExample => Smith 101, Johnson 102, Williams 103");

string input = string.Empty;

while (true)
{
    input = Console.ReadLine();

    if (!string.IsNullOrWhiteSpace(input))
    {
        break;
    }
    Console.WriteLine("Input cannot be null. Please enter valid pairs.");
}



string[] pairs = input.Split(',', StringSplitOptions.RemoveEmptyEntries);

foreach (var pair in pairs)
{
    string[] parts = pair.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length != 2)
    {
        Console.WriteLine($"Invalid pair: '{pair}'. Expected 'LastName ApartmentNumber'.");
        continue;
    }

    string lastName = parts[0].Trim();
    string apartmentNumber = parts[1].Trim();

    if (!int.TryParse(apartmentNumber, out int number))
    {
        Console.WriteLine($"Invalid apartment number: '{apartmentNumber}' in pair '{pair}'. Expected a valid integer.");
        continue;
    }

    apartmentOwners[number] = lastName;
}

if (apartmentOwners.Count > 0)
{
    Console.WriteLine("Which apartment do you need info for? Type EXIT to end program.");

    while (true)
    {
        string? apartmentToCheck = Console.ReadLine()?.Trim();

        if (string.IsNullOrWhiteSpace(apartmentToCheck))
        {
            Console.WriteLine("Input cannot be null. Please enter valid apartment number.");
            continue;
        }

        if (apartmentToCheck.Trim().ToLower() == "exit")
        {
            break;
        }

        if (!int.TryParse(apartmentToCheck, out int apartment))
        {
            Console.WriteLine($"Invalid input. Please enter an integer.");
            continue;
        }

        if (apartmentOwners.ContainsKey(apartment))
        {
            Console.WriteLine($"{apartment} - {apartmentOwners[apartment]}");
        }
        else
        {
            Console.WriteLine($"No owner found for apartment {apartment}.");
        }
    }
}
else
{
    Console.WriteLine("No valid pairs were entered.");
}



