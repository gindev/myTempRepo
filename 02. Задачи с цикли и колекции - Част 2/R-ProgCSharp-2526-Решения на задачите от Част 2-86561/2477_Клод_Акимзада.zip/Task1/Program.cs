﻿// Създайте програма, която попълва масив с 10 произволни цели числа в диапазона от 1 до 100, след което отпечатайте попълнените в масива числа чрез друг цикъл.

Random random = new Random();
//for (int i = 0; i < 10; i++)
//{
//    Console.WriteLine(random.Next(1, 101));
//}

int[] randomNumbers = new int[10];

for (int i = 0; i < 10; i++)
{
    randomNumbers[i] = random.Next(1, 101);
}

foreach (int number in randomNumbers)
{
    Console.Write($"{number} ");
}
Console.WriteLine();