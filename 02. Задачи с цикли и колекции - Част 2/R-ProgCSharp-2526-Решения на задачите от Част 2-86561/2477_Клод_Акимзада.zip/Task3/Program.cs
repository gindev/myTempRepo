﻿// Напишете програма, която приема от конзолата имена на хора, подавани последователно, всяко на отделен ред, запазва ги в List, след което ги отпечатайте по азбучен ред на конзолата.

Console.WriteLine("Enter names one by one in order, each on a new line. The program will sort them alphabetically and print them.");
Console.WriteLine("Type EXIT to end.");

List<string> names = new List<string>();

while (true)
{
    string input = Console.ReadLine();

    if (input?.Trim().ToLower() == "exit")
    {
        break;
    }

    if (string.IsNullOrWhiteSpace(input))
    {
        Console.WriteLine("Input cannot be null. Please enter a valid name.");
        continue;
    }

    bool isValid = input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));

    if (!isValid)
    {
        Console.WriteLine("Invalid input! Only letters");
        continue;
    }

    names.Add(input);
}


if (names.Count > 0)
{
    names.Sort();
    Console.WriteLine(string.Join(", ", names));
}
else
{
    Console.WriteLine("No names were entered.");
}