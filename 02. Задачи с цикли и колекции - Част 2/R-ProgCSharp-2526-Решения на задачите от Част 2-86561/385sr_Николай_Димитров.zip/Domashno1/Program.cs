﻿// 1. Създайте програма, която попълва масив с 10 произволни цели числа в диапазона от 1 до 100,
// след което отпечатайте попълнените в масива числа чрез друг цикъл.

//int[] numbers = new int[10];
//Random rand = new Random();

//for (int i = 0; i < numbers.Length; i++)
//{
//    numbers[i] = rand.Next(1, 101);
//}

//Console.WriteLine("10-те различни числа са:");

//for  (int i = 0;i < numbers.Length; i++)
//{
//    Console.WriteLine(numbers[i]);
//}

// 2. Създайте програма, която създава квадратна матрица с размер 5 на 5 и я попълва с произволни числа в диапазона от 1 до 100,
// след което отпечатайте попълнените в нея числа така, че да се визуализира като квадратна матрица.

//int[,] matrix = new int[5, 5];
//Random random = new Random();

//for (int i = 0; i < 5; i++)
//{
//    for (int j = 0; j < 5; j++)
//    {
//        matrix[i, j] = random.Next(1, 101);
//    }
//}
//for (int i = 0; i < 5; i++)
//{
//    for (int j = 0; j < 5; j++)
//    {
//        Console.Write(matrix[i, j] + "\t");
//    }
//    Console.WriteLine();
//}

// 3. Напишете програма, която приема от конзолата имена на хора, подавани последователно, всяко на отделен ред,
// запазва ги в List, след което ги отпечатайте по азбучен ред на конзолата.

//List<string> names = new List<string>();

//Console.WriteLine("Въведете имена. Натиснете Enter на празен ред, като сте готови!");

//while (true)
//{
//    string input = Console.ReadLine();

//    if (string.IsNullOrWhiteSpace(input))
//    {
//        break;
//    }

//    names.Add(input);
//}

//names.Sort();

//Console.WriteLine("\nИмена по азбучен ред:");

//foreach (string name in names)
//{
//    Console.WriteLine(name);
//}

// 4. Създайте програма, на която от конзолата на един ред се въвеждат неограничен брой двойки от фамилни имена и номера на апартаменти отделени с празно място
// между тях. Съхранявайте ги в подходяща за това колекция. Двойките са отделени една от друга със запетая. На конзолата, като втори ред се въвежда и число,
// което следва да се провери дали отговаря на някое от подадените фамилни имена. В случай, че отговаря, отпечатайте фамилното име,
// а ако не отговаря - отпчатайте подходящо съобщение.


//Dictionary<int, string> apartments = new Dictionary<int, string>();

//Console.WriteLine("Добавете имена и номера на апартаменти:");
//string input = Console.ReadLine();
//Console.WriteLine("Изберете номер на апартамент:");
//string[] pairs = input.Split(',');


//foreach (string pair in pairs)
//{
//    string[] data = pair.Trim().Split(' ');
//    string name = data[0];
//    int number = int.Parse(data[1]);

//    apartments[number] = name;
//}

//int searchNumber = int.Parse(Console.ReadLine());

//if (apartments.ContainsKey(searchNumber))
//{
//    Console.WriteLine(apartments[searchNumber]);
//}
//else
//{
//    Console.WriteLine("Няма такъв апартамент.");
//}