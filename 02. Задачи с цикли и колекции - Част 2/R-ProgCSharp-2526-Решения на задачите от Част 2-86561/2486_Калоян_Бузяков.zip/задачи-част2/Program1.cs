﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[,] matrix = new int[5, 5];




            for (int i = 0; i < 5; i++)
            {

                for (int j = 0; j < 5; j++)
                {

                    matrix[i, j] = rand.Next(1, 101);

                }

            }


            for (int i = 0; i < 5; i++)
            {

                for (int j = 0; j < 5; j++)
                {

                    Console.Write(matrix[i, j] + " ");

                }

                Console.WriteLine();
            }

        }
    }
}