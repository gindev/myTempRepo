﻿//1.
//Random rand = new Random();
//int[] numbers = new int[10];
//for (int i = 0; i < numbers.Length; i++)
//{
//   numbers[i] = rand.Next(1, 101);
//}
//Console.WriteLine("");
//for (int i = 0; i < numbers.Length; i++)
//{
//   Console.WriteLine(numbers[i] + " ");
//}
//2.
//Random rand = new Random();
//int[,] matrix = new int[5, 5];
//for (int i = 0; i < 5; i++)
//{
//    for (int j = 0; j < 5; j++)
//    {
//        matrix[i, j] = rand.Next(1, 101);
//    }
//}
//for (int i = 0; i < 5; i++)
//{
//    for (int j = 0; j < 5; j++)
//    {
//        Console.Write($"{matrix[i, j],4}");
//    }
//    Console.WriteLine();
//}
//3.
//List<string> names = new List<string>();
//Console.WriteLine("Въвеждай имена(stop за край)");
//while (true)
//{
//    string input = Console.ReadLine();
//    if (input.ToLower() == "stop")
//    {
//        break;
//    }
//    names.Add(input);
//}
//names.Sort();
//Console.WriteLine("Имена по азбучен ред");
//foreach (string name in names)
//{
//    Console.WriteLine(name);
//}
////4.
//Dictionary<string, int> apartments = new Dictionary<string, int>();
//Console.WriteLine("Въведете фамилии и апартаменти (пример: Иванови 12, Петрови 31)");
//string input  = Console.ReadLine();
//string[] pairs = input.Split(',');
//foreach (string pair in pairs)
//{
//    string[] parts = pair.Trim().Split(' ');
//    string name = parts[0];
//    int number = int.Parse(parts[1]);
//    apartments[name] = number;
//}
//Console.WriteLine("Въведи номер на апартамента");
//int search = int.Parse(Console.ReadLine());
//bool found =  false;
//foreach (var item in apartments)
//{
//    if(item.Value == search)
//    {
//        Console.WriteLine("Фамилия: " + item.Key);
//        found = true;
//    }
//}
//if (!found)
//{
//    Console.WriteLine("Няма такъв апартамент.");
//}