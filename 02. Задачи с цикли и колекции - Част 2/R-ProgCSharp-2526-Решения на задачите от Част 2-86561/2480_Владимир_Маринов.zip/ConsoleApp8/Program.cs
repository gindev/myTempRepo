﻿//1
//Random rnd = new Random();
//int[] numbers = new int[10];
//for (int i = 0; i < 10; i++)
//{
//    numbers[i] = rnd.Next(1, 101);
//}
//foreach (int num  in numbers)
//{
//    Console.WriteLine(num + "");
//}
//2
//Random rnd = new Random();
//int[,] matrix = new int[5,5];
//for (int row  = 0; row < 5; row++)
//{
//    for(int col = 0; col < 5; col++)
//    {
//        matrix[row,col] = rnd.Next(1,101);
//        Console.Write(matrix[row,col] + " \t");
//    }
//    Console.WriteLine();
//}
//3
//using System;
//class Program
//{
//    static void Main()
//    {
//        Console.Write("Колко имена ще въвеждате? ");
//        int n = int.Parse(Console.ReadLine());
//        string[] names = new string[n];
//        for(int i = 0; i < n; i++)
//        {
//            Console.Write($"Въведете име{i + 1}: ");
//            names[i] = Console.ReadLine();
//        }
//        Array.Sort( names );
//        Console.WriteLine("\nИмена по азбучен ред:");
//        foreach(string name in names )
//        {
//            Console.WriteLine(name);
//        }
//    }
//}
//4
//using System;
//Console.Write("Колко апартамента ще въвеждате? ");
//int n = int.Parse(Console.ReadLine());
//string[]families = new string[n];
//string[]numbers = new string[n];

//for (int i = 0; i < n; i++)
//{
//    Console.Write($"Фамилия{i + 1} ");
//    families[i] = Console.ReadLine();
//    Console.WriteLine($"Номер на апартамента {i + 1} ");
//    numbers[i] = Console.ReadLine();
//}
//Console.Write("\nВъведи номер на търсене: ");
//string search = Console.ReadLine();
//bool found = false;
//for(int i = 0; i < n; i++)
//{
//    if (numbers[i] == search)
//    {
//        Console.WriteLine("Фамилия: " + families[i]);
//        found = true;
//    }
//}
//if (!found) Console.WriteLine("Няма такъв апартамент.");