﻿namespace ConsoleApp2;

using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Zadacha 1:");
        int[] numbers = new int[10];
        Random rand = new Random();
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = rand.Next(0, 101);
        }

        for (int i = 0; i < numbers.Length; i++)
        {
            Console.WriteLine(numbers[i]);

        }

        Console.WriteLine("\n");
        Console.WriteLine("Zadacha 2:");
        int[,] matrix = new int[5, 5];
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                matrix[i, j] = rand.Next(1, 101);
            }

        }

        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }

            Console.WriteLine();
        }

        Console.WriteLine("Zadacha 3:");
        Console.WriteLine("Vuvezhdaite imena (prazno pole za krai):");

        List<string> names = new List<string>();

        while (true)
        {
            string name = Console.ReadLine();

            if (string.IsNullOrEmpty(name))
                break;

            names.Add(name);
        }

        names.Sort();

        Console.WriteLine("Po azbuchen red:");
        foreach (string n in names)
        {
            Console.WriteLine(n);
        }

        Console.WriteLine();
        Console.WriteLine("Zadacha 4:");
        Console.WriteLine("Vuvedi: familnoIme nomer, familnoIme nomer ...");

        string input = Console.ReadLine();
        Dictionary<string, int> apartments = new Dictionary<string, int>();

        try
        {
            string[] pairs = input.Split(',');

            foreach (string pair in pairs)
            {
                try
                {
                    string[] data = pair.Trim().Split(' ');

                    if (data.Length < 2)
                    {
                        Console.WriteLine("Greshen format: " + pair);
                        continue;
                    }

                    string surname = data[0];
                    int number = int.Parse(data[1]);

                    apartments[surname] = number;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Nomerut ne e validen: " + pair);
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Nomerut e tvurde golqm: " + pair);
                }
            }

            Console.WriteLine("Vuvedi nomer na apartament:");

            int search = int.Parse(Console.ReadLine());

            bool found = false;

            foreach (var item in apartments)
            {
                if (item.Value == search)
                {
                    Console.WriteLine(item.Key);
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Nqma takuv apartament.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Vuznikna greshka: " + ex.Message);
        }
    }
}