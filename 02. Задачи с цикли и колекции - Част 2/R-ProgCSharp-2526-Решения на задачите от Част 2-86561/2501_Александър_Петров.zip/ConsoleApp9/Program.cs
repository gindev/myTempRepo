﻿namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string>();
            string input;

            Console.WriteLine("Vavedete imena:");

            while (true)
            {
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    break;
                }
                names.Add(input);
            }

            names.Sort();

            Console.WriteLine("\nImena sortirani po azbushen red:");
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
        }
    }
}
