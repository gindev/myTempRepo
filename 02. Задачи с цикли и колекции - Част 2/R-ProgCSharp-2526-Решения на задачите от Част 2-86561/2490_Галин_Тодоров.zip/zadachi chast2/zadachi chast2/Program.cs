﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace zadachi_chast2
{
    internal class Zadachi
    {


    }

    class Zadacha1
    {
        public static void Run()
        {
            //Създайте програма, която попълва масив с 10 произволни цели числа в диапазона от 1 до 100, след което отпечатайте попълнените в масива числа чрез друг цикъл.
            int[] chisla = new int[10];
            Random rnd = new Random();

            for (int i = 0; i < chisla.Length; i++)
                chisla[i] = rnd.Next(1, 101);

            Console.WriteLine("Masiv");
            for (int i = 0; i < chisla.Length; i++)
                Console.Write(chisla[i] + " ");

            Console.WriteLine("\n");
        }
    }

    class Zadacha2
    {
        public static void Run()
        {
            //Създайте програма, която създава квадратна матрица с размер 5 на 5 и я попълва с произволни числа в диапазона от 1 до 100, след което отпечатайте попълнените в нея числа така, че да се визуализира като квадратна матрица.
            int[,] matrix = new int[5, 5];
            Random rnd = new Random();

            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 5; col++)
                {
                    matrix[row, col] = rnd.Next(1, 101);
                }
            }

            Console.WriteLine("Matrica 5x5:");

            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 5; col++)
                {
                    Console.Write(matrix[row, col] + "\t");
                }
                Console.WriteLine();
            }
        }
    }

    class Zadacha3
    {
        public static void Run()

        //Напишете програма, която приема от конзолата имена на хора, подавани последователно, всяко на отделен ред, запазва ги в List, след което ги отпечатайте по азбучен ред на конзолата.
        {
            List<string> names = new List<string>();

            for (int i = 1; i <= 5; i++)
            {
                Console.Write($"Vuvedete 5 imena na hora {i}: ");
                names.Add(Console.ReadLine());
            }

            names.Sort();

            Console.WriteLine("\nImenata po azbuchen red:");
            foreach (string name in names)
            {
                Console.WriteLine("- " + name);
            }
        }
    }

    class Program
    {
        static void Main()
        {
           Zadacha1.Run();
           Zadacha2.Run();
            Zadacha3.Run();
        }
    }
}
