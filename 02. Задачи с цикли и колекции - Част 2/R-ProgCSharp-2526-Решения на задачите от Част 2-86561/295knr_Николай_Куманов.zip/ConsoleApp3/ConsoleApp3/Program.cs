﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            Console.WriteLine("Write names on new lanes. When you are ready write \"END\" ");

            string line = Console.ReadLine();

            while (line != "END")
            {
                list.Add(line);
                line = Console.ReadLine();
            }

            list.Sort();
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
        }
    }
}
