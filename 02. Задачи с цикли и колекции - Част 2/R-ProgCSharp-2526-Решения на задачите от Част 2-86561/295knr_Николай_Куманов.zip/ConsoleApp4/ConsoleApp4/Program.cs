﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, string> apartments = new Dictionary<int, string>();

            List<string> lines = Console.ReadLine().Split(',').ToList();

            foreach (string line in lines)
            {
                apartments.Add(int.Parse(line.Split(' ')[1]), line.Split(' ')[0]);
            }

            int apartmentNumber = int.Parse(Console.ReadLine());

            if (apartments.ContainsKey(apartmentNumber)){
                Console.WriteLine(apartments[apartmentNumber]);
            }
            else
            {
                Console.WriteLine("There isnt such a room number");
            }
        }
    }
}
