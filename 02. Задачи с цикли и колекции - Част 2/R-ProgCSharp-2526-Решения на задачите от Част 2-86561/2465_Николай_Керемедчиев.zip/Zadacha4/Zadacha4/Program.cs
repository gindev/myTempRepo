﻿namespace Zadacha4
{
    using System;
    using System.Collections.Generic;

    class Program
    {
        static void Main()
        {
            Dictionary<string, int> people = new Dictionary<string, int>();

            // първи ред - двойки фамилия и апартамент
            string input = Console.ReadLine();

            string[] pairs = input.Split(',');

            foreach (string pair in pairs)
            {
                string[] data = pair.Trim().Split(' ');
                string surname = data[0];
                int apartment = int.Parse(data[1]);

                people[surname] = apartment;
            }

            // втори ред - номер за проверка
            int number = int.Parse(Console.ReadLine());

            bool found = false;

            foreach (var p in people)
            {
                if (p.Value == number)
                {
                    Console.WriteLine(p.Key);
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Няма такова фамилно име.");
            }
        }
    }
}