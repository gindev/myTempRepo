﻿namespace Zadacha3
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            List<string> names = new List<string>();
            string name;

            Console.WriteLine("Въвеждайте имена. За край напишете stop.");

            name = Console.ReadLine();

            while (name != "stop")
            {
                names.Add(name);
                name = Console.ReadLine();
            }

            names.Sort();

            Console.WriteLine("Имена по азбучен ред:");

            foreach (string n in names)
            {
                Console.WriteLine(n);
            }
        }
    }
}
