﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 2; i <= n; i++)
            {
                IsSimple(i);
            }
        }

        private static void IsSimple(int n)
        {
            for (int i = 2; i < n; i++)
            {
                if (n % i == 0)
                {
                    Console.WriteLine($"{n} is not simple");
                    return;
                }
            }

            Console.WriteLine($"{n} is simple");

        }

    }

}
