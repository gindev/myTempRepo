﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            int[] numbers = ParseInput(input);

            BubbleSort(numbers);

            PrintArray(numbers);
        }

        static int[] ParseInput(string input)
        {
            return input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(int.Parse)
                        .ToArray();
        }

        static void Swap(int[] array, int index1, int index2)
        {
            int temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

        static void BubbleSort(int[] array)
        {
            int n = array.Length;
            bool isSwapped;

            for (int i = 0; i < n - 1; i++)
            {
                isSwapped = false;

                for (int j = 0; j < n - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        Swap(array, j, j + 1);
                        isSwapped = true;
                    }
                }

                if (!isSwapped)
                {
                    break;
                }
            }
        }

        static void PrintArray(int[] array)
        {
            Console.WriteLine(string.Join(" ", array));
        }
    }

}

