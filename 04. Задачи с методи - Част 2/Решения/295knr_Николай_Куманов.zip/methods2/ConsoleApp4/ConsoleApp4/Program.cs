﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            int nod = NOD(a, b);
            int nok = NOK(a, b, nod);

            Console.WriteLine(nod);
            Console.WriteLine(nok);
        }

        public static int NOD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % temp;
                a = temp;
            }
            return a;
        }

        public static int NOK(int a, int b, int nod)
        {
            if (a == 0 || b == 0) return 0;
            return a * b / nod;
        }


    }
}
