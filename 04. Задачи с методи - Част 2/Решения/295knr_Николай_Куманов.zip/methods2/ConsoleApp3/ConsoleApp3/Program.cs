﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            SumOfNumbers(n);
            Console.WriteLine( IsPallindrome(n));
        }

        private static bool IsPallindrome(int n)
        {

            int original = n;
            int reversed = 0;

            while (n > 0)
            {
                int lastN = n % 10;
                reversed = (reversed * 10) + lastN;
                n /= 10;
            }

            return original == reversed;
        }

        private static void SumOfNumbers(int n)
        {
            int sum = 0;

            while (n > 0)
            {
                sum += n % 10;
                n /= 10;
            }
            Console.WriteLine(sum);
        }
    }
}
