﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int[] numbers = Console.ReadLine().Split(' ')
                                 .Select(int.Parse)
                                 .ToArray();

            int evenCount = 0;
            int oddCount = 0;
            int primeCount = 0;
            int palindromeCount = 0;

            foreach (int num in numbers)
            {
                if (num % 2 == 0)
                {
                    evenCount++;
                }
                else
                {
                    oddCount++;
                }

                if (IsSimple(num))
                {
                    primeCount++;
                }

                if (IsPallindrome(num))
                {
                    palindromeCount++;
                }
            }

            Console.WriteLine($"Четни: {evenCount}");
            Console.WriteLine($"Нечетни: {oddCount}");
            Console.WriteLine($"Прости: {primeCount}");
            Console.WriteLine($"Палиндроми: {palindromeCount}");
        }


        static bool IsSimple(int n)
        {
            for (int i = 2; i < n; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;

        }

        private static bool IsPallindrome(int n)
        {

            int original = n;
            int reversed = 0;

            while (n > 0)
            {
                int lastN = n % 10;
                reversed = (reversed * 10) + lastN;
                n /= 10;
            }

            return original == reversed;
        }
    }
}
