﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            int[] numbers = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                                    .Select(int.Parse)
                                    .ToArray();

            int min = GetMin(numbers);
            int max = GetMax(numbers);
            int sum = GetSum(numbers);
            double average = GetAverage(numbers);

            Console.WriteLine($"Най-малък елемент: {min}");
            Console.WriteLine($"Най-голям елемент: {max}");
            Console.WriteLine($"Сума: {sum}");
            Console.WriteLine("Средна стойност: {0}", average.ToString("F2"));
        }

        static int GetMin(int[] array)
        {
            int min = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < min)
                {
                    min = array[i];
                }
            }
            return min;
        }

        static int GetMax(int[] array)
        {
            int max = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > max)
                {
                    max = array[i];
                }
            }
            return max;
        }

        static int GetSum(int[] array)
        {
            int sum = 0;
            foreach (int num in array)
            {
                sum += num;
            }
            return sum;
        }

        static double GetAverage(int[] array)
        {
            if (array.Length == 0) return 0;
            return (double)GetSum(array) / array.Length;
        }

    }

}
