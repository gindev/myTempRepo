﻿namespace Zadacha_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете цели числа (разделени с интервал или запетая): ");
            string input = Console.ReadLine();
            int[] numbers = ParseInput(input);

            int even = 0, odd = 0, prime = 0, palindrome = 0;

            foreach (int n in numbers)
            {
                if (n % 2 == 0) even++;
                else odd++;
                if (IsPrime(n)) prime++;
                if (IsPalindrome(n)) palindrome++;
            }

            Console.WriteLine($"Четни числа: {even}");
            Console.WriteLine($"Нечетни числа: {odd}");
            Console.WriteLine($"Прости числа: {prime}");
            Console.WriteLine($"Палиндроми: {palindrome}");

            static bool IsPrime(int number)
            {
                if (number <= 1) return false;
                if (number == 2) return true;
                if (number % 2 == 0) return false;
                for (int i = 3; i <= Math.Sqrt(number); i += 2)
                    if (number % i == 0) return false;
                return true;
            }

            static bool IsPalindrome(int number)
            {
                string str = Math.Abs(number).ToString();
                int left = 0, right = str.Length - 1;
                while (left < right)
                {
                    if (str[left] != str[right]) return false;
                    left++;
                    right--;
                }
                return true;
            }

            static int[] ParseInput(string input)
            {
                return input
                    .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse)
                    .ToArray();
            }
        }
    }
}
