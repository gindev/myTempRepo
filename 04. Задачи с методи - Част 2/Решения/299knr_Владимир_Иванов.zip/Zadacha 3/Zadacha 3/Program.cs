﻿namespace Zadacha_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете цяло число: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine($"Сума на цифрите: {SumOfDigits(n)}");
            if (IsPalindrome(n))
            {
                Console.WriteLine($"{n} е палиндром");
            }
            else
            {
                Console.WriteLine($"{n} не е палиндром");
            }

            static int SumOfDigits(int number)
            {
                number = Math.Abs(number);
                int sum = 0;
                while (number > 0)
                {
                    sum += number % 10;
                    number /= 10;
                }
                return sum;
            }

            static bool IsPalindrome(int number)
            {
                string str = Math.Abs(number).ToString();
                int left = 0, right = str.Length - 1;
                while (left < right)
                {
                    if (str[left] != str[right]) return false;
                    left++;
                    right--;
                }
                return true;
            }
        }
    }
}
