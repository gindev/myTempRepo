﻿namespace Zadacha_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете първото число: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Въведете второто число: ");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine($"НОД({a}, {b}) = {NOD(a, b)}");
            Console.WriteLine($"НОК({a}, {b}) = {NOK(a, b)}");

            static int NOD(int a, int b)
            {
                a = Math.Abs(a);
                b = Math.Abs(b);
                while (b != 0)
                {
                    int temp = b;
                    b = a % b;
                    a = temp;
                }
                return a;
            }

            static long NOK(int a, int b)
            {
                return (long)Math.Abs(a) / NOD(a, b) * Math.Abs(b);
            }
        }
    }
}
