﻿namespace Zadacha_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете числа (разделени с интервал или запетая): ");
            string input = Console.ReadLine();
            int[] numbers = ParseInput(input);

            SelectionSort(numbers);

            Console.Write("Сортиран масив: ");
            PrintArray(numbers);

            static int[] ParseInput(string input)
            {
                return input
                    .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse)
                    .ToArray();
            }

            static void SelectionSort(int[] arr)
            {
                int n = arr.Length;
                for (int i = 0; i < n - 1; i++)
                {
                    int minIndex = i;
                    for (int j = i + 1; j < n; j++)
                    {
                        if (arr[j] < arr[minIndex])
                            minIndex = j;
                    }

                    // Размяна
                    int temp = arr[minIndex];
                    arr[minIndex] = arr[i];
                    arr[i] = temp;
                }
            }

            static void PrintArray(int[] arr)
            {
                Console.WriteLine(string.Join(" ", arr));
            }
        }
    }
}
