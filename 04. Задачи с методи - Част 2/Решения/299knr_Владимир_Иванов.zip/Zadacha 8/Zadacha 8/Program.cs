﻿namespace Zadacha_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете числа (разделени с интервал или запетая): ");
            string input = Console.ReadLine();
            int[] numbers = ParseInput(input);

            BubbleSort(numbers);

            Console.Write("Сортиран масив (Bubble Sort): ");
            PrintArray(numbers);

            static int[] ParseInput(string input)
            {
                return input
                    .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse)
                    .ToArray();
            }

            static void Swap(int[] arr, int i, int j)
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }

            static void BubbleSort(int[] arr)
            {
                int n = arr.Length;
                for (int i = 0; i < n - 1; i++)
                {
                    bool swapped = false;
                    for (int j = 0; j < n - 1 - i; j++)
                    {
                        if (arr[j] > arr[j + 1])
                        {
                            Swap(arr, j, j + 1);
                            swapped = true;
                        }
                    }
                    if (!swapped) break;
                }
            }

            static void PrintArray(int[] arr)
            {
                Console.WriteLine(string.Join(" ", arr));
            }
        }
    }
}
