﻿namespace Zadacha_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете цяло число: ");
            int n = int.Parse(Console.ReadLine());

            if (IsPrime(n))
                Console.WriteLine($"{n} е просто число.");
            else
                Console.WriteLine($"{n} НЕ е просто число.");

            static bool IsPrime(int number)
            {
                if (number <= 1) return false;
                if (number == 2) return true;
                if (number % 2 == 0) return false;

                for (int i = 3; i <= Math.Sqrt(number); i += 2)
                {
                    if (number % i == 0) return false;
                }
                return true;
            }
        }
    }
}
