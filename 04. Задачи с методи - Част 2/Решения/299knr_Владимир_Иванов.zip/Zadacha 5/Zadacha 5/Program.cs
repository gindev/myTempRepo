﻿namespace Zadacha_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете числа (разделени с интервал или запетая): ");
            string input = Console.ReadLine();
            double[] numbers = ParseInput(input);

            Console.WriteLine($"Минимален елемент: {FindMin(numbers)}");
            Console.WriteLine($"Максимален елемент: {FindMax(numbers)}");
            Console.WriteLine($"Сума: {Sum(numbers)}");
            Console.WriteLine($"Средна стойност: {Average(numbers):F2}");

            static double[] ParseInput(string input)
            {
                return input
                    .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(double.Parse)
                    .ToArray();
            }

            static double FindMin(double[] arr)
            {
                double min = arr[0];
                foreach (double x in arr)
                    if (x < min) min = x;
                return min;
            }

            static double FindMax(double[] arr)
            {
                double max = arr[0];
                foreach (double x in arr)
                    if (x > max) max = x;
                return max;
            }

            static double Sum(double[] arr)
            {
                double sum = 0;
                foreach (double x in arr) sum += x;
                return sum;
            }

            static double Average(double[] arr)
            {
                return Sum(arr) / arr.Length;
            }
        }
    }
}
