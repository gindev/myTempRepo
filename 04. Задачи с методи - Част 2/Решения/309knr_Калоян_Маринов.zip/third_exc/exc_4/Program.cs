﻿namespace Program
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Insert two numbers for checking");
            int n1 = int.Parse(Console.ReadLine());
            int n2 = int.Parse(Console.ReadLine());
            Console.WriteLine($"The NOD is {FindNOD(n1, n2)}");
            Console.WriteLine($"The NOK is {FindNOK(n1, n2)}");
        }
        static int FindNOD(int a, int b)
        {
           if(b == 0)
            {
                return a;
            }
            else
            {
                return FindNOD(b, a % b);
            }
        }

        static int FindNOK(int a, int b)
        {
            return (a * b) / FindNOD(a, b);
        }
    }
}