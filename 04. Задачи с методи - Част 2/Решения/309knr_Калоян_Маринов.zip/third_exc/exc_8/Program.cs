﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number with comma between them");
            string nums = Console.ReadLine();   
            int[] mas = ParseMas(nums);
            mas = BubbleSort(mas);

            Console.WriteLine($"Bubble sort {string.Join(", ", BubbleSort(mas))}");

        }

        static int[] ParseMas(string numbers)
        {
            string[] nums = numbers.Split(", ");
            int[] mas = new int[nums.Length];
            for(int i = 0; i < nums.Length; i++)
            {
                mas[i] = int.Parse(nums[i]);
            }
            return mas;
        }

        static int[] BubbleSort(int[] mas)
        {
            for(int i = 0; i < mas.Length -1; i ++)
            {
                for(int j = 0; j < mas.Length -1; j ++)
                {
                    if(mas[j] > mas[j+1])
                    {
                        mas = SwapItems(mas, j);
                    }
                }
  
            }
            return mas;
        }

        static int[] SwapItems(int[] mas, int index)
        {
            int temp = mas[index];
            mas[index] = mas[index+1];
            mas[index+1] = temp;

            return mas;
        }
    }
}