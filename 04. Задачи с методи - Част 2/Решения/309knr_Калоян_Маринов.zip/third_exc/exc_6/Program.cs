﻿namespace Prorgam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] mas = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int evenCounter = 0;
            int oddCounter = 0;
            int simpleCounter = 0;
            int palindromCounter = 0;

            foreach(int n in mas)
            {
                if(CheckEven(n))
                {
                    evenCounter += 1;
                }

                if(CheckOdd(n))
                {
                    oddCounter += 1;
                }

                if(CheckNum(n))
                {
                    simpleCounter += 1;
                }

                if(IsPalindorom(n))
                {
                    palindromCounter += 1;
                }
            }
            Console.WriteLine($"Even numbers: {evenCounter}");
            Console.WriteLine($"Odd numbers: {oddCounter}");
            Console.WriteLine($"Simple numbers: {simpleCounter}");
            Console.WriteLine($"Palindrom numbers: {palindromCounter}");
        }

        static bool CheckEven(int num)
        {
            bool flag = true;
            if (num % 2 != 0)
            {
                flag = false;
            }
            return flag;
        }

        static bool CheckOdd(int num)
        {
            bool flag = true;
            if (num % 2 == 0)
            {
                flag = false;
            }
            return flag;
        }

        static bool CheckNum(int num)
        {
            bool flag = true;
            for(int i = 1; i < num; i++)
            {
                if (i != 1)
                {
                    if (num % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
            }
            return flag;
        }   

        static bool IsPalindorom(int n)
        {
            string num = n.ToString();
            bool flag = true;
            for(int i = 0; i < num.Length / 2; i ++)
            {
                if(num[i] != num[num.Length - i - 1])
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }
    }
}