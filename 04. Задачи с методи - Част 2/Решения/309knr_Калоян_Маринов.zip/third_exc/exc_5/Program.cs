﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] mas = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            Console.WriteLine($"The min is {MinNum(mas)}");
            Console.WriteLine($"The max is {MaxNum(mas)}");
            Console.WriteLine($"The total sum is {TotalSum(mas)}");
            Console.WriteLine($"The average is {Average(mas)}");
        }

        static int MinNum(int[] mas)
        {
            int min = mas[0];
            foreach(int n in mas)
            {
                if(n < min)
                {
                    min = n;
                }
            }
            return min;
        }
        static int MaxNum(int[] mas)
        {
            int max = mas[0];
            foreach(int n in mas)
            {
                if(n > max)
                {
                    max = n;
                }
            }
            return max;
        }
        static int TotalSum(int[] mas)
        {
            int sum = 0;
            foreach(int n in mas)
            {
                sum += n;
            }
            return sum;
        }

        static double Average(int[] mas)
        {
            int sum = TotalSum(mas);
            
            return sum / (double)mas.Length;
        }

    }
}