﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] mas = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            Console.WriteLine($"Insertion sort {string.Join(", ", InsertionSort(mas))}");
            Console.WriteLine($"Selection sort {string.Join(", ", SelectionSort(mas))}");
            Console.WriteLine($"Bubble sort {string.Join(", ", BubbleSort(mas))}");
        }

        static int[] InsertionSort(int[] mas)
        {
            for(int i = 0; i < mas.Length -1; i++)
            {
                for(int j = i; j >= 0; j--)
                {
                    if (mas[j] > mas[j+1])
                    {
                        int temp = mas[j];
                        mas[j] = mas[j+1];
                        mas[j+1] = temp;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            return mas;
        }

        static int[] SelectionSort(int[] mas)
        {
            for(int i = 0; i < mas.Length -1; i++)
            {
                int min = i;
                for(int j = i + 1; j < mas.Length -1; j++)
                {
                    if(mas[j] < mas[min])
                    {
                        min = j;
                    }
                }
                int temp = mas[min];
                mas[min] = mas[i];
                mas[i] = temp;
            }
            return mas;
        }

        static int[] BubbleSort(int[] mas)
        {
            for(int i = 0; i < mas.Length -1; i ++)
            {
                for(int j = 0; j < mas.Length -1; j ++)
                {
                    if(mas[j] > mas[j+1])
                    {
                        int temp = mas[j];
                        mas[j] = mas[j+1];
                        mas[j+1] = temp;
                    }
                }
  
            }
            return mas;
        }
    }
}