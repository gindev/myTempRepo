﻿namespace Program
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Insert the number for checking");
            string n = Console.ReadLine();
            IsPalindorom(n);
            SumNums(n);
        }



        static void IsPalindorom(string num)
        {
            bool flag = true;
            for(int i = 0; i < num.Length / 2; i ++)
            {
                if(num[i] != num[num.Length - i - 1])
                {
                    Console.WriteLine("The num is not Palindrom");
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                Console.WriteLine("The num is Palindrom");
            }
        }

        static void SumNums(string num)
        {
            int totalSum = 0;
            foreach(char n in num)
            {
                totalSum += int.Parse(n.ToString());
            }

            Console.WriteLine($"The sum of the nums {num} is {totalSum}");
        }
    }
}