﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert the number for checking");
            int n = int.Parse(Console.ReadLine());
            CheckNums(n);
        }

        static void CheckNums(int num)
        {
            List<int> simpleNums = new List<int>();

            for(int i = 2; i <= num; i++)
            {
                if (CheckNum(i))
                {
                    simpleNums.Add(i);
                }
            }
            Console.WriteLine(string.Join(", ", simpleNums));
        }

        static bool CheckNum(int num)
        {
            bool flag = true;
            for(int i = 1; i < num; i++)
            {
                if (i != 1)
                {
                    if (num % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
            }
            return flag;
        }            
    }
}