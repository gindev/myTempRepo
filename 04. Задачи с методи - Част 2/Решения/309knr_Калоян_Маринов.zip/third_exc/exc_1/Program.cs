﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert the number for checking");
            int n = int.Parse(Console.ReadLine());
            CheckNum(n);
        }


        static void CheckNum(int num)
        {
            bool flag = true;
            for(int i = 1; i < num; i++)
            {
                if (i != 1)
                {
                    if (num % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
            }

            if (flag)
            {
                Console.WriteLine($"The {num} is simple");
            }
            else
            {
                Console.WriteLine($"The {num} is not simple");
            }
        }
    }
}