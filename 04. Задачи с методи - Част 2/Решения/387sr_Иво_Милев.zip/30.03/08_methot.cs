﻿using System;

class Program8
{
	static void Main()
	{
		static void Main()
		{
			int[] numbers = parseInput();

			bubbleSort(numbers);

			printArray(numbers);
		}

		static int[] parseInput()
		{
			return Console.ReadLine()
				.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
				.Select(int.Parse)
				.ToArray();
		}

		static void Swap(int[] arr, int i, int j)
		{
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}

		static void bubbleSort(int[] arr)
		{
			for (int i = 0; i < arr.Length - 1; i++)
			{
				bool swapped = false;

				for (int j = 0; j < arr.Length - 1 - i; j++)
				{
					if (arr[j] > arr[j + 1])
					{
						Swap(arr, j, j + 1);
						swapped = true;
					}
				}
				if (!swapped)
				{
					break;
				}
			}
		}
		static void printArray(int[] arr)
		{
			foreach (int num in arr)
			{
				Console.Write(num + " ");
			}
		}
	}
}
