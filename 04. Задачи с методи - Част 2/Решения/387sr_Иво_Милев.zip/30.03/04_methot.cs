﻿//using System;

//class Program4
//{
//static void Main()
//{
//		Console.Write("Въведи първото число: ");
//		int a = int.Parse(Console.ReadLine());
//		Console.Write("Въведи второто число: ");
//		int b = int.Parse(Console.ReadLine());
//		int gcd = FindGCD(a, b);
//		int lcm = FindLCM(a, b, gcd);
//		Console.WriteLine("НОД: " + gcd);
//		Console.WriteLine("НОК: " + lcm);
//}
//static int FindGCD(int a, int b)
//{
//		a = Math.Abs(a);
//		b = Math.Abs(b);
//		while (b != 0)
//		{
//			int temp = b;
//			b = a % b;
//			a = temp;
//		}
//		return a;
//}
//static int FindLCM(int a,int b, int gcd)
//{
//		return Math.Abs(a * b) / gcd;
//}
//} 