﻿//using System;
//namespace _30._03._26
//{
//	internal class Program
//	{
		////////////////////////////////////////////////// 1
		//static void Main()
		//{
		//	Console.Write("Въведи число: ");
		//	int number = int.Parse(Console.ReadLine());
		//	if (IsPrime(number))
		//	{
		//		Console.WriteLine("Числото е просто.");
		//	}
		//	else
		//	{
		//		Console.WriteLine("Числото НЕ е просто. ");
		//	}
		//}
		//static bool IsPrime(int number)
		//{
		//	if (number <= 1)
		//		return false;
		//		for (int i = 2; i <= Math.Sqrt(number); i++)
		//		{
		//		if (number % i == 0) return false;
		//		}
		//	return true;
		//}

		//////////////////////////////////////////////////// 2
		//static void Main()
		//{
		//	Console.Write("Въведи цяло число N: ");
		//	int n = int.Parse(Console.ReadLine());
		//	Console.WriteLine("Прости числа от 2 до " + n + "са: ");
		//	for (int i = 2; i <= n; i++)
		//	{
		//		if (IsPrime(i))
		//		{
		//			Console.Write(i + " ");
		//		}
		//	}
		//}
		//static bool IsPrime(int number)
		//{
		//	if (number <= 1)
		//		return false;
		//	for (int i = 2; i <= Math.Sqrt(number); i++)
		//	{
		//		if (number % i == 0)
		//			return false;
		//	}
		//	return true;
		//}

		//////////////////////////////////////////// 3
//		static void Main()
//		{
//			Console.Write("въведи число: ");
//			int number = int.Parse(Console.ReadLine());
//			int sum = SumOfDigits(number);
//			bool isPalindrome = isPalindrome(number);
//			Console.WriteLine("Сума на цифрите: " + sum);
//			if (isPalindrome)
//			{
//				Console.WriteLine("Числото е палиндром. ");
//			}
//			else
//			{
//				Console.WriteLine("Числото НЕ е палиндром. ");
//			}
//		}
//		static int SumOfDigits(int number)
//		{
//			number = Math.Abs(number);
//			int sum = 0;
//			while (number > 0)
//			{
//				sum += number % 10;
//				number /= 10;
//			}
//			return sum;

//		}
//		static bool IsPalindrome(int number)
//		{
//			number = Math.Abs(number);
//			int original = number;
//			int reversed = 0;
//			while (number > 0)
//			{
//				int digit = number % 10;
//				reversed = reversed * 10 + digit;
//				number /= 10;
//			}
//			return original == reversed;

//		}
//	}
//}