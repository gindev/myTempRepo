﻿////using System;
////using System.Collections.Generic;
////using System.Linq;
////using System.Text;
////using System.Threading.Tasks;

////namespace HWpracticum
////{
////    internal class _7_method
////    {
////        class Sorting
////        {

////            static void SortArray(int[] array)
////            {
////                int n = array.Length;

////                for (int pass = 0; pass < n - 1; pass++)        
////                {
////                    for (int i = 0; i < n - 1 - pass; i++)      
////                    {
////                        if (array[i] > array[i + 1])            
////                        {
                            
////                            int temp = array[i];
////                            array[i] = array[i + 1];
////                            array[i + 1] = temp;
////                        }
////                    }
////                }
////            }

            
////            static void PrintArray(int[] array)
////            {
////                for (int i = 0; i < array.Length; i++)
////                {
////                    Console.Write(array[i]);
////                    if (i < array.Length - 1)
////                        Console.Write(" ");   
////                }
////                Console.WriteLine();
////            }

////            static void Main()
////            {
////                Console.Write("Enter numbers (separated by space or comma): ");
////                string line = Console.ReadLine();

               
////                string[] parts = line.Split(new char[] { ' ', ',' },
////                                             StringSplitOptions.RemoveEmptyEntries);

////                int[] numbers = new int[parts.Length];
////                for (int i = 0; i < parts.Length; i++)
////                {
////                    numbers[i] = int.Parse(parts[i].Trim());
////                }

////                Console.Write("Before sorting: ");
////                PrintArray(numbers);

////                SortArray(numbers);     

////                Console.Write("After sorting:  ");
////                PrintArray(numbers);
////            }
////        }
////    }
////}

