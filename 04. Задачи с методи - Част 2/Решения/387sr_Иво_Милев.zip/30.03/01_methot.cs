﻿//using System;

//class Program
//{
//	static void Main()
//	{
//		Console.Write("Въведи число: ");
//		int number = int.Parse(Console.ReadLine());
//		if (IsPrime(number))
//		{
//			Console.WriteLine("Числото е просто.");
//		}
//		else
//		{
//			Console.WriteLine("Числото НЕ е просто. ");
//		}
//	}
//	static bool IsPrime(int number)
//	{
//		if (number <= 1)
//			return false;
//		for (int i = 2; i <= Math.Sqrt(number); i++)
//		{
//			if (number % i == 0) return false;
//		}
//		return true;
//	}
//}
