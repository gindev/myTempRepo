﻿//using System;
//using System.Linq;

//class Program5
//{
//	static void Main()
//	{
//		Console.Write("Въведете числа (разделени с интервал или запетая): ");
//		string input = Console.ReadLine();

//		int[] numbers = input
//			.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
//			.Select(int.Parse)
//			.ToArray();

//		Console.WriteLine($"Минимален елемент: {FindMin(numbers)}");
//		Console.WriteLine($"Максимален елемент: {FindMax(numbers)}");
//		Console.WriteLine($"Сума: {FindSum(numbers)}");
//		Console.WriteLine($"Средна стойност: {FindAverage(numbers):F2}");
//	}

//	static int FindMin(int[] arr)
//	{
//		int min = arr[0];
//		foreach (int num in arr)
//		{
//			if (num < min)
//				min = num;
//		}
//		return min;
//	}

//	static int FindMax(int[] arr)
//	{
//		int max = arr[0];
//		foreach (int num in arr)
//		{
//			if (num > max)
//				max = num;
//		}
//		return max;
//	}

//	static int FindSum(int[] arr)
//	{
//		int sum = 0;
//		foreach (int num in arr)
//		{
//			sum += num;
//		}
//		return sum;
//	}

//	static double FindAverage(int[] arr)
//	{
//		return (double)FindSum(arr) / arr.Length;
//	}
//}

