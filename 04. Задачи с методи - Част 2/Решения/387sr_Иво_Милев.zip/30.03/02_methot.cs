﻿//using System;

//class Program
//{

////	static void Main()
////	{
////		Console.Write("Въведи цяло число N: ");
////		int n = int.Parse(Console.ReadLine());
////		Console.WriteLine("Прости числа от 2 до " + n + "са: ");
////		for (int i = 2; i <= n; i++)
////		{
////			if (IsPrime(i))
////			{
////				Console.Write(i + " ");
////			}
////		}
////	}
////	static bool IsPrime(int number)
////	{
////		if (number <= 1)
////			return false;
////		for (int i = 2; i <= Math.Sqrt(number); i++)
////		{
////			if (number % i == 0)
////				return false;
////		}
////		return true;
////	}
////}
