﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace HWpracticum
//{
//	internal class _6_method
//	{
//		static bool IsEven(int n)
//		{
//			return n % 2 == 0;
//		}
//		static bool IsPrime(int n)
//		{
//			if (n < 2) return false;

//			for (int i = 2; i <= Math.Sqrt(n); i++)
//			{
//				if (n % i == 0) return false;
//			}
//			return true;
//		}


//		static bool IsPalindrome(int n)
//		{
//			string text = n.ToString();
//			string reversed = "";


//			for (int i = text.Length - 1; i >= 0; i--)
//			{
//				reversed += text[i];
//			}

//			return text == reversed;
//		}

//		static void Main()
//		{
//			Console.Write("Въведи number разделени с интервал: ");
//			string line = Console.ReadLine();

//			string[] part = line.Split(' ');
//			int[] number = new int[part.Length];

//			for (int i = 0; i < part.Length; i++)
//			{
//				number[i] = int.Parse(part[i]);
//			}


//			int even = 0;
//			int odd = 0;
//			int simple = 0;
//			int palindrome = 0;

//			for (int i = 0; i < number.Length; i++)
//			{
//				if (IsEven(number[i])) even++;
//				else odd++;

//				if (IsPrime(number[i])) simple++;
//				if (IsPalindrome(number[i])) palindrome++;
//			}

//			Console.WriteLine("even number: " + even);
//			Console.WriteLine("odd number: " + odd);
//			Console.WriteLine("simple number: " + simple);
//			Console.WriteLine("palindrome: " + palindrome);
//		}
//	}
//}
