﻿//using System;
//static void Main()
//{
//	Console.Write("въведи число: ");
//	int number = int.Parse(Console.ReadLine());
//	int sum = SumOfDigits(number);
//	bool isPalindrome = isPalindrome(number);
//	Console.WriteLine("Сума на цифрите: " + sum);
//	if (isPalindrome)
//	{
//		Console.WriteLine("Числото е палиндром. ");
//	}
//	else
//	{
//		Console.WriteLine("Числото НЕ е палиндром. ");
//	}
//}
//static int SumOfDigits(int number)
//{
//	number = Math.Abs(number);
//	int sum = 0;
//	while (number > 0)
//	{
//		sum += number % 10;
//		number /= 10;
//	}
//	return sum;

//}
//static bool IsPalindrome(int number)
//{
//	number = Math.Abs(number);
//	int original = number;
//	int reversed = 0;
//	while (number > 0)
//	{
//		int digit = number % 10;
//		reversed = reversed * 10 + digit;
//		number /= 10;
//	}
//	return original == reversed;

//}



