﻿namespace zadacha6
{
    using System;
    using System.Linq;

    class Program
    {
        static bool IsPrime(int n)
        {
            if (n <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0) return false;
            return true;
        }

        static bool IsPalindrome(int n)
        {
            int original = n, reversed = 0;
            while (n > 0)
            {
                reversed = reversed * 10 + n % 10;
                n /= 10;
            }
            return original == reversed;
        }

        static void Main()
        {
            int[] arr = Console.ReadLine()
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            int even = arr.Count(x => x % 2 == 0);
            int odd = arr.Count(x => x % 2 != 0);
            int prime = arr.Count(x => IsPrime(x));
            int palindrome = arr.Count(x => IsPalindrome(x));

            Console.WriteLine("Chetni: " + even);
            Console.WriteLine("Nechetni: " + odd);
            Console.WriteLine("Prosti: " + prime);
            Console.WriteLine("Palindromi: " + palindrome);
        }
    }
}
