﻿namespace zadacha3
{
    using System;

    class Program
    {
        static int SumDigits(int n)
        {
            int sum = 0;
            while (n > 0)
            {
                sum += n % 10;
                n /= 10;
            }
            return sum;
        }

        static bool IsPalindrome(int n)
        {
            int original = n;
            int reversed = 0;

            while (n > 0)
            {
                reversed = reversed * 10 + n % 10;
                n /= 10;
            }

            return original == reversed;
        }

        static void Main()
        {
            int num = int.Parse(Console.ReadLine());

            Console.WriteLine("Suma: " + SumDigits(num));
            Console.WriteLine("Palindrom: " + IsPalindrome(num));
        }
    }
}
