﻿namespace zadacha5
{
    using System;
    using System.Linq;

    class Program
    {
        static void Main()
        {
            Console.WriteLine("Vuvedete chisla (Razdeleni s interval ili zapetaq):");

            string input = Console.ReadLine();

            int[] arr = input
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            int min = arr.Min();
            int max = arr.Max();
            int sum = arr.Sum();
            double avg = arr.Average();

            Console.WriteLine($"Minimalno: {min}");
            Console.WriteLine($"Maksimalno: {max}");
            Console.WriteLine($"Suma: {sum}");
            Console.WriteLine($"Sredno: {avg:F2}");
        }
    }
}
