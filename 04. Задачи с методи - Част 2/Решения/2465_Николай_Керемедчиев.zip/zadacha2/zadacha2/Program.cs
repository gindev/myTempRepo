﻿using System.Reflection;

namespace zadacha2
{
    

    class Program
    {
        static bool IsPrime(int n)
        {
            if (n <= 1) return false;

            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                    return false;
            }
            return true;
        }

        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 2; i <= n; i++)
            {
                if (IsPrime(i))
                    Console.Write(i + " ");
            }
        }
    }
}
