﻿//Създайте програма, която приема от конзолата ред с цели числа, разделени със запетая или интервал, и ги записва в масив.
//Напишете метод, който сортира масива във възходящ ред, без да използвате вградени функции за сортиране (като Array.Sort()).
//Можете да използвате алгоритъм по избор (например selection sort, insertion sort или друг).
//След това отпечатайте сортирания масив.

using Common;


while (true)
{
    int[]? numbers = ArrayOperations.ParseInputToIntArray();

    if (numbers == null)
    {
        break;
    }

    ArrayOperations.BubbleSortArray(numbers);
    ArrayOperations.PrintArray(numbers);
    Console.WriteLine();
}