﻿//Създайте програма, която приема от конзолата ред с числа, разделени с интервал или запетая, и ги записва в масив.
//Напишете отделни методи, които намират:

//най - малкия елемент;
//най - големия елемент;
//сумата на елементите;
//средната стойност на елементите.
//След това програмата трябва да отпечата всички резултати.

//Пример: При вход от конзолата: 4, 7, 2, 9, 5

//Изходът следва да бъде:

//Минимален елемент: 2
//Максимален елемент: 9
//Сума: 27
//Средна стойност: 5.40

using Common;

while (true)
{
    int[]? numbers = ArrayOperations.ParseInputToIntArray();

    if (numbers == null)
    {
        break;
    }

    Console.WriteLine($"Min: {numbers.Min()}");
    Console.WriteLine($"Max: {numbers.Max()}");
    Console.WriteLine($"Sum: {numbers.Sum()}");
    Console.WriteLine($"Average: {numbers.Average():F2}");
    Console.WriteLine();
}