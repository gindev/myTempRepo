﻿//Създайте програма, която приема от конзолата цяло число. Напишете:

//метод, който намира сумата на цифрите му; X
//метод, който проверява дали числото е палиндром. X
//Число е палиндром, ако се чете еднакво отляво надясно и отдясно наляво. Например: 121, 1331, 7.
//Програмата трябва да отпечата на конзолата:

//сумата на цифрите;
//дали числото е палиндром.

using Common;

Console.WriteLine("Enter a whole number. The program will print the sum of its digits and check if its a palindrome.");
Console.WriteLine("Type EXIT to end.");


while (true)
{
    string? input = Console.ReadLine();

    if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    bool isValidNumber = int.TryParse(input, out int number);

    if (!isValidNumber)
    {
        Console.WriteLine("Invalid input. Input can only be a whole integer.");
        Console.WriteLine("Try again or type EXIT to end.");
        continue;
    }

    int sumOfDigits = CustomMath.GetSumOfDigits(number);
    Console.WriteLine($"The sum of the digits is: {sumOfDigits}");

    if (CustomMath.IsPalindrome(number))
    {
        Console.WriteLine("The number is a palindrome.");
    }
    else
    {
        Console.WriteLine("The number is not a palindrome.");
    }
}