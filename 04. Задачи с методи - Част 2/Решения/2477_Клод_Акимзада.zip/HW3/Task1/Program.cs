﻿//Създайте програма, която приема от конзолата цяло число.
//Напишете метод, който проверява дали числото е просто.
//Числото е просто, ако е по-голямо от 1 и има точно два делителя – 1 и себе си.

using Common;

Console.WriteLine("Enter a whole number, the program will print whether it's prime or not");
Console.WriteLine("Type EXIT to end.");

while (true)
{
    string? input = Console.ReadLine();

    if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    bool isValidNumber = int.TryParse(input, out int number);

    if (!isValidNumber)
    {
        Console.WriteLine("Invalid input. Input can only be a whole integer.");
        Console.WriteLine("Try again or type EXIT to end.");
        continue;
    }

    if (CustomMath.IsPrime(number))
    {
        Console.WriteLine($"{number} is prime.");
    }
    else
    {
        Console.WriteLine($"{number} is not prime.");
    }
}

