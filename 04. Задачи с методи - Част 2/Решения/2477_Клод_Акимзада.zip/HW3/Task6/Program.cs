﻿//Създайте програма, която приема от конзолата ред с цели числа и ги записва в масив. Напишете програма, която:

//намира колко от числата са четни;
//намира колко са нечетни;
//намира колко са прости;
//намира колко са палиндроми.
//Важно: За решението използвайте методи, написани в предходни задачи, когато е възможно.

//Пример:

//При вход от конзолата: 2 3 4 5 11 22 121 10

//Примерен изход на конзолата:

//Четни числа: 4
//Нечетни числа: 4
//Прости числа: 4
//Палиндроми: 3(7 с едноцифрените числа)
using Common;

while (true)
{

    int[]? numbers = ArrayOperations.ParseInputToIntArray();

    if (numbers == null)
    {
        break;
    }

    int evenCount = numbers.Count(n => n % 2 == 0);
    int oddCount = numbers.Length - evenCount;
    int primeCount = numbers.Count(CustomMath.IsPrime);
    int palindromeCount = numbers.Count(CustomMath.IsPalindrome);

    Console.WriteLine($"Even numbers: {evenCount}");
    Console.WriteLine($"Odd numbers: {oddCount}");
    Console.WriteLine($"Prime numbers: {primeCount}");
    Console.WriteLine($"Palindromes: {palindromeCount}");
    Console.WriteLine();
}