﻿namespace Common
{
    public static class ArrayOperations
    {
        public static int[]? ParseInputToIntArray()
        {
            Console.WriteLine("Enter an array of numbers separated by space or comma:");
            Console.WriteLine("Type 'EXIT' to end.");

            while (true)
            {
                string? input = Console.ReadLine()?.Trim();

                if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Invalid input. Try again.");
                    continue;
                }

                char[] separators = new[] { ' ', ',' };
                string[] numberStrings = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                bool allValid = numberStrings.All(s => int.TryParse(s, out _));

                if (allValid)
                {
                    return ConvertStringArrayToIntArray(numberStrings);
                }

                Console.WriteLine("Invalid input. Please enter only whole numbers.");
            }
        }

        // expects pre-validated input
        public static int[] ConvertStringArrayToIntArray(string[] numberStrings)
        {
            return numberStrings.Select(int.Parse).ToArray();
        }

        public static void BubbleSortArray(int[] array)
        {
            if (array == null || array.Length <= 1)
            {
                return;
            }

            int n = array.Length;
            bool swapped;

            for (int i = 0; i < n - 1; i++)
            {
                swapped = false;

                for (int j = 0; j < n - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        Swap(array, j, j + 1);
                        swapped = true;
                    }
                }

                if (!swapped)
                {
                    break;
                }
            }
        }
        public static void Swap(int[] array, int index1, int index2)
        {
            int temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

        public static void PrintArray(int[] array)
        {
            Console.WriteLine(string.Join(", ", array));
        }
    }
}
