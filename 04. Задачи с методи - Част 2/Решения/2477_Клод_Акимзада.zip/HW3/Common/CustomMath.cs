﻿namespace Common
{
    public static class CustomMath
    {
        public static bool IsPrime(int number)
        {
            if (number <= 1)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }

        public static int GetSumOfDigits(int number)
        {
            int sum = 0;
            number = Math.Abs(number);
            while (number > 0)
            {
                sum += number % 10;
                number /= 10;
            }
            return sum;
        }

        public static bool IsPalindrome(int number)
        {
            if (number < 0)
            {
                return false;
            }

            int originalNumber = number;
            int reversedNumber = 0;

            while (number > 0)
            {
                int lastDigit = number % 10;
                reversedNumber = (reversedNumber * 10) + lastDigit;
                number /= 10;
            }

            return originalNumber == reversedNumber;
        }

        // Greatest Common Divisor (GCD)
        public static int GetGcd(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);

            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }

            return a;
        }


        // Least Common Multiple (LCM)
        public static long GetLcm(int a, int b)
        {
            if (a == 0 || b == 0)
            {
                return 0;
            }

            return Math.Abs(((long)a / GetGcd(a, b)) * b);
        }
    }
}
