﻿//Създайте програма, която приема от конзолата две цели числа. Напишете метод, който намира най-големия общ делител (НОД) на двете числа. След това напишете втори метод, който намира най-малкото общо кратно (НОК), като използва намерения НОД.

//Формула: НОК = (a * b) / НОД

//Програмата трябва да отпечата:

//НОД на двете числа;
//НОК на двете числа.


using Common;

Console.WriteLine("Enter two whole numbers. The program will calculate their GCD and LCM.");
Console.WriteLine("Type EXIT to end.");

while (true)
{

    string? input1 = Console.ReadLine()?.Trim();
    if (string.Equals(input1, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    string? input2 = Console.ReadLine()?.Trim();
    if (string.Equals(input2, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    if (int.TryParse(input1, out int num1) && int.TryParse(input2, out int num2))
    {
        int gcd = CustomMath.GetGcd(num1, num2);
        long lcm = CustomMath.GetLcm(num1, num2);

        Console.WriteLine($"Greatest Common Divisor: {gcd}");
        Console.WriteLine($"Least Common Multiple: {lcm}");
    }
    else
    {
        Console.WriteLine("Invalid input. Both inputs must be whole integers.");
    }
}