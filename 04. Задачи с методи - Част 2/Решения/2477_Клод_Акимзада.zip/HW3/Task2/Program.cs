﻿// Създайте програма, която приема от конзолата цяло число N и отпечатва всички прости числа от 2 до N. Използвайте метод от предходната задача, който проверява дали дадено число е просто.

using Common;

Console.WriteLine("Enter a whole number N, the program will print all prime numbers from 2 to N");

while (true)
{
    string? input = Console.ReadLine();
    if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }
    bool isValidNumber = int.TryParse(input, out int number);
    if (!isValidNumber || number < 2)
    {
        Console.WriteLine("Invalid input. Input can only be a whole integer greater than or equal to 2.");
        Console.WriteLine("Try again or type EXIT to end.");
        continue;
    }
    Console.WriteLine($"Prime numbers from 2 to {number}:");
    for (int i = 2; i <= number; i++)
    {
        if (CustomMath.IsPrime(i))
        {
            Console.Write($"{i} ");
        }
    }
    Console.WriteLine();
}