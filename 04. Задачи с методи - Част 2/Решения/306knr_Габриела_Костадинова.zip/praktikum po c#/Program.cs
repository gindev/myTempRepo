﻿using System.IO;
using System.Text;

namespace Задачи_с_цикли_и_колекции___Част_1
{
    internal class Program
    {
        //        static void Main()
        //        {
        //        Console.OutputEncoding = Encoding.UTF8;

        //        Console.Write("Въведете цяло число N: ");

        //            if (int.TryParse(Console.ReadLine(), out int n))
        //            {
        //                for (int i = 0; i <= n; i++)
        //                {
        //                    Console.WriteLine(i);
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("Невалиден вход!");
        //            }
        //        }
        //    }
        //}



        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;

        //    Console.Write("Въведете цяло число N: ");

        //    if (int.TryParse(Console.ReadLine(), out int n))
        //    {
        //        for (int i = n; i >= 0; i--)
        //        {
        //            Console.WriteLine(i);
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("Невалиден вход!");
        //    }
        //}

        //static void Main() 
        //{
        //    Console.OutputEncoding = Encoding.UTF8;

        //    if (int.TryParse(Console.ReadLine(), out int n))
        //{
        //    for (int i = 0; i <= n; i++)
        //    {
        //        if (i % 2 == 0)
        //        {
        //            Console.WriteLine(i + " е четно");
        //        }
        //        else
        //        {
        //            Console.WriteLine(i + " е нечетно");
        //        }
        //    }
        //}
        //else
        //{
        //     Console.WriteLine("Невалиден вход!");
        //}


        //}

        static void Main()
        {

            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine("Въведете числа, разделени с интервал:");

            string input = Console.ReadLine();
            string[] parts = input.Split(' ');

            int[] numbers = new int[parts.Length];
            bool isValid = true;

            for (int i = 0; i < parts.Length; i++)
            {
                if (!int.TryParse(parts[i], out numbers[i]))
                {
                    isValid = false;
                    break;
                }
            }

            if (!isValid)
            {
                Console.WriteLine("Невалиден вход!");
                return;
            }

            Console.WriteLine("Числата в обратен ред:");

            for (int i = numbers.Length - 1; i >= 0; i--)
            {
                Console.Write(numbers[i] + " ");
            }
        }
    }
}



















    

