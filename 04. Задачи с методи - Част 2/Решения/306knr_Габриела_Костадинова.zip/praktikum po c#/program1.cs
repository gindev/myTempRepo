﻿using System.Text;

namespace Задачи_с_цикли_и_колекции___Част_2
{
    internal class Program
    {
        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;

        //    int[] numbers = new int[10];
        //    Random rand = new Random();


        //    for (int i = 0; i < numbers.Length; i++)
        //    {
        //        numbers[i] = rand.Next(1, 101);
        //    }

        //    Console.WriteLine("Числата в масива са:");


        //    for (int i = 0; i < numbers.Length; i++)
        //    {
        //        Console.Write(numbers[i] + " ");
        //    }
        //}


        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;

        //    int[,] matrix = new int[5, 5];
        //    Random rand = new Random();


        //    for (int i = 0; i < 5; i++)
        //    {
        //        for (int j = 0; j < 5; j++)
        //        {
        //            matrix[i, j] = rand.Next(1, 101);
        //        }
        //    }

        //    Console.WriteLine("Матрицата е:");


        //    for (int i = 0; i < 5; i++)
        //    {
        //        for (int j = 0; j < 5; j++)
        //        {
        //            Console.Write(matrix[i, j].ToString().PadLeft(4));
        //        }
        //        Console.WriteLine();
        //    }
        //}

        //static void Main()
        //{
        //    Console.OutputEncoding = Encoding.UTF8;
        //    Console.InputEncoding = Encoding.UTF8;

        //    List<string> names = new List<string>();

        //    Console.WriteLine("Въвеждайте имена (празен ред за край):");

        //    while (true)
        //    {
        //        string input = Console.ReadLine();

        //        if (string.IsNullOrWhiteSpace(input))
        //            break;

        //        names.Add(input);
        //    }

        //    if (names.Count == 0)
        //    {
        //        Console.WriteLine("Няма въведени имена.");
        //        return;
        //    }

        //    names.Sort();

        //    Console.WriteLine("Имена по азбучен ред:");

        //    foreach (string name in names)
        //    {
        //        Console.WriteLine(name);
        //    }
        //}
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            Console.WriteLine("Въведете фамилии и апартаменти:");
            string input = Console.ReadLine();

            Dictionary<string, int> data = new Dictionary<string, int>();

            string[] pairs = input.Split(',');

            bool isValid = true;

            foreach (string pair in pairs)
            {
                string[] parts = pair.Trim().Split(' ');

                if (parts.Length != 2 || !int.TryParse(parts[1], out int apartment))
                {
                    isValid = false;
                    break;
                }

                string name = parts[0];

                if (!data.ContainsKey(name))
                {
                    data.Add(name, apartment);
                }
            }

            if (!isValid)
            {
                Console.WriteLine("Невалиден вход!");
                return;
            }

            Console.Write("Въведете номер за проверка: ");

            if (!int.TryParse(Console.ReadLine(), out int searchNumber))
            {
                Console.WriteLine("Невалиден номер!");
                return;
            }

            bool found = false;

            foreach (var item in data)
            {
                if (item.Value == searchNumber)
                {
                    Console.WriteLine("Фамилия: " + item.Key);
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine("Няма съвпадение.");
            }
        }
    }
}







