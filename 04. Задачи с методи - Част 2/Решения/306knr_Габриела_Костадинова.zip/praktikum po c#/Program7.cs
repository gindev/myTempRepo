﻿using System.Text;

namespace Задача6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            int[] arr = Console.ReadLine()
                .Split(' ')
                .Select(int.Parse)
                .ToArray();

            int even = 0, odd = 0, prime = 0, pal = 0;

            foreach (int n in arr)
            {
                if (n % 2 == 0) even++; else odd++;
                if (IsPrime(n)) prime++;
                if (IsPalindrome(n)) pal++;
            }

            Console.WriteLine("Четни: " + even);
            Console.WriteLine("Нечетни: " + odd);
            Console.WriteLine("Прости: " + prime);
            Console.WriteLine("Палиндроми: " + pal);
        }

        static bool IsPrime(int num)
        {
            if (num <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(num); i++)
                if (num % i == 0) return false;
            return true;
        }

        static bool IsPalindrome(int num)
        {
            string s = num.ToString();
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return s == new string(arr);
        }
    }
}
