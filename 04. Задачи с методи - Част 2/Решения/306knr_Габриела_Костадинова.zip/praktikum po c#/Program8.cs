﻿using System.Text;

namespace задача7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            int[] arr = Parse();

            SelectionSort(arr);
            Print(arr);
        }

        static int[] Parse()
        {
            return Console.ReadLine()
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
        }

        static void SelectionSort(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int min = i;

                for (int j = i + 1; j < arr.Length; j++)
                    if (arr[j] < arr[min])
                        min = j;

                int temp = arr[i];
                arr[i] = arr[min];
                arr[min] = temp;
            }
        }

        static void Print(int[] arr)
        {
            Console.WriteLine(string.Join(" ", arr));
        }
    }
    
}
