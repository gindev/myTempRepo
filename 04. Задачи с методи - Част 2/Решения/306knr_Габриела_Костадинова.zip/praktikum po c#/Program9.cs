﻿using System.Text;

namespace задача8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            int[] arr = Parse();

            BubbleSort(arr);
            Print(arr);
        }

        static int[] Parse()
        {
            return Console.ReadLine()
                .Split(' ')
                .Select(int.Parse)
                .ToArray();
        }

        static void Swap(int[] arr, int i, int j)
        {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }

        static void BubbleSort(int[] arr)
        {
            bool swapped;

            for (int i = 0; i < arr.Length - 1; i++)
            {
                swapped = false;

                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        Swap(arr, j, j + 1);
                        swapped = true;
                    }
                }

                if (!swapped) break;
            }
        }

        static void Print(int[] arr)
        {
            Console.WriteLine(string.Join(" ", arr));
        }
    }
    
}
