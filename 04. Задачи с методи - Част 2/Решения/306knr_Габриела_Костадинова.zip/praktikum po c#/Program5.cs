﻿using System.Text;

namespace Задача4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.Write("Въведи първо число: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Въведи второ число: ");
            int b = int.Parse(Console.ReadLine());

            int nod = GCD(a, b);
            int nok = LCM(a, b);

            Console.WriteLine("НОД: " + nod);
            Console.WriteLine("НОК: " + nok);
        }

        static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }

        static int LCM(int a, int b)
        {
            return Math.Abs(a * b) / GCD(a, b);
        }
    }
    
}
