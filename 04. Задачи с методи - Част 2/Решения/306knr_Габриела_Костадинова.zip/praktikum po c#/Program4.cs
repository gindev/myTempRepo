﻿using System.Text;

namespace Задача_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.Write("Въведи число: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Сума на цифрите: " + SumDigits(n));
            Console.WriteLine(IsPalindrome(n) ? "Палиндром е" : "Не е палиндром");
        }

        static int SumDigits(int num)
        {
            int sum = 0;
            num = Math.Abs(num);

            while (num > 0)
            {
                sum += num % 10;
                num /= 10;
            }
            return sum;
        }

        static bool IsPalindrome(int num)
        {
            string s = Math.Abs(num).ToString();
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);

            return s == new string(arr);
        }
    }
    
}
