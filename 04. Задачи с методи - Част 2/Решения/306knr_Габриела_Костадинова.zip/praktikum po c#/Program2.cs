﻿using System.Text;

namespace Задача_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.Write("Въведи число: ");
            int n = int.Parse(Console.ReadLine());

            if (IsPrime(n))
                Console.WriteLine("Числото е просто.");
            else
                Console.WriteLine("Числото НЕ е просто.");
        }

        static bool IsPrime(int num)
        {
            if (num <= 1) return false;

            for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if (num % i == 0)
                    return false;
            }
            return true;
        }
    }
}
    

