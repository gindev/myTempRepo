﻿using System.Text;

namespace Задача_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.Write("Въведи числа: ");
            int[] arr = Console.ReadLine()
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            Console.WriteLine("Минимален елемент: " + Min(arr));
            Console.WriteLine("Максимален елемент: " + Max(arr));
            Console.WriteLine("Сума: " + Sum(arr));
            Console.WriteLine("Средна стойност: " + Avg(arr).ToString("F2"));
        }

        static int Min(int[] arr) => arr.Min();
        static int Max(int[] arr) => arr.Max();
        static int Sum(int[] arr) => arr.Sum();
        static double Avg(int[] arr) => arr.Average();
    }
}
    

