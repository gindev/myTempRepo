﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static int Min(int[] arr) => arr.Min();
        static int Max(int[] arr) => arr.Max();
        static int Sum(int[] arr) => arr.Sum();
        static double Avg(int[] arr) => arr.Average();
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine()
            .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToArray();

            Console.WriteLine($"Минимален елемент: {Min(arr)}");
            Console.WriteLine($"Максимален елемент: {Max(arr)}");
            Console.WriteLine($"Сума: {Sum(arr)}");
            Console.WriteLine($"Средна стойност: {Avg(arr):F2}");
        }
    }
}
