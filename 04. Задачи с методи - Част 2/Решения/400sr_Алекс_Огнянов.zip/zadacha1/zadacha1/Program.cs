﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Program
    {
        static bool PrimeNUm(int num)
        {
            bool prime = true;
            for (int i = 2; i <= Math.Sqrt(num) && prime == true; i++) 
            {
                if (num % i == 0)
                {
                    prime = false;
                }
            }
            return prime;
        }
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            if (PrimeNUm(num) == true)
            {
                Console.WriteLine($"The number {num} is prime");
            }
            else 
            {
                Console.WriteLine($"The number {num} is not prime");

            }
        }
    }
}
