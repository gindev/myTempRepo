﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha8
{
    internal class Program
    {
        static int[] ParseInput()
        {
            return Console.ReadLine()
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
        }

        static void Swap(int[] arr, int i, int j)
        {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }

        static void BubbleSort(int[] arr)
        {
            bool swapped;

            for (int i = 0; i < arr.Length - 1; i++)
            {
                swapped = false;

                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        Swap(arr, j, j + 1);
                        swapped = true;
                    }
                }

                if (!swapped) break;
            }
        }

        static void PrintArray(int[] arr)
        {
            Console.WriteLine(string.Join(" ", arr));
        }
        static void Main(string[] args)
        {
            int[] arr = ParseInput();

            BubbleSort(arr);

            PrintArray(arr);
        }
    }
}
