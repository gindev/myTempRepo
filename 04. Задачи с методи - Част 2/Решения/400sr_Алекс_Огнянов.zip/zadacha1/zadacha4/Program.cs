﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {
        static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }

        static int LCM(int a, int b)
        {
            return Math.Abs(a * b) / GCD(a, b);
        }

        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            int gcd = GCD(a, b);
            int lcm = LCM(a, b);

            Console.WriteLine($"НОД: {gcd}");
            Console.WriteLine($"НОК: {lcm}");
        }
    }
}
