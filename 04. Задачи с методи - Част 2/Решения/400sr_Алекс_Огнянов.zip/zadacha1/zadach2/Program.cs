﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace zadacha2
{
    internal class Program
    {
        static bool PrimeNUm(int num)
        {
            if (num < 2) return false;

            bool prime = true;
            for (int i = 2; i <= Math.Sqrt(num) && prime == true; i++)
            {
                if (num % i == 0)
                {
                    prime = false;
                }
            }
            return prime;
        }

            static void Main(string[] args)
            {
                int n = int.Parse(Console.ReadLine());

                for (int i = 2; i <= n; i++)
                {
                    if (PrimeNUm(i))
                    {
                        Console.Write(i + " ");
                    }
                }
        }
    }
}
