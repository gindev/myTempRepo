﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha6
{
    internal class Program
    {
        static bool PrimeNUm(int num)
        {
            if (num < 2) return false;

            bool prime = true;
            for (int i = 2; i <= Math.Sqrt(num) && prime == true; i++)
            {
                if (num % i == 0)
                    prime = false;
            }
            return prime;
        }

        static bool IsPalindrome(int num)
        {
            int original = num;
            int reversed = 0;

            while (num > 0)
            {
                reversed = reversed * 10 + num % 10;
                num /= 10;
            }

            return original == reversed;
        }
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine()
            .Split(' ')
            .Select(int.Parse)
            .ToArray();

            int even = 0, odd = 0, prime = 0, palindrome = 0;

            foreach (int num in arr)
            {
                if (num % 2 == 0) even++;
                else odd++;

                if (PrimeNUm(num)) prime++;
                if (IsPalindrome(num)) palindrome++;
            }

            Console.WriteLine($"Четни числа: {even}");
            Console.WriteLine($"Нечетни числа: {odd}");
            Console.WriteLine($"Прости числа: {prime}");
            Console.WriteLine($"Палиндроми: {palindrome}");
        }
    }
}
