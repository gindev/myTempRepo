﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Program
    {
        static int SumDigits(int num)
        {
            int sum = 0;
            num = Math.Abs(num);

            while (num > 0)
            {
                sum += num % 10;
                num /= 10;
            }
            return sum;
        }

        static bool IsPalindrome(int num)
        {
            int original = num;
            int reversed = 0;

            while (num > 0)
            {
                reversed = reversed * 10 + num % 10;
                num /= 10;
            }

            return original == reversed;
        }
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());

            Console.WriteLine($"Сума на цифрите: {SumDigits(num)}");

            if (IsPalindrome(num))
                Console.WriteLine("Числото е палиндром");
            else
                Console.WriteLine("Числото не е палиндром");
        }
    }
}
