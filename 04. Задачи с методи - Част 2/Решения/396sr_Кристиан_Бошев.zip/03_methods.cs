﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter number: ");
        int n = int.Parse(Console.ReadLine());

        int sum = SumOfDigits(n);
        bool isPalindrome = IsPalindrome(n);

        Console.WriteLine("Sum of digits = " + sum);

        if (isPalindrome)
        {
            Console.WriteLine("The number is palindrome");
        }
        else
        {
            Console.WriteLine("The number is NOT palindrome");
        }
    }
    static int SumOfDigits(int n)
    {
        int sum = 0;

        while (n != 0)
        {
            sum += n % 10;
            n = n / 10;
        }

        return sum;
    }
    static bool IsPalindrome(int n)
    {
        int original = n;
        int reversed = 0;

        while (n != 0)
        {
            int digit = n % 10;
            reversed = reversed * 10 + digit;
            n = n / 10;
        }

        return original == reversed;
    }
}