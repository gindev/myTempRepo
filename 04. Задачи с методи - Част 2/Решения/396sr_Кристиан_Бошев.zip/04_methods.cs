using System;

class Program
{
	static void Main()
	{
		static int findNOD(int a, int b)
		{
			while (b != 0)
			{
				int remainder = a % b;
				a = b;
				b = remainder;
			}
			return a;
		}
		static int findNOK(int a, int b)
		{
			int nod = findNOD(a, b);
			return (a * b) / nod;
		}

		Console.Write("Input first number: ");
		int a = int.Parse(Console.ReadLine());

		Console.Write("Input second number: ");
		int b = int.Parse(Console.ReadLine());

		Console.WriteLine("NOD of " + a + " and " + b + " is: " + findNOD(a, b));
		Console.WriteLine("NOK of " + a + " and " + b + " is: " + findNOK(a, b));
	}
}