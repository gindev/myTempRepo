﻿class Program
{
    static void Main()
    {
        static void Main()
        {
            int[] numbers = Console.ReadLine()
                .Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            int min = findMin(numbers);
            int max = findMax(numbers);
            int sum = findSum(numbers);
            double avg = findAverage(numbers);

            Console.WriteLine("Min element: " + min);
            Console.WriteLine("Max element: " + max);
            Console.WriteLine("Sum: " + sum);
            Console.WriteLine("Avg value: " + avg.ToString("F2"));
        }
        static int findMin(int[] arr)
        {
            int min = arr[0];

            foreach (int num in arr)
            {
                if (num < min)
                {
                    min = num;
                }
            }

            return min;
        }
        static int findMax(int[] arr)
        {
            int max = arr[0];

            foreach (int num in arr)
            {
                if (num > max)
                {
                    max = num;
                }
            }

            return max;
        }
        static int findSum(int[] arr)
        {
            int sum = 0;

            foreach (int num in arr)
            {
                sum += num;
            }

            return sum;
        }
        static double findAverage(int[] arr)
        {
            int sum = findSum(arr);
            return (double)sum / arr.Length;
        }
    }
}