﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter number: ");
        int num = int.Parse(Console.ReadLine()!);

        if (IsPrime(num))
        {
            Console.WriteLine("The number is prime");
        }
        else
        {
            Console.WriteLine("The number is NOT prime");
        }
        static bool IsPrime(int n)
        {
            if (n <= 1)
            {
                return false;
            }
            for (int i = 2; i < n; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}