using System;

class Program
{
    class Sorting
    {
        static void sortArray(int[] array)
        {
            int n = array.Length;

            for (int i = 0; i < n - 1; i++)
            {
                for (int i = 0; i < n - 1 - i; i++)
                {
                    if (array[i] > array[i + 1])
                    {
                        int temp = array[i];
                        array[i] = array[i + 1];
                        array[i + 1] = temp;
                    }
                }
            }
        }
        static void printArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i]);
                if (i < array.Length - 1)
                    Console.Write(" ");
            }
            Console.WriteLine();
        }

        static void Main()
        {
            Console.Write("Input numbers separated by space or comma: ");
            string line = Console.ReadLine();

            string[] parts = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            int[] numbers = new int[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                numbers[i] = int.Parse(parts[i].Trim());
            }

            Console.Write("Before sorting: ");
            printArray(numbers);

            sortArray(numbers);

            Console.Write("After sorting:  ");
            printArray(numbers);
        }
    }
}