﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Създайте програма, която приема от конзолата цяло число N и отпечатва всички прости числа от 2 до N. Използвайте метод от предходната задача, който проверява дали дадено число е просто.


                  int N = int.Parse(Console.ReadLine());

            
            for (int i = 2; i <= N; i++)
            {
                Proveri(i);
            }
        }

        static void Proveri(int number)
        {
            bool eProsto = true;

            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    eProsto = false;
                    break;
                }
            }

           
            if (eProsto)
            {
                Console.Write(number + " ");
            }
        }
    }

}






