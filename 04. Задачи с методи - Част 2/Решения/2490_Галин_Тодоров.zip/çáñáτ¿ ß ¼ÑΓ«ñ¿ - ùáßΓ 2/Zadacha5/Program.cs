﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Създайте програма, която приема от конзолата ред с числа, разделени с интервал или запетая, и ги записва в масив.
            //Напишете отделни методи, които намират:

            //най - малкия елемент;
            //            най - големия елемент;
            //            сумата на елементите;
            //            средната стойност на елементите.
            //След това програмата трябва да отпечата всички резултати.

            //Пример: При вход от конзолата: 4, 7, 2, 9, 5

            //Изходът следва да бъде:

            //Минимален елемент: 2
            //Максимален елемент: 9
            //Сума: 27
            //Средна стойност: 5.40

           
            string input = Console.ReadLine();

           
            string[] elements = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

           
            int[] numbers = new int[elements.Length];
            for (int i = 0; i < elements.Length; i++)
            {
                numbers[i] = int.Parse(elements[i]);
            }

            
            Console.WriteLine("Min element: " + FindMin(numbers));
            Console.WriteLine("Max елемент: " + FindMax(numbers));
            Console.WriteLine("SUM: " + FindSum(numbers));
            Console.WriteLine("Average: " + FindAverage(numbers).ToString("F2"));
        }

        static int FindMin(int[] arr)
        {
            int min = arr[0];
            foreach (int n in arr) if (n < min) min = n;
            return min;
        }

        static int FindMax(int[] arr)
        {
            int max = arr[0];
            foreach (int n in arr) if (n > max) max = n;
            return max;
        }

        static int FindSum(int[] arr)
        {
            int sum = 0;
            foreach (int n in arr) sum += n;
            return sum;
        }

        static double FindAverage(int[] arr)
        {
            return (double)FindSum(arr) / arr.Length;
        }
    }




}
    

