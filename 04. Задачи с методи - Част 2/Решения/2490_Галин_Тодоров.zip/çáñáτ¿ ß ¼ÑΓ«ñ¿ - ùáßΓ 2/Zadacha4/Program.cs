﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Създайте програма, която приема от конзолата две цели числа. Напишете метод, който намира най-големия общ делител (НОД) на двете числа. След това напишете втори метод, който намира най-малкото общо кратно (НОК), като използва намерения НОД.

            //Формула: НОК = (a * b) / НОД

            //Програмата трябва да отпечата:

            //НОД на двете числа;
            //НОК на двете числа.


            Console.WriteLine("Vuvedete dve chisla ");
            int N1 = int.Parse(Console.ReadLine());
            int N2 = int.Parse(Console.ReadLine());

            int nod = NOD(N1, N2);
            int nok = NOK(N1, N2, nod);

            Console.WriteLine($"НОД : {nod}");
            Console.WriteLine($"НОК а: {nok}");

        }

            static int NOD(int a, int b)
            {
                while (b != 0)
                {
                    int temp = b;
                    b = a % b;
                    a = temp;
                }
                return Math.Abs(a);
            }

            
            static int NOK(int a, int b, int nod)
            {
                if (nod == 0) return 0; 
                return Math.Abs(a * b) / nod;
            }
        }


    }



    
    
