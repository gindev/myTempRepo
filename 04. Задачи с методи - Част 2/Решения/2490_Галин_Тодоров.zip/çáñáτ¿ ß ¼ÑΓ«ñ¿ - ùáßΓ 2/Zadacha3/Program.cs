﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Създайте програма, която приема от конзолата цяло число.Напишете:

            //метод, който намира сумата на цифрите му;
            // метод, който проверява дали числото е палиндром.
            //Число е палиндром, ако се чете еднакво отляво надясно и отдясно наляво.Например: 121, 1331, 7.Програмата трябва да отпечата на конзолата:

            //сумата на цифрите;
            // дали числото е палиндром.

            int N = int.Parse(Console.ReadLine());

            Console.WriteLine(SUM(N));
            Console.WriteLine(Palindrome (N) ? "yes" : "No");
        }

        static int SUM(int n)
        {
            int sum = 0;
            n = Math.Abs(n); 
            while (n > 0)
            {
                sum += n % 10;
                n /= 10;
            }
            return sum;
        }

        static bool Palindrome(int n)
        {
            string original = Math.Abs(n).ToString();
            string reversed = new string(original.Reverse().ToArray());
            return original == reversed;
        }
    }






}
  

