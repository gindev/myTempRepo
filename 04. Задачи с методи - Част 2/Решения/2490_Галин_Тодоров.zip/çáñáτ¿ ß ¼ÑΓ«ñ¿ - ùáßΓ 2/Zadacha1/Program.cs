﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            ////Създайте програма, която приема от конзолата цяло число. Напишете метод, който проверява дали числото е просто. Числото е просто, ако е по-голямо от 1 и има точно два делителя – 1 и себе си.

            int N = int.Parse(Console.ReadLine());

           Proveri(N);
        }

        static void Proveri(int N)
        {
            if (N <= 1)
            {
                Console.WriteLine("Vuvedenoto chislo ne e prosto.");
                return;
            }

            for (int i = 2; i <= Math.Sqrt(N); i++)
            {
                if (N % i == 0)
                {
                    Console.WriteLine("Ne e prosto.");
                    return;
                }
            }

            Console.WriteLine("Prosto e.");
        }
    }



    


}
       
        




    

