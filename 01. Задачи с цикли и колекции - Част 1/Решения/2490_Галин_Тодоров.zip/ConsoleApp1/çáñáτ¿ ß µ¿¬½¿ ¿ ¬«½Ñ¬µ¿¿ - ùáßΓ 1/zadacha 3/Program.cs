﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от 0 до N включително, като изписва кое число е четно и кое не.


            Console.Write("Vuvedete nqkakvo chislo ");
            int N = int.Parse(Console.ReadLine());

            for (int i = 0; i <= N; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i + " e chetno chislo");
                }
                else
                {
                    Console.WriteLine(i + " e nechetno chislo");
                }
            }
        }
    }
}
       

      
  
