﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Създайте програма, която приема произволен брой цели числа от конзолата, след което ги изобразява в обратен ред.

            Console.WriteLine("Vuvedete nqkolko chisla :");

            int[] numbers = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);

            Console.WriteLine("Chislata v obraten red sa slednite:");

            for (int i = numbers.Length - 1; i >= 0; i--)
            {
                Console.Write(numbers[i] + " ");
            }
        }
    }

}
        
      
    

