﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от N до 0 включително.
            int N = int.Parse(Console.ReadLine());

            for (int i = N; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}

    
    

