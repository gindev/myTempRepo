﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadachi1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от 0 до N включително.

            int Number = int.Parse(Console.ReadLine());
            Console.Write("Въведете някакво число :");


            for (int i = 0; i <= Number; i++)
            {
                Console.WriteLine(i);
            }

        }
    }
}

      

