﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadachi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("zadacha1");

            int num1 = int.Parse(Console.ReadLine());
            int num2 = 0;
            while (num2 != num1+1)
            {
                Console.WriteLine(num2);
                num2++;
            }
            Console.WriteLine("zadacha2");

            int num3 = int.Parse(Console.ReadLine());
            int num4 = 0;
            while (num4 != num3)
            {
                Console.WriteLine(num4);
                num4++;
            }
            Console.WriteLine("zadacha3");

            int zad3 = int.Parse(Console.ReadLine());
            for (int i =0; i<=zad3;i++) 
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine($"{i} - even");
                }
                else 
                {
                    Console.WriteLine($"{i} - odd");
                }
            }
            Console.WriteLine("zadacha4");
            Console.WriteLine(string.Join(" ", Console.ReadLine().Split().Reverse()));
        }
    }
}
