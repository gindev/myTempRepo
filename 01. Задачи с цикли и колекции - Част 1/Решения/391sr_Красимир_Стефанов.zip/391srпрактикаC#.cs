/////////////////////////////////////////////////////////////////// зад 1
    int num1 = int.Parse(Console.ReadLine());
    for (int i = 0; i <= num1; i++)
    {
        Console.WriteLine(i);
    }
}

/////////////////////////////////////////////////////////////////// зад 2

int num2 = int.Parse(Console.ReadLine());
for (int i = 0; num2 >= i; num2--)
{
    Console.WriteLine(num2);
}

/////////////////////////////////////////////////////////////////// зад 3

int num3 = int.Parse(Console.ReadLine());
for (int i = 0; i <= num3; i++)
{
    if (i % 2 == 0)
        Console.WriteLine($"Even numbers:{i}");
    else
        Console.WriteLine($"Odd numbers:{i}");
}

/////////////////////////////////////////////////////////////////// зад 4

{ 1, 88, 15, 23, 7, 9 }

int[] numbers = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
for (int i = numbers.Length-1; i >= 0; i--)
{
    Console.WriteLine(numbers[i]);
}

