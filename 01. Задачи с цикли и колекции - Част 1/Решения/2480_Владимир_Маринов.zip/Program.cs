﻿//1
//Console.Write("Въведете N: ");
//int n = int.Parse(Console.ReadLine());
//for (int i = 0; i <= n; i++)
//{
//    Console.WriteLine(i);
//}
//2
//Console.WriteLine("Въведете N: ");
//int n = int.Parse(Console.ReadLine());
//for (int i = n;  i >= 0; i--)
//{
//    Console.WriteLine(i);
//}
//3
//Console.WriteLine("Въведете N: ");
//int n = int.Parse(Console.ReadLine());
//for (int i = 0; i <= n; i++)
//{
//    if (i % 2 == 0)
//    {
//        Console.WriteLine($"{i} е четно");
//    }
//    else
//    {
//        Console.WriteLine($"{i} е нечетно");
//    }
//}
//4
//Console.WriteLine("Въведи числа");
//string input = Console.ReadLine();
//string[] numbers = input.Split(" ");
//Console.WriteLine("В обратен ред:");
//for (int i = numbers.Length - 1; i >= 0; i--)
//{
//    Console.WriteLine(numbers[i] + " ");
//}

