﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Въведете числото l:");
            int l = int.Parse(Console.ReadLine());
            for (int i = 0; i <= l; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i + " -четно");
                }
                else
                {
                    Console.WriteLine(i + " -нечетно");
                }
            }
        }
    }
}
