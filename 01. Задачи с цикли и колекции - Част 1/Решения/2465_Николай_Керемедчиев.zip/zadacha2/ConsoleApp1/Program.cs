﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Въведете числото j:");
            int j = int.Parse(Console.ReadLine());
            for (int i = j; i >= 0; i--)
            {
                Console.WriteLine(i);

            }
        }
    }
}
