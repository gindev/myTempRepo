﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Колко числа ще въведеш: ");
            int n = int.Parse(Console.ReadLine());
            int[] numbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Въведи цислото:");
                numbers[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Числата в обратен ред: ");
            for (int i = n - 1; i >= 0; i--)
            {
                Console.WriteLine(numbers[i]);
            }
        }
    }
}
