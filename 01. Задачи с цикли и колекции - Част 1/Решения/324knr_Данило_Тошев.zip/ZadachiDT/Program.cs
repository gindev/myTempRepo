﻿namespace ZadachiDT;

using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Izberi si zadachata (1-4)");
        string? choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                PrintAscending();
                break;
            case "2":
                PrintDescending();
                break;
            case "3":
                PrintEvenOdd();
                break;
            case "4":
                ReverseNumbers();
                break;
            default:
                Console.WriteLine("Nevadilen izbor.");
                break;
        }
    }

    static int ReadInt()
    {
        while(true)
        {
            Console.WriteLine("Vvedete chislo:");
            string? input =Console.ReadLine();
            if (int.TryParse(input, out int number))
                return number;
            Console.WriteLine("Molq vvedete validno cqlo chislo");
        }
    }

    static void PrintAscending()
    {
        int n = ReadInt();
        for (int i = 0; i <= n; i++)
            Console.WriteLine(i);
    }

    static void PrintDescending()
    {
        int n = ReadInt();

        for (int i = n; i >= 0; i--)
            Console.WriteLine(i);
    }

    static void PrintEvenOdd()
    {
        int n = ReadInt();

        for (int i = 0; i <= n; i++)
            Console.WriteLine(i % 2 == 0 ? $"{i} e chetno" : $"{i} e nechetno");
    }

    static void ReverseNumbers()
    {
        Console.WriteLine("Vvedite chisla (prazen red na kraj):");

        List<int> numbers = new();

        while (true)
        {
            string? input = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(input))
                break;

            if (int.TryParse(input, out int number))
                numbers.Add(number);
            else
                Console.WriteLine("Nevalidno chislo");
        }

        numbers.Reverse();

        Console.WriteLine("Chislata v obraten red:");
        numbers.ForEach(n => Console.WriteLine(n));
    }
        
    }
