﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задача 1
            //Console.Write("Въведи числа за N: ");
            //int n1 = int.Parse(Console.ReadLine());
            //for (int i = 0; i <= n1; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //Задача 2
            //Console.Write("Въведи числа за N: ");
            //int n2 = int.Parse(Console.ReadLine());
            //for (int i = n2; i >= 0; i--)
            //{
            //    Console.WriteLine(i);
            //}

            //Задача 3
            //Console.Write("Въведи числа за N: ");
            //int n3 = int.Parse(Console.ReadLine());
            //for (int i = 0; i <= n3; i++)
            //{
            //    if (i % 2 == 0)
            //    {
            //        Console.WriteLine($"{i} са четни числа");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{i} а това са нечетни числа" );
            //    }
            //}

            //Задача 4
            //List<int> numbs = new List<int>();

            //Console.WriteLine("Въведете колко то си изкаш цели числа (за край напиши'stop'):");

            //while (true)
            //{
            //    string input = Console.ReadLine();
            //    if (input.ToLower() == "stop")
            //        break;

            //    if (int.TryParse(input, out int number))
            //    {
            //        numbs.Add(number);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Невалидно число. Опитайте отново или напиши 'stop' за край.");
            //    }
            //}

            //Console.WriteLine("\nЧислата в обратен ред:");
            //for (int i = numbs.Count - 1; i >= 0; i--)
            //{
            //    Console.WriteLine(numbs[i]);
            //}
        }
    }
}
