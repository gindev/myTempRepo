﻿using System.Globalization;

//// 1. Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от 0 до N включително.

//int num = int.Parse(Console.ReadLine());

//for (int i = 0; i <= num; i++)
//{
//    Console.WriteLine(i);
//}

//// 2. Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от N до 0 включително.

//int num1 = int.Parse(Console.ReadLine());

//for (int i = 0; num1 >= i; num1--)
//{
//    Console.WriteLine(num1);
//}


//// 3. Създайте програма, която приема цяло число N от конзолата и отпечатва всички числа от 0 до N, като изписва кое число е четно и кое не.

//int num2 = int.Parse(Console.ReadLine());

//for (int i = 0; i <= num2; i++)
//{
//    if (i % 2 == 0)
//    {
//        Console.WriteLine("Четни числа: " + i);
//    }
//    else if (i % 2 == 1)
//    {
//        Console.WriteLine("Нечетни числа: " + i);
//    }
//}

//// 4. Създайте програма, която приема произволен брой цели числа от конзолата, след което ги изобразява в обратен ред.

//int[] numbers = Console.ReadLine()!.Split(new[] { ' ', ',', ';' }, StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

//for (int i = numbers.Length - 1; i >= 0; i--)
//{
//    Console.WriteLine(numbers[i]);
//}