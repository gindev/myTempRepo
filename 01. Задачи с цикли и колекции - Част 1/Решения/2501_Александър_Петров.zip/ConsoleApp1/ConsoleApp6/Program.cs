﻿namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();
            string input;

            Console.WriteLine("Vavedete celi chisla (za da sprete, vavedete prazen red):");

            // Четем числа, докато не бъде въведен празен ред
            while (true)
            {
                Console.Write("Vavedete chislo: ");
                input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    break; // Спира, ако въведената стойност е празна
                }

                if (int.TryParse(input, out int number))
                {
                    numbers.Add(number);
                }
                else
                {
                    Console.WriteLine("Molq, vavedete validno cqlo chislo.");
                }
            }

            // Извеждаме числата в обратен ред
            Console.WriteLine("\nChisla v obraten red:");
            for (int i = numbers.Count - 1; i >= 0; i--)
            {
                Console.WriteLine(numbers[i]);
            }
        }
    }
}
