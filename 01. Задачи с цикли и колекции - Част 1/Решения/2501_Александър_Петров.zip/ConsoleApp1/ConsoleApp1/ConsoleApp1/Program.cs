﻿using System.Collections.Specialized;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            int n = int.Parse(Console.ReadLine());
            for (int i= 0; i <= n; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}
