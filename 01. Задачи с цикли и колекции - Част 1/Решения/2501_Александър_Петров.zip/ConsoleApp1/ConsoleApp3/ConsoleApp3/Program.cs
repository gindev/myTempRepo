﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Molq, vavedete cqlo chislo N: ");
            int N = int.Parse(Console.ReadLine());

            
            for (int i = 0; i <= N; i++)
            {
                
                if (i % 2 == 0)
                {
                    Console.WriteLine($"{i} e chetno");
                }
                else
                {
                    Console.WriteLine($"{i} e nechetno");
                }

            }
        }
    }
}
