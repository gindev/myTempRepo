﻿//1.
//Console.WriteLine("Въведи число");
//int n = int.Parse(Console.ReadLine());
//Console.WriteLine("------------");
//for(int i = 0; i <= n; i++)
//{
//    Console.WriteLine(i);
//}
//2.
//Console.WriteLine("Въведи число");
//int n = int.Parse(Console.ReadLine());
//Console.WriteLine("------------");
//for (int i = n; i >= 0; i--)
//{
//    Console.WriteLine(i);
//}
//3.
//Console.WriteLine("Въведи число");
//int n = int.Parse(Console.ReadLine());
//Console.WriteLine("------------");
//for (int i = 0; i <= n; i++)
//{
//    if(i % 2 == 0)
//    {
//        Console.WriteLine($"{i} е четно");
//    }
//    else
//    {
//        Console.WriteLine($"{i} е нечетно");
//    }
//}
//4.
//List<int> numbers = new List<int>();
//Console.WriteLine("Въведете числа (въведете 'stop' за край)");
//while (true)
//{
//    string input = Console.ReadLine();
//    if (input.ToLower() == "stop")
//    {
//        break;
//    }
//    if(int.TryParse(input, out int num))
//    {
//        numbers.Add(num);
//    }
//    else
//    {
//        Console.WriteLine("Enter a num");
//    }
//}
//    numbers.Sort();
//    numbers.Reverse();
//    Console.WriteLine("Числата в обратен ред са:");
//    foreach(int number in numbers)
//    {
//        Console.WriteLine(number);
//    }
