﻿Console.WriteLine("Enter integers one by one. Type REVERSE to reverse or EXIT to end.");

List<int> nums = new List<int>();

while (true)
{
    string input = Console.ReadLine();

    if (input?.Trim().ToLower() == "exit")
    {
        break;
    }

    if (input?.Trim().ToLower() == "reverse")
    {
        if (nums.Count == 0)
        {
            Console.WriteLine("No integers to reverse.");
            continue;
        }
        Console.WriteLine("Here are your integers in reverse:");

        nums.Reverse();
        Console.WriteLine(string.Join(" ", nums));
        nums.Clear();
        continue;
    }

    bool isValid = int.TryParse(input, out int n);

    if (!isValid)
    {
        Console.WriteLine("That's not an integer. Try again or type EXIT.");
        continue;
    }

    nums.Add(n);
}