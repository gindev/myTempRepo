﻿Console.WriteLine("Enter an integer, the program will print 0 to N. Type EXIT to end.");


while (true)
{
    string input = Console.ReadLine();

    if (input?.Trim().ToLower() == "exit")
    {
        break;
    }

    bool isValid = int.TryParse(input, out int n);

    if (!isValid)
    {
        Console.WriteLine("That's not an integer. Try again or type EXIT.");
        continue;
    }

    int i = 0;

    if (n >= 0)
    {
        while (i <= n)
        {
            Console.Write($"{i} ");
            i++;
        }
    }
    else
    {
        while (i >= n)
        {
            Console.Write($"{i} ");
            i--;
        }
    }
    Console.WriteLine();
}