﻿Console.WriteLine("Enter an integer, the program will print N to 0. Type EXIT to end.");


while (true)
{
    string input = Console.ReadLine();

    if (input?.Trim().ToLower() == "exit")
    {
        break;
    }

    bool isValid = int.TryParse(input, out int n);

    if (!isValid)
    {
        Console.WriteLine("That's not an integer. Try again or type EXIT.");
        continue;
    }

    if (n >= 0)
    {
        while (n >= 0)
        {
            Console.Write($"{n} ");
            n--;
        }
    }
    else
    {
        while (n <= 0)
        {
            Console.Write($"{n} ");
            n++;
        }
    }
    Console.WriteLine();
}