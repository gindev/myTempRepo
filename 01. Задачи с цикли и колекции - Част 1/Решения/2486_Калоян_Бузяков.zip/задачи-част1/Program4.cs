﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Колко числа ще въведеш: ");
            int n = int.Parse(Console.ReadLine());

            int[] chisla = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write("Въведи число: ");
                chisla[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Числата са:");

            for (int i = n - 1; i >= 0; i--)
            {
                Console.WriteLine(chisla[i]);
            }

        }
    }
}
