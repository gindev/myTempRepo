﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("напишете число");
            int n = int.Parse(Console.ReadLine());
            int[] n2 = new int[n];

            Console.Write("напишете числа");
            for (int i = 0; i < n; i++)
            {

                Console.Write(" , ");
                n2[i]= int.Parse(Console.ReadLine());

            }
            Console.WriteLine("числата");


            for (int i = n; 0 <= n; n--)
            {
                Console.WriteLine(n2[i]);
            }
        }
    }
}
