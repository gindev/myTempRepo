﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<int>numbers = Console.ReadLine().Split(' ').Select(n=> int.Parse(n)).ToList();

            for (int i = numbers.Count -1 ; i >=0;  i--)
            {

                Console.Write(numbers[i] + " ");
            }
        }
    }
}
