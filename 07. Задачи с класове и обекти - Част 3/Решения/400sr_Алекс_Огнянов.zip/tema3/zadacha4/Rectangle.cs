﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Rectangle : Shape
    {
        private double width;
        private double height;

        public Rectangle(string n, double w, double h) : base(n)
        {
            this.width = w;
            this.height = h;
        }

        public override double CalculateArea() 
        {
            return width * height;
        }

        public override double CalculatePerimeter()
        {
            return 2 * (width + height);
        }
    }
}
