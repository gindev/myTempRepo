﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ширина на правоъгълник: ");
            double w = double.Parse(Console.ReadLine());
            Console.Write("Въведете височина на правоъгълник: ");
            double h = double.Parse(Console.ReadLine());

            Console.Write("Въведете радиус на окръжност: ");
            double r = double.Parse(Console.ReadLine());

            Rectangle rect = new Rectangle("Правоъгълник", w, h);
            Circle circle = new Circle("Окръжност", r);


            Console.WriteLine(rect.ToString());
            Console.WriteLine($"Лице: {rect.CalculateArea():F2}");
            Console.WriteLine($"Периметър: {rect.CalculatePerimeter():F2}");

            Console.WriteLine();

            Console.WriteLine(circle.ToString());
            Console.WriteLine($"Лице: {circle.CalculateArea():F2}");
            Console.WriteLine($"Периметър: {circle.CalculatePerimeter():F2}");
        }
    }
}
