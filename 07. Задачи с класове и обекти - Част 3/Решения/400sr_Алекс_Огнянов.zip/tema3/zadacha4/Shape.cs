﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha4
{
    internal abstract class Shape
    {
        protected string name; 

        public Shape(string n)
        {
            this.name = n;
        }

        public abstract double CalculateArea();
        public abstract double CalculatePerimeter();

        public override string ToString()
        {
            return "Фигура: " + name;
        }
    }
}
