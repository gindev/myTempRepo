﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Teacher : Person
    {
        private string discipline;
        private string academicTitle;

        public Teacher(string f, string l, int a, string d, string at)
            : base(f, l, a)
        {
            this.discipline = d;
            this.academicTitle = at;
        }

        public override void PrintInfo()
        {
            base.PrintInfo();
            Console.WriteLine($"Дисциплина: {discipline}");
            Console.WriteLine($"Академична длъжност: {academicTitle}");
        }
    }
}
