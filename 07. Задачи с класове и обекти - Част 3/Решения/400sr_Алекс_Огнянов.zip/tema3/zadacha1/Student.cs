﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Student : Person 
    {
        private string facultyNumber;
        private string specialty;

        public Student(string f, string l, int a, string fn, string s)
            : base(f, l, a)
        {
            this.facultyNumber = fn;
            this.specialty = s;
        }

        public override void PrintInfo() 
        {
            base.PrintInfo(); 
            Console.WriteLine($"Факултетен номер: {facultyNumber}");
            Console.WriteLine($"Специалност: {specialty}");
        }
    }
}