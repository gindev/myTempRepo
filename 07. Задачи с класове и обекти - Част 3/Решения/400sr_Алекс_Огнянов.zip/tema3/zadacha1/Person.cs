﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Person
    {
        protected string firstName;
        protected string lastName;
        protected int age;

        public Person(string f, string l, int a)
        {
            this.firstName = f;
            this.lastName = l;
            this.age = a;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"Име: {firstName}");
            Console.WriteLine($"Фамилия: {lastName}");
            Console.WriteLine($"Възраст: {age}");
        }
    }
}
