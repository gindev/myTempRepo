﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Въвеждане на данни за студент");
            Console.Write("Име: "); string sName = Console.ReadLine();
            Console.Write("Фамилия: "); string sLName = Console.ReadLine();
            Console.Write("Възраст: "); int sAge = int.Parse(Console.ReadLine());
            Console.Write("Фак. номер: "); string sNum = Console.ReadLine();
            Console.Write("Специалност: "); string sSpec = Console.ReadLine();

            Student student = new Student(sName, sLName, sAge, sNum, sSpec);

            Console.WriteLine("\nВъвеждане на данни за преподавател ");
            Console.Write("Име: "); string tName = Console.ReadLine();
            Console.Write("Фамилия: "); string tLName = Console.ReadLine();
            Console.Write("Възраст: "); int tAge = int.Parse(Console.ReadLine());
            Console.Write("Дисциплина: "); string tDisc = Console.ReadLine();
            Console.Write("Акад. длъжност: "); string tTitle = Console.ReadLine();

            Teacher teacher = new Teacher(tName, tLName, tAge, tDisc, tTitle);

            Console.WriteLine("\nИнформация за студент:");
            student.PrintInfo();

            Console.WriteLine("\nИнформация за преподавател:");
            teacher.PrintInfo();
        }
    }
}
