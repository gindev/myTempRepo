﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Employee
    {
        protected string name;
        protected decimal baseSalary;

        public Employee(string n, decimal bs)
        {
            this.name = n;
            this.baseSalary = bs;
        }

        public virtual decimal CalculateSalary()
        {
            return baseSalary;
        }

        public override string ToString()
        {
            return "Служител: " + name;
        }
    }
}
