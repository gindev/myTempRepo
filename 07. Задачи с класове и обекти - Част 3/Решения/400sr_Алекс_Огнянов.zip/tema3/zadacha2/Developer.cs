﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace zadacha2
{
    internal class Developer : Employee
    {
        private int overtimeHours;
        private decimal overtimeRate;

        public Developer(string n, decimal bs, int oh, decimal or) : base(n, bs)
        {
            this.overtimeHours = oh;
            this.overtimeRate = or;
        }

        public override decimal CalculateSalary()
        {
            return baseSalary + (overtimeHours * overtimeRate);
        }

        public override string ToString()
        {
            return "Разработчик: " + name;
        }
    }
}
