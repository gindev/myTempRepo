﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете име на мениджър: ");
            string mName = Console.ReadLine();
            Console.Write("Въведете основна заплата: ");
            decimal mSalary = decimal.Parse(Console.ReadLine());
            Console.Write("Въведете бонус: ");
            decimal mBonus = decimal.Parse(Console.ReadLine());

            Manager manager = new Manager(mName, mSalary, mBonus);

            Console.WriteLine();

            Console.Write("Въведете име на разработчик: ");
            string dName = Console.ReadLine();
            Console.Write("Въведете основна заплата: ");
            decimal dSalary = decimal.Parse(Console.ReadLine());
            Console.Write("Въведете брой извънредни часове: ");
            int dHours = int.Parse(Console.ReadLine());
            Console.Write("Въведете ставка за час: ");
            decimal dRate = decimal.Parse(Console.ReadLine());

            Developer dev = new Developer(dName, dSalary, dHours, dRate);

            Console.WriteLine(manager.ToString());
            Console.WriteLine($"Крайна заплата: {manager.CalculateSalary()}");

            Console.WriteLine();

            Console.WriteLine(dev.ToString());
            Console.WriteLine($"Крайна заплата: {dev.CalculateSalary()}");
        }
    }
}
