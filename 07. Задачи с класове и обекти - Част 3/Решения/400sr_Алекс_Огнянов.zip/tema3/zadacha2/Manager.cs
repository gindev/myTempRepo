﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha2
{
    internal class Manager : Employee 
    {
        private decimal bonus;

        public Manager(string n, decimal bs, decimal b) : base(n, bs)
        {
            this.bonus = b;
        }

        public override decimal CalculateSalary()
        {
            return baseSalary + bonus;
        }

        public override string ToString()
        {
            return "Мениджър: " + name;
        }
    }
}
