﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Motorcycle : Vehicle
    {
        private string motorType;

        public Motorcycle(string mk, string md, string mt) : base(mk, md)
        {
            this.motorType = mt;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Мотоциклет: {make} {model}, Тип: {motorType}");
        }
    }
}
