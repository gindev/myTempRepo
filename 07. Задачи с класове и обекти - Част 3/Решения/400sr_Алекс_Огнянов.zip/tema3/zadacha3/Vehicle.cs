﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Vehicle
    {
        protected string make;
        protected string model;

        public Vehicle(string mk, string md)
        {
            this.make = mk;
            this.model = md;
        }

        public virtual void ShowInfo()
        {
            Console.Write($"{make} {model}");
        }

        public override string ToString()
        {
            return make + " " + model;
        }
    }
}
