﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Car : Vehicle
    {
        private int doorCount;

        public Car(string mk, string md, int dc) : base(mk, md)
        {
            this.doorCount = dc;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Автомобил: {make} {model}, Брой врати: {doorCount}");
        }
    }
}
