﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha3
{
    internal class Truck : Vehicle
    {
        private double capacity;

        public Truck(string mk, string md, double c) : base(mk, md)
        {
            this.capacity = c;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Камион: {make} {model}, Товароносимост: {capacity} кг");
        }
    }
}
