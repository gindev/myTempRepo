﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Subscription : IPayable
    {
        protected string serviceName;
        protected decimal monthlyFee;
        protected int months;

        public Subscription(string service, decimal fee, int m)
        {
            this.serviceName = service;
            this.monthlyFee = fee;
            this.months = m;
        }

        public decimal GetPaymentAmount()
        {
            return monthlyFee * months;
        }

        // Коригиран формат според изображението
        public override string ToString() //[cite: 1, 2]
        {
            return $"Абонамент: {serviceName}, Сума: {GetPaymentAmount():F2} лв.";
        }
    }
}
