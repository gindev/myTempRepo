﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Invoice : IPayable
    {
        protected string invoiceNumber; //[cite: 1]
        protected decimal amount;

        public Invoice(string nr, decimal amt)
        {
            this.invoiceNumber = nr;
            this.amount = amt;
        }

        public decimal GetPaymentAmount()
        {
            return amount;
        }

        // Коригиран формат за съответствие с примерния изход
        public override string ToString() //[cite: 1, 2]
        {
            return $"Фактура №{invoiceNumber}: {amount:F2} лв.";
        }
    }
}
