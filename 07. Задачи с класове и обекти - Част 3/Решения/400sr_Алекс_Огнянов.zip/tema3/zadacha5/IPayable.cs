﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal interface IPayable
    {
        decimal GetPaymentAmount();
    }
}
