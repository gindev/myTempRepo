﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPayable> payments = new List<IPayable>();

            // Данни от примерния изход
            payments.Add(new Invoice("1001", 350.00M));
            payments.Add(new Invoice("1002", 120.00M));
            payments.Add(new Subscription("Интернет", 60.00M, 1));
            payments.Add(new Subscription("Софтуерен лиценз", 90.00M, 1));

            decimal totalSum = 0;

            // Обхождане и извеждане на информацията
            foreach (IPayable p in payments)
            {
                // Използваме пренаписания ToString() на всеки обект[cite: 1, 2]
                Console.WriteLine(p.ToString());

                // Натрупваме общата сума
                totalSum += p.GetPaymentAmount();
            }

            // Извеждане на общата сума в правилния формат
            Console.WriteLine($"\nОбща сума за плащане: {totalSum:F2} лв.");
        }
    }
}
