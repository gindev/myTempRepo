using System;
using System.Collections.Generic;

namespace OOPTasks
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}");
        }
    }

    class Student : Person
    {
        public string University { get; set; }

        public Student(string name, int age, string university)
            : base(name, age)
        {
            University = university;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Student -> Name: {Name}, Age: {Age}, University: {University}");
        }
    }

    class Teacher : Person
    {
        public string Subject { get; set; }

        public Teacher(string name, int age, string subject)
            : base(name, age)
        {
            Subject = subject;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Teacher -> Name: {Name}, Age: {Age}, Subject: {Subject}");
        }
    }

    class Employee
    {
        public string Name { get; set; }
        public double BaseSalary { get; set; }

        public Employee(string name, double baseSalary)
        {
            Name = name;
            BaseSalary = baseSalary;
        }

        public virtual double CalculateSalary()
        {
            return BaseSalary;
        }
    }

    class Manager : Employee
    {
        public double Bonus { get; set; }

        public Manager(string name, double baseSalary, double bonus)
            : base(name, baseSalary)
        {
            Bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return BaseSalary + Bonus;
        }
    }

    class Developer : Employee
    {
        public int OvertimeHours { get; set; }
        public double HourRate { get; set; }

        public Developer(string name, double baseSalary, int hours, double rate)
            : base(name, baseSalary)
        {
            OvertimeHours = hours;
            HourRate = rate;
        }

        public override double CalculateSalary()
        {
            return BaseSalary + (OvertimeHours * HourRate);
        }
    }

    class Vehicle
    {
        public string Brand { get; set; }

        public Vehicle(string brand)
        {
            Brand = brand;
        }

        public virtual void ShowInfo()
        {
            Console.WriteLine($"Vehicle brand: {Brand}");
        }
    }

    class Car : Vehicle
    {
        public int Doors { get; set; }

        public Car(string brand, int doors) : base(brand)
        {
            Doors = doors;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Car -> Brand: {Brand}, Doors: {Doors}");
        }
    }

    class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }

        public Motorcycle(string brand, bool sidecar) : base(brand)
        {
            HasSidecar = sidecar;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Motorcycle -> Brand: {Brand}, Sidecar: {HasSidecar}");
        }
    }

    class Truck : Vehicle
    {
        public double LoadCapacity { get; set; }

        public Truck(string brand, double capacity) : base(brand)
        {
            LoadCapacity = capacity;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Truck -> Brand: {Brand}, Capacity: {LoadCapacity} tons");
        }
    }

    abstract class Shape
    {
        public abstract double GetArea();
        public abstract double GetPerimeter();
    }

    class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double w, double h)
        {
            Width = w;
            Height = h;
        }

        public override double GetArea()
        {
            return Width * Height;
        }

        public override double GetPerimeter()
        {
            return 2 * (Width + Height);
        }
    }

    class Circle : Shape
    {
        public double Radius { get; set; }

        public Circle(double r)
        {
            Radius = r;
        }

        public override double GetArea()
        {
            return Math.PI * Radius * Radius;
        }

        public override double GetPerimeter()
        {
            return 2 * Math.PI * Radius;
        }
    }

    interface IPayable
    {
        double GetPaymentAmount();
    }

    class Invoice : IPayable
    {
        public string Product { get; set; }
        public int Quantity { get; set; }
        public double PricePerItem { get; set; }

        public Invoice(string product, int qty, double price)
        {
            Product = product;
            Quantity = qty;
            PricePerItem = price;
        }

        public double GetPaymentAmount()
        {
            return Quantity * PricePerItem;
        }
    }

    class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public double MonthlyFee { get; set; }
        public int Months { get; set; }

        public Subscription(string service, double fee, int months)
        {
            ServiceName = service;
            MonthlyFee = fee;
            Months = months;
        }

        public double GetPaymentAmount()
        {
            return MonthlyFee * Months;
        }
    }

    class Program
    {
        static void Main()
        {
            Person p = new Person("Ivan", 30);
            Student s = new Student("Maria", 20, "Sofia University");
            Teacher t = new Teacher("Petar", 45, "Math");

            p.PrintInfo();
            s.PrintInfo();
            t.PrintInfo();

            Employee m = new Manager("Boss", 2000, 500);
            Employee d = new Developer("Coder", 1500, 20, 25);

            Console.WriteLine(m.CalculateSalary());
            Console.WriteLine(d.CalculateSalary());
        }
    }
}
