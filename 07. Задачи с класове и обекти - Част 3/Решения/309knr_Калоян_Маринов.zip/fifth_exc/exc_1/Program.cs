﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter what type of person you would like to insert \n 1-student \n 2-teacher");
            int type = int.Parse(Console.ReadLine());

            Person person;

            if (type == 1)
            {
                Console.WriteLine("Enter the name of the student");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the surname of the student");
                string surname = Console.ReadLine();
                Console.WriteLine("Enter the age of the student");
                int age = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the faculty number of the student");
                string fk = Console.ReadLine();
                Console.WriteLine("Enter the specialty of the student");
                string sp = Console.ReadLine();

                person = new Student(name, surname, age, fk, sp);

            }
            else
            {
                Console.WriteLine("Enter the name of the teacher");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the surname of the teacher");
                string surname = Console.ReadLine();
                Console.WriteLine("Enter the age of the teacher");
                int age = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the subject the teacher teaches");
                string subject = Console.ReadLine();
                Console.WriteLine("Enter the academic position of the teacher");
                string ac = Console.ReadLine();

                person = new Teacher(name, surname, age, subject, ac);
            }
            person.PrintInfo();
        }
    }
}