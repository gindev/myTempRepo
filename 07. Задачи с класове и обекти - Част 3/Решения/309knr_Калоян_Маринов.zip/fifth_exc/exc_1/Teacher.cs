namespace Program
{
    class Teacher : Person
    {
        string subject;
        string acPos;

        public Teacher(string name,string surname, int age, string subject, string acPos)
            : base(name,surname, age)
        {
            this.subject = subject;
            this.acPos = acPos;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"{acPos} {name} {surname}, teaching {subject}");
        }
    }
}