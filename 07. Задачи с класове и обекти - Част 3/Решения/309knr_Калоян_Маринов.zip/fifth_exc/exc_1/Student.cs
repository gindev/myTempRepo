namespace Program
{
    public class Student : Person
    {
        string fkNum;
        string specialty;

        public Student(string name, string surname, int age, string fkNum, string specialty)
         : base(name, surname, age)
        {
            this.fkNum = fkNum;
            this.specialty = specialty;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"{name} {surname} {fkNum}, studing {specialty}");
        }
    }
}