namespace Program
{
    public class Person
    {
        protected string name;
        protected string surname;
        protected int age;


        public Person(string name, string surname, int age)
        {
            this.name = name;
            this.surname = surname;
            this.age = age;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"Hi, I am {name} {surname}, {age}, just a person");
        }
    }
}