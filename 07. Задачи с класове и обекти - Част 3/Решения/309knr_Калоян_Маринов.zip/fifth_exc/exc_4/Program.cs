﻿using System.Reflection.Metadata;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter what type of shape you would like to insert \n 1-rectangle \n 2-circle");
            int type = int.Parse(Console.ReadLine());

            Shape shape;
            if (type == 1)
            {
                Console.WriteLine("Enter the width of the rectangle");
                double width = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the height of the rectangle");
                double height = double.Parse(Console.ReadLine());

                shape = new Rectangle(width, height);
            }
            else
            {
                Console.WriteLine("Enter the radius of the circle");
                double radius = double.Parse(Console.ReadLine());
                shape = new Circle(radius);
            }
            Console.WriteLine($"{shape.name}:");
            Console.WriteLine($"Area = {shape.CalculateArea():F2}");
            Console.WriteLine($"Perimeter = {shape.CalculatePerimeter():F2}");
        }
    }
}