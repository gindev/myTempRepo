namespace Program
{
    abstract class Shape
    {
        public string name;

        public Shape(string name)
        {
            this.name = name;
        }

        public abstract double CalculateArea();
        public abstract double CalculatePerimeter();
    }

}