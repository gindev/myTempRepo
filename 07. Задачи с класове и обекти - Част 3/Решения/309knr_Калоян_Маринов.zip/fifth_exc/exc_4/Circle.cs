namespace Program
{
    class Circle : Shape
    {
        public double radius;

        public Circle(double radius)
            : base("Circle")
        {
            this.radius = radius;
        }

        public override double CalculateArea()
        {
            return Math.PI * (radius * radius);
        }

        public override double CalculatePerimeter()
        {
            return 2 * (Math.PI * radius);
        }
    }
}