namespace Program
{
    class Rectangle : Shape
    {
        public double width;
        public double height;

        public Rectangle(double width, double height)
            : base("Rectangle")
        {
            this.width = width;
            this.height = height;
        }

        public override double CalculateArea()
        {
            return width * height;
        }

        public override double CalculatePerimeter()
        {
            return 2 * (width + height);
        }
    }

}