namespace Program
{
    class Car : Vehicle
    {
        public int doors;

        public Car(string brand, string model, int doors)
            : base(brand, model)
        {
            this.doors = doors;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Car -> Brand: {brand}, Model: {model}, Doors: {doors}");
        }
    }
}