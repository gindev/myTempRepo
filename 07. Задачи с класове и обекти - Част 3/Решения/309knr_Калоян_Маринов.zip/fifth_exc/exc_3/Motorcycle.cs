namespace Program
{
    class Motorcycle : Vehicle
    {
        public string engineType;

        public Motorcycle(string brand, string model, string engineType)
            : base(brand, model)
        {
            this.engineType = engineType;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Motorcycle -> Brand: {brand}, Model: {model}, Motor type: {engineType}");
        }
    }
}