﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> vehicles = new List<Vehicle>();

            vehicles.Add(new Car("Toyota", "Corolla", 4));
            vehicles.Add(new Motorcycle("Yamaha", "R1", "sports"));
            vehicles.Add(new Truck("Volvo", "FH16", 20));

            foreach (var v in vehicles)
            {
                v.ShowInfo();
            }
        }
    }
}