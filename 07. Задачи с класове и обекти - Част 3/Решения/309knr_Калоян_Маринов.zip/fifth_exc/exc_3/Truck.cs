namespace Program
{
    class Truck : Vehicle
    {
        public double capacity;

        public Truck(string brand, string model, double capacity)
            : base(brand, model)
        {
            this.capacity = capacity;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Truck -> Brand: {brand}, Model: {model}, Capacity: {capacity} t");
        }
    }
}