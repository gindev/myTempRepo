namespace Program
{
    class Vehicle
    {
        public string brand;
        public string model;

        public Vehicle(string brand, string model)
        {
            this.brand = brand;
            this.model = model;
        }

        public virtual void ShowInfo()
        {
            Console.WriteLine($"Brand: {brand}, Model: {model}");
        }
    }

}