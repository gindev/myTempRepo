﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPayable> payments = new List<IPayable>();

            payments.Add(new Invoice("INV001", 300.00m));
            payments.Add(new Invoice("INV002", 120.00m));

            payments.Add(new Subscription("Netflix", 60.00m, 3));
            payments.Add(new Subscription("Spotify", 90.00m, 6));

            decimal total = 0;

            foreach (var item in payments)
            {
                total += item.GetPaymentAmount();
            }

            Console.WriteLine($"Total pay sum: {total}");
        }
    }
}