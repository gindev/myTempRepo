namespace Program
{
    public interface IPayable
    {
        decimal GetPaymentAmount();
    }
}