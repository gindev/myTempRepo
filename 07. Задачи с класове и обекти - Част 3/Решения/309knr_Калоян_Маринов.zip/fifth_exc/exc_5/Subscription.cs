namespace Program
{
    public class Subscription : IPayable
    {
        public string serviceName;
        public decimal monthlyFee;
        public int months;

        public Subscription(string serviceName, decimal monthlyFee, int months)
        {
            this.serviceName = serviceName;
            this.monthlyFee = monthlyFee;
            this.months = months;
        }

        public decimal GetPaymentAmount()
        {
            return monthlyFee * months;
        }
    }
}