namespace Program
{
    public class Invoice : IPayable
    {
        public string invoiceNumber;
        public decimal amount;

        public Invoice(string invoiceNumber, decimal amount)
        {
            this.invoiceNumber = invoiceNumber;
            this.amount = amount;
        }

        public decimal GetPaymentAmount()
        {
            return amount;
        }
}
}