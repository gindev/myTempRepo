namespace Program
{
    class Manager : Employee
    {
        public double bonus;

        public Manager(string name, double baseSalary, double bonus)
            : base(name, baseSalary)
        {
            this.bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return baseSalary + bonus;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Manager: {name}");
            Console.WriteLine($"End salaty: {CalculateSalary()}");
        }

    }
}