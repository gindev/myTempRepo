namespace Program
{
    class Employee
    {
        public string name;
        public double baseSalary;

        public Employee(string name, double baseSalary)
        {
            this.name = name;
            this.baseSalary = baseSalary;
        }

        public virtual double CalculateSalary()
        {
            return baseSalary;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine("Something");
        }
    }

}