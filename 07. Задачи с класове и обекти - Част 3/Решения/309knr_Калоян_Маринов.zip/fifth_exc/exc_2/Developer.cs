namespace Program
{
    class Developer : Employee
    {
        public int overtimeHours;
        public double hourRate;

        public Developer(string name, double baseSalary, int overtimeHours, double hourRate)
            : base(name, baseSalary)
        {
            this.overtimeHours = overtimeHours;
            this.hourRate = hourRate;
        }

        public override double CalculateSalary()
        {
            return baseSalary + (overtimeHours * hourRate);
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Developer: {name}");
            Console.WriteLine($"End salaty: {CalculateSalary()}");
        }
    }
}