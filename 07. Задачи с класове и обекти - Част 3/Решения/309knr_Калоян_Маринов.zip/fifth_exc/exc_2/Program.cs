﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter what type of person you would like to insert \n 1-manager \n 2-developer");
            int type = int.Parse(Console.ReadLine());
            Employee employee;

            if (type == 1)
            {
                Console.WriteLine("Enter the name of the manager");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the base salary of the manager");
                double baseSalary = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the bonus for the manager");
                double bonus = double.Parse(Console.ReadLine());
                employee = new Manager(name, baseSalary, bonus);
            }
            else
            {
                Console.WriteLine("Enter the name of the developer");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the base salary of the developer");
                double baseSalary = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the overtime hours of the developer");
                int oH = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the hour rate of the developer");
                double hR = double.Parse(Console.ReadLine());
                employee = new Developer(name, baseSalary, oH, hR);

            }
            // Manager manager = new Manager("Ivan", 3000, 800);
            // Developer developer = new Developer("Petar", 2500, 10, 20);

            // Console.WriteLine($"Manager salary: {manager.CalculateSalary()}");
            // Console.WriteLine($"Developer salary: {developer.CalculateSalary()}");
            employee.PrintInfo();
        }
    }
}