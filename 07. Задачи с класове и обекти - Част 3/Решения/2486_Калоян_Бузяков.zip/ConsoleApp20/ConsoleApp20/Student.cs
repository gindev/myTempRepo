﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    public class Student : Person
    {

        public int FakultetenNomer { get; set; }
        public string Specialnost { get; set; }

        public Student(string ime, string familiq, int vazrast, int fn, string specialnost)
            : base(ime, familiq, vazrast)
        {
            FakultetenNomer = fn;
            Specialnost = specialnost;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за студент:");
            base.PrintInfo();
            Console.WriteLine("Факултетен номер: " + FakultetenNomer);
            Console.WriteLine("Специалност: " + Specialnost);
        }

    }

}
