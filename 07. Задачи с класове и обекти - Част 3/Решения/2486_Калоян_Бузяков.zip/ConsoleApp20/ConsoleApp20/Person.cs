﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    public class Person
    {

        public string Ime { get; set; }
        public string Familiq { get; set; }
        public int Vazrast { get; set; }

        public Person(string ime, string familiq, int vazrast)
        {
            Ime = ime;
            Familiq = familiq;
            Vazrast = vazrast;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine("Име: " + Ime);
            Console.WriteLine("Фамилия: " + Familiq);
            Console.WriteLine("Възраст: " + Vazrast);
        }

    }
}
