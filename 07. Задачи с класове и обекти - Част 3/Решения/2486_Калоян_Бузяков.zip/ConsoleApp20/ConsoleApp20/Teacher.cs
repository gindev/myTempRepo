﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    public class Teacher : Person
    {

        public string Disciplina { get; set; }
        public string AkademichnaDlajnost { get; set; }

        public Teacher(string ime, string familiq, int vazrast, string disciplina, string dlajnost)
            : base(ime, familiq, vazrast)
        {
            Disciplina = disciplina;
            AkademichnaDlajnost = dlajnost;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за преподавател:");
            base.PrintInfo();
            Console.WriteLine("Дисциплина: " + Disciplina);
            Console.WriteLine("Академична длъжност: " + AkademichnaDlajnost);
        }

    }

}
