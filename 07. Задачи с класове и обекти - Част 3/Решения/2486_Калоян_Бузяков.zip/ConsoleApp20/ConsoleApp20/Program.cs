﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете име на студент: ");
            string sIme = Console.ReadLine();
            Console.Write("Въведете фамилия на студент: ");
            string sFam = Console.ReadLine();
            Console.Write("Въведете възраст на студент: ");
            int sVaz = int.Parse(Console.ReadLine());
            Console.Write("Въведете факултетен номер: ");
            int fn = int.Parse(Console.ReadLine());
            Console.Write("Въведете специалност: ");
            string spec = Console.ReadLine();

            Console.WriteLine();

            Console.Write("Въведете име на преподавател: ");
            string tIme = Console.ReadLine();
            Console.Write("Въведете фамилия на преподавател: ");
            string tFam = Console.ReadLine();
            Console.Write("Въведете възраст на преподавател: ");
            int tVaz = int.Parse(Console.ReadLine());
            Console.Write("Въведете дисциплина: ");
            string disc = Console.ReadLine();
            Console.Write("Въведете академична длъжност: ");
            string dlaj = Console.ReadLine();

            Console.WriteLine();

            Student student = new Student(sIme, sFam, sVaz, fn, spec);
            student.PrintInfo();

            Console.WriteLine();

            Teacher teacher = new Teacher(tIme, tFam, tVaz, disc, dlaj);
            teacher.PrintInfo();

        }
    }
}
