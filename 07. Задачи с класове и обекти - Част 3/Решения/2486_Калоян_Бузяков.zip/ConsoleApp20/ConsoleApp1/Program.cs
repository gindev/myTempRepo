﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Въведете име на мениджър: ");
            string mIme = Console.ReadLine();
            Console.Write("Въведете основна заплата: ");
            double mZap = double.Parse(Console.ReadLine());
            Console.Write("Въведете бонус: ");
            double bonus = double.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.Write("Въведете име на разработчик: ");
            string dIme = Console.ReadLine();
            Console.Write("Въведете основна заплата: ");
            double dZap = double.Parse(Console.ReadLine());
            Console.Write("Въведете брой извънредни часове: ");
            int chAsove = int.Parse(Console.ReadLine());
            Console.Write("Въведете ставка за час: ");
            double stavka = double.Parse(Console.ReadLine());

            Console.WriteLine();

            Manager m = new Manager(mIme, mZap, bonus);
            Console.WriteLine("Мениджър: " + m.Ime);
            Console.WriteLine("Крайна заплата: " + m.CalculateSalary());

            Console.WriteLine();

            Developer d = new Developer(dIme, dZap, chAsove, stavka);
            Console.WriteLine("Разработчик: " + d.Ime);
            Console.WriteLine("Крайна заплата: " + d.CalculateSalary());

        }

    }
}
