﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Developer : Employee
    {
        public int IzvandredniChasove { get; set; }
        public double StavkaZaChas { get; set; }

        public Developer(string ime, double zaplata, int chAsove, double stavka)
            : base(ime, zaplata)
        {
            IzvandredniChasove = chAsove;
            StavkaZaChas = stavka;
        }

        public override double CalculateSalary()
        {
            return OsnovnaZaplata + (IzvandredniChasove * StavkaZaChas);
        }

    }

}
