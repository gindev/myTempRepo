﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Manager : Employee
    {
        public double Bonus { get; set; }

        public Manager(string ime, double zaplata, double bonus)
            : base(ime, zaplata)
        {
            Bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return OsnovnaZaplata + Bonus;
        }

    }

}
