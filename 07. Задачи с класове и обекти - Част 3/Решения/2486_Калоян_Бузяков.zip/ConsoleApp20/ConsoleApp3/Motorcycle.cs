﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Motorcycle : Vehicle
    {

        public string TipNaMotora { get; set; }

        public Motorcycle(string marka, string model, string tip)
            : base(marka, model)
        {

            TipNaMotora = tip;

        }

        public override void ShowInfo()
        {

            Console.WriteLine("Мотоциклет: " + Marka + " " + Model
                + ", Тип: " + TipNaMotora);

        }

    }

}
