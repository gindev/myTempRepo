﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Car : Vehicle
    {

        public int BrojVrati { get; set; }

        public Car(string marka, string model, int vrati)
            : base(marka, model)
        {

            BrojVrati = vrati;

        }

        public override void ShowInfo()
        {

            Console.WriteLine("Автомобил: " + Marka + " " + Model
                + ", Брой врати: " + BrojVrati);

        }

    }

}
