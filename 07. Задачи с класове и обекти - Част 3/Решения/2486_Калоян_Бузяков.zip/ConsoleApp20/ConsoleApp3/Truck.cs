﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Truck : Vehicle
    {
        public double Tovaronossimost { get; set; }

        public Truck(string marka, string model, double tovar)
            : base(marka, model)
        {

            Tovaronossimost = tovar;

        }

        public override void ShowInfo()
        {

            Console.WriteLine("Камион: " + Marka + " " + Model
                + ", Товароносимост: " + Tovaronossimost + " кг");

        }

    }

}
