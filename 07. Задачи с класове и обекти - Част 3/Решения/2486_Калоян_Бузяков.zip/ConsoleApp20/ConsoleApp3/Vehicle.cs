﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Vehicle
    {
        public string Marka { get; set; }
        public string Model { get; set; }

        public Vehicle(string marka, string model)
        {
            Marka = marka;
            Model = model;
        }

        public virtual void ShowInfo()
        {
            Console.WriteLine("Превозно средство: " + Marka + " " + Model);
        }

    }

}
