﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> prevozni = new List<Vehicle>();

            prevozni.Add(new Car("Toyota", "Corolla", 4));
            prevozni.Add(new Motorcycle("Yamaha", "MT-07", "спортен"));
            prevozni.Add(new Truck("MAN", "TGX", 18000));

            foreach (Vehicle v in prevozni)
            {
                v.ShowInfo();
            }

        }
    }
}
