﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Subscription : IPayable
    {

        public string ImeNaUsluga { get; set; }
        public double MesechnaHaksa { get; set; }
        public int BrojMeseci { get; set; }

        public Subscription(string ime, double taksa, int meseci)
        {
            ImeNaUsluga = ime;
            MesechnaHaksa = taksa;
            BrojMeseci = meseci;
        }

        public double GetPaymentAmount()
        {
            return MesechnaHaksa * BrojMeseci;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Абонамент: " + ImeNaUsluga
                + ", Сума: " + GetPaymentAmount().ToString("F2") + " лв.");
        }

    }

}
