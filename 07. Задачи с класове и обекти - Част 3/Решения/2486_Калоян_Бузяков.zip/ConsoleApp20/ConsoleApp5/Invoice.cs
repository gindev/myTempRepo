﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Invoice : IPayable
    {

        public int Nomer { get; set; }
        public double Stojnost { get; set; }

        public Invoice(int nomer, double stojnost)
        {
            Nomer = nomer;
            Stojnost = stojnost;
        }

        public double GetPaymentAmount()
        {
            return Stojnost;
        }

        public void PrintInfo()
        {
            Console.WriteLine("Фактура #" + Nomer + ": "
                + Stojnost.ToString("F2") + " лв.");
        }

    }

}
