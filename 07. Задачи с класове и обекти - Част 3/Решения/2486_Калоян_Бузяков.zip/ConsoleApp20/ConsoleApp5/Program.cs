﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPayable> platenia = new List<IPayable>();

            Invoice inv1 = new Invoice(1001, 350.00);
            Invoice inv2 = new Invoice(1002, 120.00);
            Subscription sub1 = new Subscription("Интернет", 20.00, 3);
            Subscription sub2 = new Subscription("Софтуерен лиценз", 30.00, 3);

            platenia.Add(inv1);
            platenia.Add(inv2);
            platenia.Add(sub1);
            platenia.Add(sub2);

            inv1.PrintInfo();
            inv2.PrintInfo();
            sub1.PrintInfo();
            sub2.PrintInfo();

            double obshtaSuma = 0;
            foreach (IPayable p in platenia)
            {
                obshtaSuma += p.GetPaymentAmount();
            }

            Console.WriteLine();
            Console.WriteLine("Обща сума за плащане: " + obshtaSuma.ToString("F2") + " лв.");

        }
    }
}
