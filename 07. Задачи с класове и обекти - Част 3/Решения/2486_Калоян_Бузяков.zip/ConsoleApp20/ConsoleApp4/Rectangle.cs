﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Rectangle : Shape
    {
        public double Shirina { get; set; }
        public double Visochina { get; set; }

        public Rectangle(double shirina, double visochina)
            : base("Правоъгълник")
        {
            Shirina = shirina;
            Visochina = visochina;
        }

        public override double CalculateArea()
        {
            return Shirina * Visochina;
        }

        public override double CalculatePerimeter()
        {
            return 2 * (Shirina + Visochina);
        }
    }

}
