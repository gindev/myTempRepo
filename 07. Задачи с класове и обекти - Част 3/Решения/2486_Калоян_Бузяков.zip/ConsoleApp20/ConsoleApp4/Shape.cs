﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public abstract class Shape
    {
        public string ImeNaFigurata { get; set; }

        public Shape(string ime)
        {

            ImeNaFigurata = ime;

        }

        public abstract double CalculateArea();
        public abstract double CalculatePerimeter();

        public void PrintInfo()
        {

            Console.WriteLine("Фигура: " + ImeNaFigurata);
            Console.WriteLine("Лице: " + Math.Round(CalculateArea(), 2));
            Console.WriteLine("Периметър: " + Math.Round(CalculatePerimeter(), 2));

        }

    }

}
