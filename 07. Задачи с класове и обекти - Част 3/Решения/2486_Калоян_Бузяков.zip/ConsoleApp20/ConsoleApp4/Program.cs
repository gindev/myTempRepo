﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ширина на правоъгълник: ");
            double sh = double.Parse(Console.ReadLine());
            Console.Write("Въведете височина на правоъгълник: ");
            double vis = double.Parse(Console.ReadLine());

            Console.Write("Въведете радиус на окръжност: ");
            double r = double.Parse(Console.ReadLine());

            Console.WriteLine();

            Rectangle rect = new Rectangle(sh, vis);
            rect.PrintInfo();

            Console.WriteLine();

            Circle circle = new Circle(r);
            circle.PrintInfo();

        }
    }
}
