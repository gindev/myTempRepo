﻿namespace zadacha1
{
    using System;

    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"First Name: {FirstName}");
            Console.WriteLine($"Last Name: {LastName}");
            Console.WriteLine($"Age: {Age}");
        }
    }

    class Student : Person
    {
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }

        public Student(string firstName, string lastName, int age, string facultyNumber, string specialty)
            : base(firstName, lastName, age)
        {
            FacultyNumber = facultyNumber;
            Specialty = specialty;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Student Information:");
            base.PrintInfo();
            Console.WriteLine($"Faculty Number: {FacultyNumber}");
            Console.WriteLine($"Specialty: {Specialty}");
        }
    }

    class Teacher : Person
    {
        public string Subject { get; set; }
        public string AcademicTitle { get; set; }

        public Teacher(string firstName, string lastName, int age, string subject, string academicTitle)
            : base(firstName, lastName, age)
        {
            Subject = subject;
            AcademicTitle = academicTitle;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("\nTeacher Information:");
            base.PrintInfo();
            Console.WriteLine($"Subject: {Subject}");
            Console.WriteLine($"Academic Title: {AcademicTitle}");
        }
    }

    class Program
    {
        static void Main()
        {
            
            Console.Write("Enter student's first name: ");
            string sFirstName = Console.ReadLine();

            Console.Write("Enter student's last name: ");
            string sLastName = Console.ReadLine();

            Console.Write("Enter student's age: ");
            int sAge = int.Parse(Console.ReadLine());

            Console.Write("Enter faculty number: ");
            string facultyNumber = Console.ReadLine();

            Console.Write("Enter specialty: ");
            string specialty = Console.ReadLine();

            Student student = new Student(sFirstName, sLastName, sAge, facultyNumber, specialty);

            
            Console.Write("\nEnter teacher's first name: ");
            string tFirstName = Console.ReadLine();

            Console.Write("Enter teacher's last name: ");
            string tLastName = Console.ReadLine();

            Console.Write("Enter teacher's age: ");
            int tAge = int.Parse(Console.ReadLine());

            Console.Write("Enter subject: ");
            string subject = Console.ReadLine();

            Console.Write("Enter academic title: ");
            string title = Console.ReadLine();

            Teacher teacher = new Teacher(tFirstName, tLastName, tAge, subject, title);

            Console.WriteLine();
            student.PrintInfo();
            teacher.PrintInfo();
        }
    }
}
