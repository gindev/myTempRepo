﻿namespace zadacha2
{
    using System;

    class Employee
    {
        public string Name { get; set; }
        public double BaseSalary { get; set; }

        public Employee(string name, double baseSalary)
        {
            Name = name;
            BaseSalary = baseSalary;
        }

        public virtual double CalculateSalary()
        {
            return BaseSalary;
        }
    }

    class Manager : Employee
    {
        public double Bonus { get; set; }

        public Manager(string name, double baseSalary, double bonus)
            : base(name, baseSalary)
        {
            Bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return BaseSalary + Bonus;
        }
    }

    class Developer : Employee
    {
        public int OvertimeHours { get; set; }
        public double HourlyRate { get; set; }

        public Developer(string name, double baseSalary, int overtimeHours, double hourlyRate)
            : base(name, baseSalary)
        {
            OvertimeHours = overtimeHours;
            HourlyRate = hourlyRate;
        }

        public override double CalculateSalary()
        {
            return BaseSalary + (OvertimeHours * HourlyRate);
        }
    }

    class Program
    {
        static void Main()
        {
            
            Console.Write("Enter manager name: ");
            string managerName = Console.ReadLine();

            Console.Write("Enter base salary: ");
            double managerBaseSalary = double.Parse(Console.ReadLine());

            Console.Write("Enter bonus: ");
            double bonus = double.Parse(Console.ReadLine());

            Manager manager = new Manager(managerName, managerBaseSalary, bonus);

            Console.WriteLine();

            Console.Write("Enter developer name: ");
            string developerName = Console.ReadLine();

            Console.Write("Enter base salary: ");
            double developerBaseSalary = double.Parse(Console.ReadLine());

            Console.Write("Enter overtime hours: ");
            int overtimeHours = int.Parse(Console.ReadLine());

            Console.Write("Enter hourly rate: ");
            double hourlyRate = double.Parse(Console.ReadLine());

            Developer developer = new Developer(developerName, developerBaseSalary, overtimeHours, hourlyRate);

            Console.WriteLine();

           
            Console.WriteLine($"Manager: {manager.Name}");
            Console.WriteLine($"Final Salary: {manager.CalculateSalary()}");

            Console.WriteLine();

            Console.WriteLine($"Developer: {developer.Name}");
            Console.WriteLine($"Final Salary: {developer.CalculateSalary()}");
        }
    }
}
