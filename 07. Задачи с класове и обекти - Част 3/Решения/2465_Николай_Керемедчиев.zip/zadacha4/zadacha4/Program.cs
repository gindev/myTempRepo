﻿namespace zadacha4
{
    using System;

    namespace ShapesApp
    {
        
        abstract class Shape
        {
            public string Name { get; set; }

            public Shape(string name)
            {
                Name = name;
            }

            public abstract double CalculateArea();
            public abstract double CalculatePerimeter();
        }

        
        class Rectangle : Shape
        {
            public double Width { get; set; }
            public double Height { get; set; }

            public Rectangle(double width, double height)
                : base("Rectangle")
            {
                Width = width;
                Height = height;
            }

            public override double CalculateArea()
            {
                return Width * Height;
            }

            public override double CalculatePerimeter()
            {
                return 2 * (Width + Height);
            }
        }

        
        class Circle : Shape
        {
            public double Radius { get; set; }

            public Circle(double radius)
                : base("Circle")
            {
                Radius = radius;
            }

            public override double CalculateArea()
            {
                return Math.PI * Radius * Radius;
            }

            public override double CalculatePerimeter()
            {
                return 2 * Math.PI * Radius;
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                
                Console.Write("Enter rectangle width: ");
                double width = double.Parse(Console.ReadLine());

                Console.Write("Enter rectangle height: ");
                double height = double.Parse(Console.ReadLine());

                Console.Write("Enter circle radius: ");
                double radius = double.Parse(Console.ReadLine());

                
                Shape rectangle = new Rectangle(width, height);
                Shape circle = new Circle(radius);

                
                Console.WriteLine($"\nShape: {rectangle.Name}");
                Console.WriteLine($"Area: {rectangle.CalculateArea():F2}");
                Console.WriteLine($"Perimeter: {rectangle.CalculatePerimeter():F2}");

                
                Console.WriteLine($"\nShape: {circle.Name}");
                Console.WriteLine($"Area: {circle.CalculateArea():F2}");
                Console.WriteLine($"Perimeter: {circle.CalculatePerimeter():F2}");
            }
        }
    }
}
