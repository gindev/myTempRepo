﻿namespace zadacha3
{
    using System;
    using System.Collections.Generic;

    
    class Vehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }

        public Vehicle(string brand, string model)
        {
            Brand = brand;
            Model = model;
        }

        
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Vehicle: {Brand} {Model}");
        }
    }

    
    class Car : Vehicle
    {
        public int Doors { get; set; }

        public Car(string brand, string model, int doors)
            : base(brand, model)
        {
            Doors = doors;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Car: {Brand} {Model}, Doors: {Doors}");
        }
    }

    
    class Motorcycle : Vehicle
    {
        public string EngineType { get; set; }

        public Motorcycle(string brand, string model, string engineType)
            : base(brand, model)
        {
            EngineType = engineType;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Motorcycle: {Brand} {Model}, Engine Type: {EngineType}");
        }
    }

    
    class Truck : Vehicle
    {
        public int LoadCapacity { get; set; }

        public Truck(string brand, string model, int loadCapacity)
            : base(brand, model)
        {
            LoadCapacity = loadCapacity;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Truck: {Brand} {Model}, Load Capacity: {LoadCapacity} kg");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            List<Vehicle> vehicles = new List<Vehicle>();

            
            vehicles.Add(new Car("Toyota", "Corolla", 4));
            vehicles.Add(new Motorcycle("Yamaha", "MT-07", "Sport"));
            vehicles.Add(new Truck("MAN", "TGX", 18000));

            foreach (Vehicle v in vehicles)
            {
                v.ShowInfo();
            }
        }
    }
}
