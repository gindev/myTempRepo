﻿namespace zadacha5
{
    using System;
    using System.Collections.Generic;

    public interface IPayable
    {
        decimal GetPaymentAmount();
        string GetDescription();
    }

    public class Invoice : IPayable
    {
        public string InvoiceNumber { get; set; }
        public decimal Amount { get; set; }

        public Invoice(string invoiceNumber, decimal amount)
        {
            InvoiceNumber = invoiceNumber;
            Amount = amount;
        }

        public decimal GetPaymentAmount()
        {
            return Amount;
        }

        public string GetDescription()
        {
            return $"Invoice #{InvoiceNumber}: {Amount:F2} lv.";
        }
    }

    public class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public decimal MonthlyFee { get; set; }
        public int Months { get; set; }

        public Subscription(string serviceName, decimal monthlyFee, int months)
        {
            ServiceName = serviceName;
            MonthlyFee = monthlyFee;
            Months = months;
        }

        public decimal GetPaymentAmount()
        {
            return MonthlyFee * Months;
        }

        public string GetDescription()
        {
            return $"Subscription: {ServiceName}, Amount: {GetPaymentAmount():F2} lv.";
        }
    }

    class Program
    {
        static void Main()
        {
            List<IPayable> payables = new List<IPayable>
        {
            new Invoice("1001", 350.00m),
            new Invoice("1002", 120.00m),
            new Subscription("Internet", 20.00m, 3),
            new Subscription("Software License", 30.00m, 3)
        };

            decimal total = 0;

            foreach (var item in payables)
            {
                Console.WriteLine(item.GetDescription());
                total += item.GetPaymentAmount();
            }

            Console.WriteLine();
            Console.WriteLine($"Total payment amount: {total:F2} lv.");
        }
    }
}
