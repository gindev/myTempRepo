﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_04
{
    abstract class Shape
    {
        public string Name { get; set; }
        public abstract double CalculateArea();
        public abstract double CalculatePerimeter();
    }
}
