﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ширина на правоъгълник: ");
            double width = double .Parse(Console.ReadLine());

            Console.Write("Въведете височина на правоъгълник: ");
            double height = double .Parse(Console.ReadLine());

            Rectangle rect = new Rectangle
            {
                Name = "Правоъгълник",
                Width = width,
                Height = height,
            };

            Console.WriteLine();


            Console.Write("Въведете радиус на окръжност: ");
            double radius = double .Parse(Console.ReadLine());

            Circle circle = new Circle
            {
                Name = "Окръжност",
                Radius = radius,
            };

            Console.WriteLine();

            Console.WriteLine($"Фигура: {rect.Name}");
            Console.WriteLine($"Лице: {rect.CalculateArea():F0}");
            Console.WriteLine($"Периметър: {rect.CalculatePerimeter():F0}");

            Console.WriteLine();

            Console.WriteLine($"Фигура: {circle.Name}");
            Console.WriteLine($"Лице: {circle.CalculateArea():F2}");
            Console.WriteLine($"Периметър: {circle.CalculatePerimeter():F2}");
        }
    }
}
