﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_03
{
    internal class Vehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Brand: {Brand}, Model: {Model}");
        }
    }

}
