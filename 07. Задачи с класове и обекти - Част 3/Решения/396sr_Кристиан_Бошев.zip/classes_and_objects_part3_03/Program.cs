﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> vehicles = new List<Vehicle>();

            vehicles.Add(new Car { Brand = "Toyota", Model = "Corolla", NumberOfDoors = 4 });
            vehicles.Add(new Motorcycle { Brand = "Yamaha", Model = "MT-07", Type = "спортен" });
            vehicles.Add(new Truck { Brand = "MAN", Model = "TGX", LoadCapacity = 18000 });
            foreach (Vehicle v in vehicles)
            {
                v.ShowInfo();
            }
        }
    }
}
