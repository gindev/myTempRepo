﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_03
{
    internal class Truck : Vehicle
    {
        public double LoadCapacity { get; set; }
        public override void ShowInfo()
        {
            Console.WriteLine($"Камион: {Brand} {Model}, Товароподемност: {LoadCapacity} кг");
        }
    }
}
