﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_03
{
    internal class Motorcycle : Vehicle
    {
        public string Type { get; set; }
        public override void ShowInfo()
        {
            Console.WriteLine($"Мотоциклет: {Brand} {Model}, Тип: {Type}");
        }
    }
}
