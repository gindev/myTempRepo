﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_03
{
    internal class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }
        public override void ShowInfo()
        {
            Console.WriteLine($"Автомобил: {Brand} {Model}, Брой врати: {NumberOfDoors}");
        }
    }
}
