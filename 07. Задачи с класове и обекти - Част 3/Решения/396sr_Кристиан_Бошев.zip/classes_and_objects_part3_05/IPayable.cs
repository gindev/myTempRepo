﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_05
{
    interface IPayable
    {
        decimal GetPaymentAmount();
    }
}
