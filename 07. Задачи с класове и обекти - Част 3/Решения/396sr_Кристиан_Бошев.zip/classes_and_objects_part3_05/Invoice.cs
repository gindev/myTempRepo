﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_05
{
    internal class Invoice : IPayable
    {
        public int InvoiceNumber { get; set; }
        public decimal InvoiceAmount { get; set; }

        public decimal GetPaymentAmount()
        {
            return InvoiceAmount;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Фактура №{InvoiceNumber}: {InvoiceAmount:F2} лв.");
        }
    }
}