﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_05
{
    internal class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public decimal MonthlyFee { get; set; }
        public int Months { get; set; }

        public decimal GetPaymentAmount()
        {
            return MonthlyFee * Months;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Абонамент: {ServiceName}, Сума: {GetPaymentAmount():F2} лв.");
        }
    }
}
