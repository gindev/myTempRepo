﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPayable> payments = new List<IPayable>();

            payments.Add(new Invoice { InvoiceNumber = 1001, InvoiceAmount = 350 });
            payments.Add(new Invoice { InvoiceNumber = 1002, InvoiceAmount = 120 });

            payments.Add(new Subscription { ServiceName = "Интернет", MonthlyFee = 20, Months = 3 });
            payments.Add(new Subscription { ServiceName = "Софтуерен лиценз", MonthlyFee = 30, Months = 3 });

            decimal total = 0;

            foreach (IPayable item in payments)
            {
                if (item is Invoice invoice)
                {
                    invoice.PrintInfo();
                }
                else if (item is Subscription sub)
                {
                    sub.PrintInfo();
                }

                total += item.GetPaymentAmount();
            }

            Console.WriteLine($"\nОбща сума за плащане: {total:F2} лв.");
        }
    }
}
