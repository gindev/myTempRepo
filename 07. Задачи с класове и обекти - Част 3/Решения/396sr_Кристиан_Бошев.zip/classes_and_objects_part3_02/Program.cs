﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете име на мениджър: ");
            string ManagerName = Console.ReadLine();

            Console.Write("Въведете основна заплата: ");
            decimal ManagerSalary = decimal.Parse(Console.ReadLine());

            Console.Write("Въведете бонус: ");
            decimal bonus = decimal.Parse(Console.ReadLine());

            Manager m1 = new Manager
            {
                Name = ManagerName,
                BaseSalary = ManagerSalary,
                Bonus = bonus
            };

            Console.WriteLine();

            Console.Write("Въведете име на разработчик: ");
            string DeveloperName = Console.ReadLine();

            Console.Write("Въведете основна заплата: ");
            decimal DeveloperSalary = decimal.Parse(Console.ReadLine());

            Console.Write("Въведете брой извънредни часове: ");
            int hours = int.Parse(Console.ReadLine());

            Console.Write("Въведете ставка за час: ");
            decimal rate = decimal.Parse(Console.ReadLine());

            Developer d1 = new Developer
            {
                Name = DeveloperName,
                BaseSalary = DeveloperSalary,
                OvertimeHours = hours,
                OvertimeRate = rate
            };

            Console.WriteLine();

            Console.WriteLine($"Мениджър: {m1.Name}");
            Console.WriteLine($"Крайна заплата: {m1.CalculateSalary()}");

            Console.WriteLine();

            Console.WriteLine($"Разработчик: {d1.Name}");
            Console.WriteLine($"Крайна заплата: {d1.CalculateSalary()}");
        }
    }
}
