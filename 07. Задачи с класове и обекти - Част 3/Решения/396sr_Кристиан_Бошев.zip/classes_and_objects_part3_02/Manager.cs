﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_02
{
    internal class Manager : Employee
    {
        public decimal Bonus { get; set; }
        public override decimal CalculateSalary()
        {
            return BaseSalary + Bonus;
        }
    }
}
