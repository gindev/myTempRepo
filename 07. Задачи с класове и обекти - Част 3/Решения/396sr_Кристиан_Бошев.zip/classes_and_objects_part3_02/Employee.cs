﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_02
{
    internal class Employee
    {
        public string Name { get; set; }
        public decimal BaseSalary { get; set; }
        public virtual decimal CalculateSalary()
        {
            return BaseSalary;
        }
    }
}
