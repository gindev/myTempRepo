﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_01
{
    internal class Student:Person
    {
        public string FacultyNumber { get; set; }
        public string UniversityMajor { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine("Информация за студент:");
            Console.WriteLine($"Име: {Name}");
            Console.WriteLine($"Фамилия: {Surname}");
            Console.WriteLine($"Възраст: {Age}");
            Console.WriteLine($"Факултетен номер: {FacultyNumber}");
            Console.WriteLine($"Специалност: {UniversityMajor}");
        }
    }
}
