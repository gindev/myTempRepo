﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_01
{
    internal class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Age { get; set; }
    }
}
