﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();

            Console.WriteLine("Въведете име на студент: ");
            s1.Name = Console.ReadLine();

            Console.WriteLine("Въведете фамилия на студент: ");
            s1.Surname = Console.ReadLine();

            Console.WriteLine("Въведете възраст на студент: ");
            s1.Age = Console.ReadLine();

            Console.WriteLine("Въведете факултетен номер: ");
            s1.FacultyNumber = Console.ReadLine();

            Console.WriteLine("Въведете специалност: ");
            s1.UniversityMajor = Console.ReadLine();


            Teacher t1 = new Teacher();

            Console.WriteLine($"\nВъведете име на преподавател: ");
            t1.Name = Console.ReadLine();

            Console.WriteLine($"Въведете фамилия на преподавател: ");
            t1.Surname = Console.ReadLine();

            Console.WriteLine($"Въведете възраст на преподавател: ");
            t1.Age = Console.ReadLine();

            Console.WriteLine($"Въведете дисциплина: ");
            t1.Discipline = Console.ReadLine();

            Console.WriteLine($"Въведете академична длъжност: ");
            t1.AcademyPosition = Console.ReadLine();
            
            s1.PrintInfo();

            Console.WriteLine();

            t1.PrintInfo();
        }

    }
}
