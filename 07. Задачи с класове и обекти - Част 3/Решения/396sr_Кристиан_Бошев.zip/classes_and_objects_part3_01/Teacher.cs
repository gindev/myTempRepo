﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_objects_part3_01
{
    internal class Teacher:Person
    {
        public string Discipline { get; set; }
        public string AcademyPosition { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine("Информация за преподавател:");
            Console.WriteLine($"Име: {Name}");
            Console.WriteLine($"Фамилия: {Surname}");
            Console.WriteLine($"Възраст: {Age}");
            Console.WriteLine($"Дисциплина: {Discipline}");
            Console.WriteLine($"Академична длъжност: {AcademyPosition}");
        }
    }
}
