﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class Motorcycle : Vehicle
    {
        public string MotorcycleType { get; set; }

        public Motorcycle(string brand, string model, string motorcycleType)
            : base(brand, model)
        {
            MotorcycleType = motorcycleType;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Мотоциклет: {Brand} {Model}, Тип: {MotorcycleType}");
        }

    }
}
