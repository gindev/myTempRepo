﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }

        public Car(string brand, string model, int numberOfDoors)
            : base(brand, model)
        {
            NumberOfDoors = numberOfDoors;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Автомобил: {Brand} {Model}, Брой врати: {NumberOfDoors}");
        }

    }
}
