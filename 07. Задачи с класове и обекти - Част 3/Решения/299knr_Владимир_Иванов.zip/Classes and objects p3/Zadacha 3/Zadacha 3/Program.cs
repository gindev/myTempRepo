﻿using Zadacha_3;

List<Vehicle> vehicles = new List<Vehicle>
        {
            new Car("Toyota", "Corolla", 4),
            new Motorcycle("Yamaha", "MT-07", "sporten"),
            new Truck("MAN", "TGX", 18000)
        };

foreach (Vehicle vehicle in vehicles)
{
    vehicle.ShowInfo();
}
