﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_3
{
    internal class Truck : Vehicle
    {
        public double LoadCapacity { get; set; }

        public Truck(string brand, string model, double loadCapacity)
            : base(brand, model)
        {
            LoadCapacity = loadCapacity;
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Камион: {Brand} {Model}, Товароносимост: {LoadCapacity} кг");
        }

    }
}
