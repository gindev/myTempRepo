﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal class Invoice : IPayable
    {
        public string InvoiceNumber { get; set; }
        public double Amount { get; set; }

        public Invoice(string invoiceNumber, double amount)
        {
            InvoiceNumber = invoiceNumber;
            Amount = amount;
        }

        public double GetPaymentAmount()
        {
            return Amount;
        }

        public override string ToString()
        {
            return $"Фактура №{InvoiceNumber}: {Amount:F2} лв.";
        }

    }
}
