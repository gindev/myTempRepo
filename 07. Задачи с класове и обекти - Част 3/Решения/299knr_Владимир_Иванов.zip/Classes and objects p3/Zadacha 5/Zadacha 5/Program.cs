﻿using Zadacha_5;

List<IPayable> payments = new List<IPayable>
        {
            new Invoice("1001", 350.00),
            new Invoice("1002", 120.00),
            new Subscription("Интернет", 60.00, 1),
            new Subscription("Софтуерен лиценз", 90.00, 1)
        };

double totalAmount = 0;

foreach (IPayable payment in payments)
{
    Console.WriteLine(payment.ToString());
    totalAmount += payment.GetPaymentAmount();
}

Console.WriteLine();
Console.WriteLine($"Обща сума за плащане: {totalAmount:F2} лв.");
