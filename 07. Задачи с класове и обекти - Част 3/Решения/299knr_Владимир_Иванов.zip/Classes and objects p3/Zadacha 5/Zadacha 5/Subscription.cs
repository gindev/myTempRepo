﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public double MonthlyFee { get; set; }
        public int NumberOfMonths { get; set; }

        public Subscription(string serviceName, double monthlyFee, int numberOfMonths)
        {
            ServiceName = serviceName;
            MonthlyFee = monthlyFee;
            NumberOfMonths = numberOfMonths;
        }

        public double GetPaymentAmount()
        {
            return MonthlyFee * NumberOfMonths;
        }
        public override string ToString()
        {
            return $"Абонамент: {ServiceName}, Сума: {GetPaymentAmount():F2} лв.";
        }

    }
}
