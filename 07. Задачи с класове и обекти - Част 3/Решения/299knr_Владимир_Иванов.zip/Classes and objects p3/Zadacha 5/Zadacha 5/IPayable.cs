﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_5
{
    internal interface IPayable
    {
        double GetPaymentAmount();
    }
}
