﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_4
{
    abstract class Shape
    {
        public string Name { get; set; }

        public Shape(string name)
        {
            Name = name;
        }

        public abstract double CalculateArea();
        public abstract double CalculatePerimeter();

        public void PrintInfo()
        {
            Console.WriteLine($"Фигура: {Name}");
            Console.WriteLine($"Лице: {CalculateArea():F2}");
            Console.WriteLine($"Периметър: {CalculatePerimeter():F2}");
        }

    }
}
