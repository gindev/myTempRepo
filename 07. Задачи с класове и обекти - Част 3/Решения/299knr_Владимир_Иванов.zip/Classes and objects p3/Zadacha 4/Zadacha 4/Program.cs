﻿using Zadacha_4;

Console.Write("Въведете ширина на правоъгълник: "); double width = double.Parse(Console.ReadLine());
Console.Write("Въведете височина на правоъгълник: "); double height = double.Parse(Console.ReadLine());

Console.Write("Въведете радиус на окръжност: "); double radius = double.Parse(Console.ReadLine());

Rectangle rect = new Rectangle(width, height);
Circle circle = new Circle(radius);

Console.WriteLine();
rect.PrintInfo();
Console.WriteLine();
circle.PrintInfo();
