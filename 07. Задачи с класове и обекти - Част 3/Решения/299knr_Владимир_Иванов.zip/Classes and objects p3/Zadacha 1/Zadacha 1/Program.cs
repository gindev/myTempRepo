﻿using Zadacha_1;

Console.Write("Въведете име на студент: "); string firstName = Console.ReadLine();
Console.Write("Въведете фамилия на студент: "); string lastName = Console.ReadLine();
Console.Write("Въведете възраст на студент: "); int age = int.Parse(Console.ReadLine());
Console.Write("Въведете факултетен номер: "); string facultyNumber = Console.ReadLine();
Console.Write("Въведете специалност: "); string specialty = Console.ReadLine();

Student student = new Student(firstName, lastName, age, facultyNumber, specialty);

Console.WriteLine();
Console.Write("Въведете име на преподавател: "); string firstName2 = Console.ReadLine();
Console.Write("Въведете фамилия на преподавател: "); string lastName2 = Console.ReadLine();
Console.Write("Въведете възраст на преподавател: "); int age2 = int.Parse(Console.ReadLine());
Console.Write("Въведете дисциплина: "); string subject = Console.ReadLine();
Console.Write("Въведете академична длъжност: "); string academicTitle = Console.ReadLine();

Teacher teacher = new Teacher(firstName2, lastName2, age2, subject, academicTitle);

Console.WriteLine();
student.PrintInfo();
Console.WriteLine();
teacher.PrintInfo();
