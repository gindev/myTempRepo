﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Student : Person
    {
        public string FacultyNumber { get; set; }
        public string Specialty { get; set; }

        public Student(string firstName, string lastName, int age, string facultyNumber, string specialty)
            : base(firstName, lastName, age)
        {
            FacultyNumber = facultyNumber;
            Specialty = specialty;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за студент:");
            base.PrintInfo();
            Console.WriteLine($"Факултетен номер: {FacultyNumber}");
            Console.WriteLine($"Специалност: {Specialty}");
        }

    }
}
