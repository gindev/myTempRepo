﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_1
{
    internal class Teacher : Person
    {
        public string Subject { get; set; }
        public string AcademicTitle { get; set; }

        public Teacher(string firstName, string lastName, int age, string subject, string academicTitle)
            : base(firstName, lastName, age)
        {
            Subject = subject;
            AcademicTitle = academicTitle;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за преодавател:");
            base.PrintInfo();
            Console.WriteLine($"Дисциплина: {Subject}");
            Console.WriteLine($"Академична длъжност: {AcademicTitle}");
        }
    }
}
