﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Zadacha_2
{
    internal class Developer : Employee
    {
        public int OvertimeHours { get; set; }
        public double HourlyRate { get; set; }

        public Developer(string name, double baseSalary, int overtimeHours, double hourlyRate)
        : base(name, baseSalary)
        {
            OvertimeHours = overtimeHours;
            HourlyRate = hourlyRate;
        }
        public override double CalculateSalary()
        {
            return BaseSalary + OvertimeHours * HourlyRate;
        }

    }
}
