﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    internal class Manager : Employee
    {
        public double Bonus { get; set; }

        public Manager(string name, double baseSalary, double bonus)
            : base(name, baseSalary)
        {
            Bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return BaseSalary + Bonus;
        }

    }
}
