﻿using Zadacha_2;

Console.Write("Въведете име на мениджър: "); string managerName = Console.ReadLine();
Console.Write("Въведете основна заплата: "); double baseSalary1 = double.Parse(Console.ReadLine());
Console.Write("Въведете бонус: "); double bonus = double.Parse(Console.ReadLine());

Manager manager = new Manager(managerName, baseSalary1, bonus);

Console.WriteLine();
Console.Write("Въведете име на разработчик: "); string developerName = Console.ReadLine();
Console.Write("Въведете основна заплата: "); double baseSalary2 = double.Parse(Console.ReadLine());
Console.Write("Въведете брой извънредни часове: "); int overtimeHours = int.Parse(Console.ReadLine());
Console.Write("Въведете ставка за час: "); double hourlyRate = double.Parse(Console.ReadLine());

Developer developer = new Developer(developerName, baseSalary2, overtimeHours, hourlyRate);

Console.WriteLine();
Console.WriteLine($"Мениджър: {manager.Name}");
Console.WriteLine($"Крайна заплата: {manager.CalculateSalary()}");
Console.WriteLine();
Console.WriteLine($"Разработчик: {developer.Name}");
Console.WriteLine($"Крайна заплата: {developer.CalculateSalary()}");
