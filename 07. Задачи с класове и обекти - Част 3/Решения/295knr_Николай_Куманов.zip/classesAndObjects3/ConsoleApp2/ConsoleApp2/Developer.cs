﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Developer : Employee
    {
        public int OvertimeHours { get; set; }
        public decimal OvertimeRate { get; set; }

        public Developer(string name, decimal baseSalary, int overtimeHours, decimal overtimeRate)
            : base(name, baseSalary)
        {
            OvertimeHours = overtimeHours;
            OvertimeRate = overtimeRate;
        }

        public override decimal CalculateSalary()
        {
            return BaseSalary + (OvertimeHours * OvertimeRate);
        }
    }
}
