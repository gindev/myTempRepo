﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Manager : Employee
    {
        public decimal Bonus { get; set; }

        public Manager(string name, decimal baseSalary, decimal bonus)
            : base(name, baseSalary)
        {
            Bonus = bonus;
        }

        public override decimal CalculateSalary()
        {
            return BaseSalary + Bonus;
        }
    }
}
