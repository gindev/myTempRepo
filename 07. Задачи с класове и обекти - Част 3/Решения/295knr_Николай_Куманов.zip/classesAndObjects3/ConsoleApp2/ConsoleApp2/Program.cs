﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете име на мениджър: ");
            string managerName = Console.ReadLine();

            Console.Write("Въведете основна заплата: ");
            decimal managerBaseSalary = decimal.Parse(Console.ReadLine());

            Console.Write("Въведете бонус: ");
            decimal managerBonus = decimal.Parse(Console.ReadLine());

            Manager manager = new Manager(managerName, managerBaseSalary, managerBonus);

            Console.Write("Въведете име на разработчик: ");
            string devName = Console.ReadLine();

            Console.Write("Въведете основна заплата: ");
            decimal devBaseSalary = decimal.Parse(Console.ReadLine());

            Console.Write("Въведете брой извънредни часове: ");
            int devOvertimeHours = int.Parse(Console.ReadLine());

            Console.Write("Въведете ставка за час: ");
            decimal devOvertimeRate = decimal.Parse(Console.ReadLine());

            Developer developer = new Developer(devName, devBaseSalary, devOvertimeHours, devOvertimeRate);

            Console.WriteLine($"Мениджър: {manager.Name}");
            Console.WriteLine($"Крайна заплата: {manager.CalculateSalary()}");

            Console.WriteLine();

            Console.WriteLine($"Разработчик: {developer.Name}");
            Console.WriteLine($"Крайна заплата: {developer.CalculateSalary()}");
        }
    }
}
