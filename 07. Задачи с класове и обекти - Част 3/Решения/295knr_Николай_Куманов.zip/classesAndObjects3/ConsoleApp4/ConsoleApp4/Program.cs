﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ширина на правоъгълник: ");
            double width = double.Parse(Console.ReadLine());

            Console.Write("Въведете височина на правоъгълник: ");
            double height = double.Parse(Console.ReadLine());

            Console.Write("Въведете радиус на окръжност: ");
            double radius = double.Parse(Console.ReadLine());

            Rectangle rectangle = new Rectangle(width, height);
            Circle circle = new Circle(radius);

            Console.WriteLine($"Фигура: {rectangle.Name}");
            Console.WriteLine($"Лице: {Math.Round(rectangle.CalculateArea(), 2)}");
            Console.WriteLine($"Периметър: {Math.Round(rectangle.CalculatePerimeter(), 2)}");

            Console.WriteLine();

            Console.WriteLine($"Фигура: {circle.Name}");
            Console.WriteLine($"Лице: {Math.Round(circle.CalculateArea(), 2)}");
            Console.WriteLine($"Периметър: {Math.Round(circle.CalculatePerimeter(), 2)}");
        }
    }
}
