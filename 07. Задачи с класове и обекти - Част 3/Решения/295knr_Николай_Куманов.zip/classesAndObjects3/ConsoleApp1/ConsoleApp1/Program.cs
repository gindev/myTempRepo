﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете име на студент: ");
            string sFirstName = Console.ReadLine();

            Console.Write("Въведете фамилия на студент: ");
            string sLastName = Console.ReadLine();

            Console.Write("Въведете възраст на студент: ");
            int sAge = int.Parse(Console.ReadLine());

            Console.Write("Въведете факултетен номер: ");
            string sFacNum = Console.ReadLine();

            Console.Write("Въведете специалност: ");
            string sSpec = Console.ReadLine();

            Student student = new Student(sFirstName, sLastName, sAge, sFacNum, sSpec);

            Console.Write("Въведете име на преподавател: ");
            string tFirstName = Console.ReadLine();

            Console.Write("Въведете фамилия на преподавател: ");
            string tLastName = Console.ReadLine();

            Console.Write("Въведете възраст на преподавател: ");
            int tAge = int.Parse(Console.ReadLine());

            Console.Write("Въведете дисциплина: ");
            string tDiscipline = Console.ReadLine();

            Console.Write("Въведете академична длъжност: ");
            string tTitle = Console.ReadLine();

            Teacher teacher = new Teacher(tFirstName, tLastName, tAge, tDiscipline, tTitle);

            student.PrintInfo();
            Console.WriteLine();
            teacher.PrintInfo();
        }
    }
    
}
