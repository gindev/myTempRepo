﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Teacher : Person
    {
        public string Discipline { get; set; }
        public string AcademicTitle { get; set; }

        public Teacher(string firstName, string lastName, int age, string discipline, string academicTitle)
            : base(firstName, lastName, age)
        {
            Discipline = discipline;
            AcademicTitle = academicTitle;
        }

        public override void PrintInfo()
        {
            Console.WriteLine("Информация за преподавател:");
            base.PrintInfo();
            Console.WriteLine($"Дисциплина: {Discipline}");
            Console.WriteLine($"Академична длъжност: {AcademicTitle}");
        }
    }
}
