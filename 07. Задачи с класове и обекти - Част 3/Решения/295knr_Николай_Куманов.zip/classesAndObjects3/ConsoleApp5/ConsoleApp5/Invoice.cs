﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Invoice : IPayable
    {
        public string InvoiceNumber { get; set; }
        public decimal Amount { get; set; }

        public Invoice(string invoiceNumber, decimal amount)
        {
            InvoiceNumber = invoiceNumber;
            Amount = amount;
        }

        public decimal GetPaymentAmount()
        {
            return Amount;
        }
    }
}
