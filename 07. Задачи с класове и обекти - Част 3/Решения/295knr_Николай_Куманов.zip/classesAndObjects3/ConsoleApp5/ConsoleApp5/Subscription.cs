﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Subscription : IPayable
    {
        public string ServiceName { get; set; }
        public decimal MonthlyFee { get; set; }
        public int Months { get; set; }

        public Subscription(string serviceName, decimal monthlyFee, int months)
        {
            ServiceName = serviceName;
            MonthlyFee = monthlyFee;
            Months = months;
        }

        public decimal GetPaymentAmount()
        {
            return MonthlyFee * Months;
        }
    }
}
