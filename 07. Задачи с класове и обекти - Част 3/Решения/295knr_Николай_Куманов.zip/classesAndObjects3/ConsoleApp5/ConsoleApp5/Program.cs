﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPayable> payables = new List<IPayable>();

            payables.Add(new Invoice("1001", 350.00m));
            payables.Add(new Invoice("1002", 120.00m));
            payables.Add(new Subscription("Интернет", 30.00m, 2));
            payables.Add(new Subscription("Софтуерен лиценз", 90.00m, 1));

            decimal totalAmount = 0;

            foreach (IPayable item in payables)
            {
                if (item is Invoice invoice)
                {
                    Console.WriteLine($"Фактура №{invoice.InvoiceNumber}: {invoice.GetPaymentAmount():F2} лв.");
                }
                else if (item is Subscription subscription)
                {
                    Console.WriteLine($"Абонамент: {subscription.ServiceName}, Сума: {subscription.GetPaymentAmount():F2} лв.");
                }

                totalAmount += item.GetPaymentAmount();
            }

            Console.WriteLine();
            Console.WriteLine($"Обща сума за плащане: {totalAmount:F2} лв.");
        }
    }
}
