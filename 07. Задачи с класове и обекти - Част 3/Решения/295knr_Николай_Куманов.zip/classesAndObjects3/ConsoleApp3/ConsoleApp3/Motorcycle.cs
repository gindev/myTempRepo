﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Motorcycle : Vehicle
    {
        public string Type { get; set; }

        public Motorcycle(string make, string model, string type) : base(make, model)
        {
            Type = type;
        }

        public override void ShowInfo()
        {
            Console.Write("Мотоциклет: ");
            base.ShowInfo();
            Console.WriteLine($", Тип: {Type}");
        }
    }
}
