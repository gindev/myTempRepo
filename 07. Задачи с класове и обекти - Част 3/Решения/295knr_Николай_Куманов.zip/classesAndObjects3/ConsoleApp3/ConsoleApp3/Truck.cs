﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Truck : Vehicle
    {
        public int LoadCapacity { get; set; }

        public Truck(string make, string model, int loadCapacity) : base(make, model)
        {
            LoadCapacity = loadCapacity;
        }

        public override void ShowInfo()
        {
            Console.Write("Камион: ");
            base.ShowInfo();
            Console.WriteLine($", Товароносимост: {LoadCapacity} кг");
        }
    }
}
