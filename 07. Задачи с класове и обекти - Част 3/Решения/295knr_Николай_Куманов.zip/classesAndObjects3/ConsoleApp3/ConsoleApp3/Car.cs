﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }

        public Car(string make, string model, int numberOfDoors) : base(make, model)
        {
            NumberOfDoors = numberOfDoors;
        }

        public override void ShowInfo()
        {
            Console.Write("Автомобил: ");
            base.ShowInfo();
            Console.WriteLine($", Брой врати: {NumberOfDoors}");
        }
    }
}
