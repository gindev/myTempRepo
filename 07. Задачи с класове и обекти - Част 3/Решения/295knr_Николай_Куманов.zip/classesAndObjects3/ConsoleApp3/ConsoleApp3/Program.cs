﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> vehicles = new List<Vehicle>();

            vehicles.Add(new Car("Toyota", "Corolla", 4));
            vehicles.Add(new Motorcycle("Yamaha", "MT-07", "спортен"));
            vehicles.Add(new Truck("MAN", "TGX", 18000));

            foreach (Vehicle vehicle in vehicles)
            {
                vehicle.ShowInfo();
            }   
        }
    }
}
